<div align="center">

<img src="https://img.shields.io/badge/ChamaConnect-v1.0.0-064E3B?style=for-the-badge&logoColor=white" alt="ChamaConnect"/>

# 🇰🇪 ChamaConnect

### Kenya Chama (Investment Group) Management System

**A production-ready, full-stack financial platform built specifically for Kenyan savings and investment groups.**

[![FastAPI](https://img.shields.io/badge/FastAPI-0.111-009688?style=flat-square&logo=fastapi&logoColor=white)](https://fastapi.tiangolo.com)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-16-336791?style=flat-square&logo=postgresql&logoColor=white)](https://postgresql.org)
[![React Native](https://img.shields.io/badge/React_Native-Expo-20232A?style=flat-square&logo=react&logoColor=61DAFB)](https://expo.dev)
[![Redis](https://img.shields.io/badge/Redis-7-DC382D?style=flat-square&logo=redis&logoColor=white)](https://redis.io)
[![Docker](https://img.shields.io/badge/Docker-Compose-2496ED?style=flat-square&logo=docker&logoColor=white)](https://docker.com)
[![Python](https://img.shields.io/badge/Python-3.10+-3776AB?style=flat-square&logo=python&logoColor=white)](https://python.org)
[![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)](LICENSE)

[Features](#-features) • [Tech Stack](#-tech-stack) • [Quick Start](#-quick-start) • [API Docs](#-api-reference) • [Screenshots](#-screenshots) • [Contributing](#-contributing)

---

> *"Pamoja Tunaweza"* — Together We Can

</div>

---

## 📖 About

ChamaConnect is a comprehensive digital platform that modernises how Kenyan chamas (savings and investment groups) manage their finances. Built with the realities of the Kenyan fintech landscape in mind — M-Pesa integration, Safaricom/Airtel number formats, Africa's Talking SMS, and the Kenyan shilling (KES) — it replaces spreadsheets and paper ledgers with a secure, mobile-first system.

### Who is this for?

- **Chama Chairpersons** — manage the group, call meetings, oversee loans
- **Treasurers** — configure interest rates, approve loans, send SMS reminders
- **Secretaries** — record contributions, maintain the ledger
- **Members** — check their savings, apply for loans, pay via M-Pesa

---

## ✨ Features

### 🔐 Security
- **4-digit PIN lock** screen on every app launch and background resume
- **JWT authentication** with automatic token rotation (access + refresh)
- **bcrypt** password and PIN hashing — never stored in plain text
- **PIN lockout** after 5 failed attempts (configurable)
- **SMS OTP reset** — sends a 6-digit code to your registered M-Pesa number
- Role-based access control: Chairperson → Treasurer → Secretary → Member

### 📊 Dashboard & Analytics
- Hero card showing **Total Group Savings** in KES at a glance
- Live stats: active loans, pending approvals, compliance rate, defaulting members
- 6-month savings growth trend (bar/line chart)
- **Member leaderboard** ranked by total savings with progress bars
- Contribution breakdown by type: Regular / Welfare / Merry-Go-Round
- Next meeting countdown with venue

### 👥 Member Management
- Register members by **Safaricom or Airtel phone number** (auto-normalised to +254 format)
- Roles: **Chairperson**, **Treasurer**, **Secretary**, **Regular Member** with strict permission boundaries
- Individual member profiles: cumulative savings, active loan balance, full payment history
- Soft-delete (deactivate) members with active loan protection

### 💰 Contributions & Savings
- **Three contribution types**: Regular Savings, Welfare/Emergency, Merry-Go-Round (rotational)
- Transaction ledger with M-Pesa reference code logging
- Status tracking: **Paid**, **Pending**, **Late**, **Waived**
- Monthly compliance reporting (% of members paid on time)
- Merry-Go-Round rotation schedule with payout tracking

### 🏦 Loan Management
- **Two interest calculation engines** (toggle between them):
  - **Flat Rate** — interest on original principal, simpler and predictable
  - **Reducing Balance** — interest on outstanding balance only, fairer for borrowers
- Live loan calculator with full amortisation schedule (month-by-month breakdown)
- **Approval workflow**: applications require Chairperson or Treasurer approval
- Loan eligibility check: maximum 3× member's own savings
- Repayment tracker with countdown timers and overdue detection
- Automatic penalty accrual for late repayments

### 📱 M-Pesa Integration
- **STK Push** simulation (sandbox) — triggers phone prompt with PIN entry
- Realistic M-Pesa keypad UI with animated PIN dots
- Auto-updates the chama ledger on payment confirmation
- Daraja API v2 ready — swap `MPESA_ENV=sandbox` to `production`
- M-Pesa callback handler for real payment webhooks

### 📨 SMS Communications Hub
- **Automated late-payment reminders** generated from ledger data
- Template: *"Habari [Name], your payment of KES [Amount] was due on [Date]. Pay via M-Pesa Till [Number]."*
- One-tap **Send SMS** via Africa's Talking gateway
- Full SMS delivery log with status tracking
- Celery background scheduler: auto-sends reminders 3 days before due date

### ⚙️ Treasurer Settings
- Toggle default interest method per chama
- Configure flat rate (default 10% p.a.) and reducing balance rate (default 12% p.a.)
- Set M-Pesa till/paybill number, late penalty rate, max loan multiplier
- Live comparison tool: see the difference between flat and reducing for any loan amount

---

## 🛠 Tech Stack

### Backend
| Technology | Version | Role |
|-----------|---------|------|
| **FastAPI** | 0.111 | Async REST API framework |
| **PostgreSQL** | 16 | Primary relational database |
| **SQLAlchemy** | 2.0 | Async ORM with type hints |
| **Alembic** | 1.13 | Database migrations |
| **asyncpg** | 0.29 | High-performance async Postgres driver |
| **Redis** | 7 | Caching + Celery message broker |
| **Celery** | 5.4 | Background task queue + scheduler |
| **Pydantic v2** | 2.7 | Request/response validation |
| **python-jose** | 3.3 | JWT token creation and verification |
| **passlib + bcrypt** | 1.7 | Password and PIN hashing |
| **httpx** | 0.27 | Async HTTP client (M-Pesa API calls) |
| **Africa's Talking** | 1.2 | SMS gateway for Kenyan carriers |
| **Gunicorn** | 22 | Production WSGI server |
| **Sentry** | 2.1 | Error monitoring |

### Frontend
| Technology | Version | Role |
|-----------|---------|------|
| **React Native** | 0.74 | Cross-platform mobile framework |
| **Expo** | 51 | Managed workflow + OTA updates |
| **TypeScript** | 5.3 | Type-safe frontend code |
| **TanStack Query** | 5 | Server state management + caching |
| **Zustand** | 4.5 | Lightweight global state |
| **Axios** | 1.7 | HTTP client with JWT interceptors |
| **expo-secure-store** | 13 | Encrypted token storage |
| **React Hook Form + Zod** | 7/3 | Form validation |
| **Victory Native** | 41 | Charts and data visualisation |

### Infrastructure
| Technology | Role |
|-----------|------|
| **Docker Compose** | Full stack local orchestration |
| **Nginx** | Reverse proxy + static file serving |
| **GitHub Actions** *(config included)* | CI/CD pipeline |

---

## 📁 Project Structure

```
chamaconnect/
│
├── 📂 backend/                         # FastAPI Python backend
│   ├── 📂 app/
│   │   ├── main.py                     # App factory, CORS, startup
│   │   ├── worker.py                   # Celery app + beat schedule
│   │   ├── 📂 api/
│   │   │   ├── auth.py                 # Auth: register, login, PIN, JWT
│   │   │   ├── routers.py              # Chama, members, loans, SMS, M-Pesa
│   │   │   └── deps.py                 # Dependency injection (auth, roles)
│   │   ├── 📂 core/
│   │   │   ├── config.py               # Pydantic settings (env vars)
│   │   │   └── security.py             # JWT, bcrypt, OTP generation
│   │   ├── 📂 db/
│   │   │   └── database.py             # Async engine, session factory
│   │   ├── 📂 models/
│   │   │   └── models.py               # 15+ SQLAlchemy ORM models
│   │   ├── 📂 schemas/
│   │   │   └── schemas.py              # Pydantic v2 request/response models
│   │   ├── 📂 services/
│   │   │   ├── loan_service.py         # Flat rate + reducing balance engines
│   │   │   └── sms_mpesa_service.py    # Africa's Talking + M-Pesa Daraja
│   │   └── 📂 tasks/
│   │       └── tasks.py                # Celery: SMS reminders, overdue checks
│   ├── 📂 alembic/                     # Database migration scripts
│   ├── 📂 tests/                       # pytest async test suite
│   ├── seed.py                         # Realistic Kenyan demo data seeder
│   ├── requirements.txt
│   ├── Dockerfile
│   ├── .env                            # Local dev config (safe defaults)
│   └── .env.example                    # Template for production
│
├── 📂 frontend/                        # React Native / Expo mobile app
│   ├── App.tsx                         # Root: auth gate + PIN lock + nav
│   ├── 📂 src/
│   │   ├── 📂 screens/
│   │   │   ├── DashboardScreen.tsx     # Live stats, charts, leaderboard
│   │   │   ├── LoansScreen.tsx         # Loans + live interest calculator
│   │   │   └── PinLockScreen.tsx       # 4-digit PIN overlay with keypad
│   │   ├── 📂 services/
│   │   │   └── api.ts                  # Axios + JWT interceptor + all API calls
│   │   ├── 📂 store/
│   │   │   └── appStore.ts             # Zustand global state
│   │   └── 📂 utils/
│   │       └── theme.ts                # Design tokens (green/navy/KES formatter)
│   ├── app.json                        # Expo config
│   ├── babel.config.js
│   ├── tsconfig.json
│   └── package.json
│
├── 📂 infrastructure/
│   ├── nginx.conf                      # Reverse proxy + SPA routing
│   └── postgres-init.sql               # DB extensions (uuid-ossp, pg_trgm)
│
├── docker-compose.yml                  # Full stack: API + DB + Redis + Nginx + Workers
├── Makefile                            # Dev shortcuts (make dev, make test, etc.)
├── setup.sh                            # One-command bootstrap script
└── README.md
```

---

## 🚀 Quick Start

### Prerequisites

| Tool | Min Version | Download |
|------|------------|----------|
| Python | 3.10+ | [python.org](https://python.org) |
| Docker + Docker Compose | Latest | [docker.com](https://docker.com) |
| Node.js | 18+ | [nodejs.org](https://nodejs.org) |
| Expo Go (phone) | Latest | [App Store](https://apps.apple.com/app/expo-go/id982107779) / [Play Store](https://play.google.com/store/apps/details?id=host.exp.exponent) |

---

### Option 1 — Automated Setup (Recommended)

```bash
git clone https://github.com/YOUR_USERNAME/chamaconnect.git
cd chamaconnect
bash setup.sh
```

Then start the services:

```bash
# Terminal 1 — API server
cd backend && uvicorn app.main:app --reload --port 8000

# Terminal 2 — Mobile app
cd frontend && npx expo start
```

---

### Option 2 — Manual Step-by-Step

```bash
# 1. Clone
git clone https://github.com/YOUR_USERNAME/chamaconnect.git
cd chamaconnect

# 2. Start database + cache
docker compose up -d postgres redis

# 3. Backend setup
cd backend
pip install -r requirements.txt
alembic upgrade head          # Run migrations
python seed.py                # Load demo data
uvicorn app.main:app --reload --port 8000

# 4. Frontend setup (new terminal)
cd ../frontend
npm install --legacy-peer-deps
npx expo start
```

---

### Option 3 — Full Docker Stack

```bash
git clone https://github.com/YOUR_USERNAME/chamaconnect.git
cd chamaconnect
docker compose up --build
```

| Service | URL |
|---------|-----|
| REST API | http://localhost:8000 |
| API Docs (Swagger) | http://localhost:8000/api/docs |
| Web Frontend | http://localhost:80 |

---

## 🔐 Demo Credentials

After running `seed.py`, these accounts are ready to use:

| Member | Phone | Role |
|--------|-------|------|
| Grace Wanjiku Mwangi | +254712345678 | Chairperson |
| Peter Kamau Njoroge | +254722456789 | Treasurer |
| Fatuma Abdi Hassan | +254733567890 | Secretary |
| James Otieno Odhiambo | +254741678901 | Member |
| *(8 more members)* | ... | Member |

**All accounts share:**
- Password: `Password123!`
- PIN: `1234`

---

## 📐 Database Schema

The schema is designed for scale — UUID primary keys, composite indexes, JSONB for flexible metadata.

```
users                    ← Platform accounts (phone + bcrypt password + PIN)
  └─ chama_members       ← User ↔ Chama M2M with role + financial summary cache
       ├─ contributions  ← Every payment: Regular / Welfare / Merry-Go-Round
       ├─ loans          ← Loan lifecycle: Pending → Approved → Active → Repaid
       │    ├─ loan_repayments     ← Instalment-level repayment records
       │    └─ loan_guarantors     ← Member guarantor relationships
       └─ merry_go_round_slots     ← Annual rotation schedule

chamas                   ← Group config: rates, M-Pesa, meeting schedule
  ├─ transactions        ← M-Pesa STK, bank, cash — with raw callback storage
  ├─ meetings            ← Scheduled + completed meetings with minutes
  ├─ sms_logs            ← Every outbound SMS with delivery status
  └─ audit_logs          ← Immutable trail of all sensitive operations

refresh_tokens           ← Rotated JWT refresh tokens (one per device)
```

---

## 💡 Interest Calculation Methods

### Flat Rate (10% p.a. default)

```
Total Interest      = Principal × Rate × (Months ÷ 12)
Monthly Installment = (Principal + Total Interest) ÷ Months

─── Example: KES 50,000 / 12 months / 10% ───────────────
  Total Interest:     KES 5,000
  Total Repayable:    KES 55,000
  Monthly Payment:    KES 4,583
```

### Reducing Balance (12% p.a. default)

```
Monthly Rate = Annual Rate ÷ 12
EMI = P × r × (1 + r)^n ÷ ((1 + r)^n − 1)
Interest recalculated on outstanding balance each month.

─── Example: KES 50,000 / 12 months / 12% ───────────────
  Total Interest:     KES 3,309   (saves KES 1,691 vs flat!)
  Total Repayable:    KES 53,309
  Monthly Payment:    KES 4,442
```

The API returns a **full month-by-month schedule** for both methods.

---

## 📡 API Reference

All endpoints are prefixed with `/api/v1`. Interactive docs at `/api/docs`.

### Authentication
```
POST /auth/register          Register new user account
POST /auth/login             Login → returns JWT access + refresh tokens
POST /auth/refresh           Rotate refresh token
GET  /auth/me                Get current user profile
POST /auth/pin/setup         Set 4-digit PIN
POST /auth/pin/verify        Verify PIN (unlocks the app)
POST /auth/pin/reset/request Send OTP to registered M-Pesa number
POST /auth/pin/reset/verify  Confirm OTP → set new PIN
```

### Chamas
```
GET    /chamas               List chamas I belong to
POST   /chamas               Create a new chama
GET    /chamas/{id}          Get chama details
PATCH  /chamas/{id}          Update settings (Treasurer+ only)
GET    /chamas/{id}/dashboard  Live dashboard stats
```

### Members
```
GET    /chamas/{id}/members              List all members (sorted by savings)
POST   /chamas/{id}/members              Add member by phone number
PATCH  /chamas/{id}/members/{mid}/role   Update member role
DELETE /chamas/{id}/members/{mid}        Deactivate member
```

### Contributions
```
GET  /chamas/{id}/contributions              Paginated ledger (filterable)
POST /chamas/{id}/contributions              Log a contribution
GET  /chamas/{id}/contributions/summary      Monthly compliance stats
```

### Loans
```
POST /chamas/{id}/loans/calculate    Live interest calculator (with schedule)
POST /chamas/{id}/loans              Apply for a loan
GET  /chamas/{id}/loans              List loans (filter by status)
GET  /chamas/{id}/loans/pending      Pending approvals (Treasurer+ only)
POST /chamas/{id}/loans/{lid}/approve  Approve or reject
POST /chamas/{id}/loans/{lid}/repay    Record a repayment
```

### Payments & SMS
```
POST /chamas/{id}/payments/stk-push  Initiate M-Pesa STK push
POST /payments/mpesa/callback        Safaricom webhook endpoint
GET  /chamas/{id}/sms/reminders      Generate late-payment reminder messages
POST /chamas/{id}/sms/send           Send SMS to selected members
```

### Merry-Go-Round
```
GET  /chamas/{id}/merry-go-round     Annual rotation schedule
```

---

## 🧪 Testing

```bash
cd backend

# Run full test suite
pytest -v

# With HTML coverage report
pytest --cov=app --cov-report=html -v
open htmlcov/index.html

# Run a specific test
pytest tests/test_main.py::test_loan_calculate_flat_rate -v
pytest tests/test_main.py::test_reducing_balance_calculation -v
```

Test coverage includes:
- ✅ User registration and login flow
- ✅ PIN setup, verify, wrong PIN lockout
- ✅ Flat rate interest calculations (with assertions)
- ✅ Reducing balance calculations (with assertions)
- ✅ Loan application → approval → repayment lifecycle
- ✅ Contribution logging and ledger
- ✅ Dashboard stats aggregation

---

## 🔧 Configuration

All configuration is via environment variables in `backend/.env`.

### Key variables

```env
# ── Core ────────────────────────────────────────
SECRET_KEY=replace-with-64-char-random-string-in-prod
APP_ENV=development   # change to 'production'
DEBUG=true

# ── Database ─────────────────────────────────────
DATABASE_URL=postgresql+asyncpg://chamauser:password@localhost:5432/chamaconnect

# ── M-Pesa (Safaricom Daraja) ─────────────────────
MPESA_ENV=sandbox                  # 'production' for live payments
MPESA_CONSUMER_KEY=your_key
MPESA_CONSUMER_SECRET=your_secret
MPESA_PASSKEY=your_passkey
MPESA_SHORTCODE=174379
MPESA_CALLBACK_URL=https://yourdomain.com/api/v1/payments/mpesa/callback

# ── SMS (Africa's Talking) ────────────────────────
SMS_ENABLED=false                  # true to send real SMS
AT_USERNAME=your_username
AT_API_KEY=your_api_key
AT_SENDER_ID=ChamaApp

# ── Auth ──────────────────────────────────────────
PIN_MAX_ATTEMPTS=5
PIN_LOCKOUT_MINUTES=30
ACCESS_TOKEN_EXPIRE_MINUTES=30
```

---

## 🌍 Enabling Real M-Pesa

1. Create a developer account at [developer.safaricom.co.ke](https://developer.safaricom.co.ke)
2. Create an app and get your **Consumer Key**, **Consumer Secret**, and **Passkey**
3. Set up your **Paybill** or **Till** number
4. Expose your callback URL (use [ngrok](https://ngrok.com) for testing)
5. Update `.env`:
   ```env
   MPESA_ENV=production
   MPESA_CONSUMER_KEY=your_key
   MPESA_CONSUMER_SECRET=your_secret
   MPESA_PASSKEY=your_passkey
   MPESA_SHORTCODE=your_till_or_paybill
   MPESA_CALLBACK_URL=https://yourdomain.com/api/v1/payments/mpesa/callback
   ```

---

## 📱 Enabling Real SMS

1. Sign up at [africastalking.com](https://africastalking.com)
2. Create a team, get your **API key**
3. Register a **Sender ID** ("ChamaApp" or your chama name — requires AT approval)
4. Update `.env`:
   ```env
   SMS_ENABLED=true
   AT_USERNAME=your_username
   AT_API_KEY=your_api_key
   AT_SENDER_ID=YourSenderID
   ```

---

## 📈 Scaling Guide

The architecture is built to scale horizontally from day one:

| Users | Recommended Config |
|-------|-------------------|
| < 1,000 | 1 server, 2 Gunicorn workers, `DB_POOL_SIZE=10` |
| 1,000 – 10,000 | 2 app servers behind Nginx, `DB_POOL_SIZE=20`, Redis cache |
| 10,000 – 100,000 | Auto-scaling group, PgBouncer connection pooler, read replicas |
| 100,000+ | Multi-region, table partitioning (contributions by month), sharded Redis |

**Already built for scale:**
- UUID primary keys — no sequential ID conflicts across shards
- Async SQLAlchemy — handles thousands of concurrent requests per worker
- Composite indexes on every high-frequency query pattern
- JSONB columns for schema-flexible metadata without migrations
- Celery workers are stateless — scale out by adding more workers

---

## 🛠 Makefile Commands

```bash
make help              # Show all available commands
make dev               # Start full local dev environment in one go
make backend           # Start API with hot reload
make frontend          # Start Expo dev server
make test              # Run pytest suite
make test-cov          # Run tests + open HTML coverage report
make seed              # Re-seed the database with demo data
make migrate           # Run pending Alembic migrations
make db-shell          # Open psql console
make docker-up         # Start full Docker Compose stack
make docker-down       # Stop all Docker services
make docker-reset      # Wipe volumes and restart clean
make clean             # Remove Python cache files
```

---

## 🤝 Contributing

Contributions are welcome! Here's how to get started:

1. **Fork** the repository
2. **Clone** your fork: `git clone https://github.com/YOUR_USERNAME/chamaconnect.git`
3. **Create a branch**: `git checkout -b feature/your-feature-name`
4. **Make your changes** and add tests
5. **Run tests**: `cd backend && pytest -v`
6. **Commit**: `git commit -m "feat: description of your feature"`
7. **Push**: `git push origin feature/your-feature-name`
8. **Open a Pull Request**

### Commit message convention
```
feat:     New feature
fix:      Bug fix
docs:     Documentation update
test:     Adding or updating tests
refactor: Code refactoring (no feature/fix)
chore:    Build system or dependency updates
```

---

## 📋 Roadmap

- [ ] Push notifications (Expo Notifications + FCM)
- [ ] Investment portfolio tracking (shares, bonds, property)
- [ ] Dividend calculation and distribution
- [ ] Multi-currency support (USD, EUR for diaspora chamas)
- [ ] Loan guarantor acceptance workflow (in-app)
- [ ] Biometric unlock (fingerprint / Face ID)
- [ ] Dark mode
- [ ] Offline-first mode with sync
- [ ] Admin analytics dashboard (web)
- [ ] WhatsApp Bot integration (via Twilio)
- [ ] Bank statement import (PDF parsing)

---

## 📄 License

This project is licensed under the **MIT License** — see the [LICENSE](LICENSE) file for details.

You are free to use, modify, and distribute this software for personal and commercial chama projects.

---

## 🙏 Acknowledgements

- Built with ❤️ for Kenyan savings groups
- [Safaricom Daraja API](https://developer.safaricom.co.ke) — M-Pesa integration
- [Africa's Talking](https://africastalking.com) — SMS gateway for Kenyan carriers
- [FastAPI](https://fastapi.tiangolo.com) — The backbone of the API
- [Expo](https://expo.dev) — Simplifying React Native development

---

<div align="center">

**⭐ Star this repo if it helps your chama go digital!**

*Pamoja Tunaweza — Together We Can*

</div>
