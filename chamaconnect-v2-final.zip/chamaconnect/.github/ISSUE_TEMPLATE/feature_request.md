---
name: Feature request
about: Suggest a new feature for ChamaConnect
labels: enhancement
assignees: ''
---

**Is your request related to a problem?**
Describe the problem. e.g. "Chairpersons have no way to see..."

**Describe the solution you'd like**
What should the feature do?

**Who benefits?**
- [ ] Chairperson
- [ ] Treasurer
- [ ] Secretary
- [ ] Regular Member
- [ ] All roles

**Additional context**
Screenshots, mockups, or examples of similar apps.
