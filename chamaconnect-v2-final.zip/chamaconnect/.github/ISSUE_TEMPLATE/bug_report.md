---
name: Bug report
about: Something is broken — help us fix it
labels: bug
assignees: ''
---

**Describe the bug**
A clear description of what the bug is.

**Steps to reproduce**
1. Go to '...'
2. Click on '...'
3. See error

**Expected behaviour**
What you expected to happen.

**Environment**
- OS: [e.g. Ubuntu 22.04 / macOS 14]
- Python: [e.g. 3.12]
- Node: [e.g. 20]
- Version/commit: [e.g. v1.0.0 or abc1234]

**Logs / screenshots**
```
paste logs here
```
