## What does this PR do?

<!-- Describe your changes clearly -->

## Type of change
- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Refactor / performance improvement
- [ ] Test coverage improvement

## Testing
- [ ] `pytest -v` passes locally
- [ ] Added tests for new functionality
- [ ] Tested on mobile device or emulator (for frontend changes)

## Checklist
- [ ] Code formatted with `black` / `ruff`
- [ ] New DB tables have an Alembic migration (`make migrate-create`)
- [ ] New API endpoints documented in README
- [ ] No secrets or credentials committed

## Related issues
Closes #
