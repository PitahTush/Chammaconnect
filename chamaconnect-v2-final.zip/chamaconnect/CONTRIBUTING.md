# Contributing to ChamaConnect

Thank you for helping modernise Kenyan chamas! 🇰🇪

## Getting started

1. **Fork** the repository on GitHub
2. **Clone** your fork: `git clone https://github.com/YOUR_USERNAME/chamaconnect.git`
3. **Create a branch**: `git checkout -b feature/your-feature-name`
4. **Bootstrap**: `bash setup.sh`
5. **Make your changes** and write tests
6. **Run tests**: `cd backend && pytest -v`
7. **Commit** using the convention below
8. **Push** and open a Pull Request

## Commit message convention

| Prefix | When to use |
|--------|-------------|
| `feat:` | New feature |
| `fix:` | Bug fix |
| `docs:` | Documentation only |
| `test:` | Adding or updating tests |
| `refactor:` | Code change with no feature or fix |
| `chore:` | Build tools, dependency updates |

**Examples:**
```
feat: add WhatsApp notification channel
fix: reducing balance final payment rounding error
docs: add production M-Pesa deployment guide
test: add loan approval workflow integration test
```

## Code standards

- **Python**: PEP 8 style, `black` formatting, `ruff` linting
- **TypeScript**: strict mode enabled, avoid untyped `any`
- **Tests**: every new API endpoint needs at least one test
- **Migrations**: new or changed DB models need an Alembic migration

```bash
# Format + lint before committing
cd backend
black app/ --line-length 120
ruff check app/ --fix
```

## Database changes

```bash
# After changing a model in models.py
make migrate-create MSG="describe what changed"

# Apply the migration
make migrate
```

## Good first issues

Check the Issues tab for tickets labelled **`good first issue`** — these are
well-scoped tasks that don't require deep knowledge of the whole codebase.

## Questions?

Open a [Discussion](../../discussions) — we respond within 24 hours.
