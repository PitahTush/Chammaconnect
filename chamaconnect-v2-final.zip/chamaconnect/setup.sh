#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# ChamaConnect — One-Command Setup Script
# Run: bash setup.sh
# ─────────────────────────────────────────────────────────────
set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}⚠${NC}  $1"; }
err()  { echo -e "${RED}✗${NC}  $1"; exit 1; }
step() { echo -e "\n${GREEN}━━━ $1 ━━━${NC}"; }

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║        ChamaConnect Setup Script             ║"
echo "║   Kenya Chama Management System v1.0         ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── Prerequisites check ──────────────────────────────────────
step "Checking prerequisites"

command -v python3 >/dev/null 2>&1 || err "Python 3.10+ required. Install from https://python.org"
command -v pip >/dev/null 2>&1    || err "pip not found. Install Python first."
command -v node >/dev/null 2>&1   || warn "Node.js not found — frontend won't run. Install from https://nodejs.org"
command -v docker >/dev/null 2>&1 || err "Docker required. Install from https://docker.com"
command -v docker compose >/dev/null 2>&1 || err "Docker Compose required (comes with Docker Desktop)"

PY_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
log "Python $PY_VERSION"

# ── Start infrastructure ─────────────────────────────────────
step "Starting PostgreSQL and Redis"
docker compose up -d postgres redis
log "Waiting for Postgres to be ready..."
sleep 5

# ── Backend setup ────────────────────────────────────────────
step "Installing Python dependencies"
cd backend
pip install -r requirements.txt -q
log "Dependencies installed"

# ── Environment ──────────────────────────────────────────────
if [ ! -f ".env" ]; then
    cp .env.example .env
    log "Created .env from .env.example"
else
    log ".env already exists"
fi

# ── Database migrations ──────────────────────────────────────
step "Running database migrations"
alembic upgrade head
log "Migrations applied"

# ── Seed data ────────────────────────────────────────────────
step "Seeding demo data"
python seed.py
cd ..

# ── Frontend setup ───────────────────────────────────────────
if command -v node >/dev/null 2>&1; then
    step "Installing frontend dependencies"
    cd frontend
    npm install --legacy-peer-deps
    log "Frontend dependencies installed"
    cd ..
fi

# ── Done ─────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║                  Setup Complete! 🎉                      ║"
echo "╠══════════════════════════════════════════════════════════╣"
echo "║                                                          ║"
echo "║  Start the API server:                                   ║"
echo "║    cd backend && uvicorn app.main:app --reload           ║"
echo "║                                                          ║"
echo "║  Start the mobile app:                                   ║"
echo "║    cd frontend && npx expo start                        ║"
echo "║                                                          ║"
echo "║  API Docs:  http://localhost:8000/api/docs               ║"
echo "║                                                          ║"
echo "║  Demo login credentials:                                 ║"
echo "║    Phone:    +254712345678                               ║"
echo "║    Password: Password123!                                ║"
echo "║    PIN:      1234                                        ║"
echo "║                                                          ║"
echo "║  Or run full stack with Docker:                          ║"
echo "║    docker compose up --build                             ║"
echo "║                                                          ║"
echo "╚══════════════════════════════════════════════════════════╝"
