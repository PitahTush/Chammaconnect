# Code of Conduct

## Our Pledge

We are committed to making ChamaConnect a welcoming, respectful project
for everyone — regardless of background, gender, nationality, or experience level.

## Our Standards

**Positive behaviour:**
- Using welcoming and inclusive language
- Being respectful of differing viewpoints and experiences
- Accepting constructive criticism gracefully
- Focusing on what is best for the community

**Unacceptable behaviour:**
- Harassment or discriminatory comments of any kind
- Personal attacks
- Publishing others' private information without consent
- Trolling or deliberately disruptive behaviour

## Enforcement

Violations may be reported via GitHub Issues (mark as confidential).
Maintainers will review and respond within 48 hours.

## Attribution

Adapted from the [Contributor Covenant](https://www.contributor-covenant.org) v2.1.
