import enum
import uuid
from datetime import datetime, date
from decimal import Decimal
from typing import List, Optional

from sqlalchemy import (
    Boolean, Column, Date, DateTime, Enum,
    ForeignKey, Index, Integer, Numeric, String, Text,
    UniqueConstraint, CheckConstraint, func,
)
from sqlalchemy import JSON as JSONB
from sqlalchemy.dialects.postgresql import UUID
try:
    from sqlalchemy.dialects.postgresql import ARRAY
except ImportError:
    pass
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


def generate_uuid() -> str:
    return str(uuid.uuid4())


class UserRole(str, enum.Enum):
    SUPER_ADMIN = "super_admin"
    CHAMA_ADMIN = "chama_admin"
    MEMBER = "member"


class ChamaMemberRole(str, enum.Enum):
    CHAIRPERSON = "chairperson"
    TREASURER = "treasurer"
    SECRETARY = "secretary"
    MEMBER = "member"


class ContributionType(str, enum.Enum):
    REGULAR_SAVINGS = "regular_savings"
    WELFARE = "welfare"
    MERRY_GO_ROUND = "merry_go_round"
    FINE = "fine"
    REGISTRATION_FEE = "registration_fee"


class ContributionStatus(str, enum.Enum):
    PAID = "paid"
    PENDING = "pending"
    LATE = "late"
    WAIVED = "waived"


class LoanStatus(str, enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    DISBURSED = "disbursed"
    ACTIVE = "active"
    FULLY_REPAID = "fully_repaid"
    DEFAULTED = "defaulted"


class InterestMethod(str, enum.Enum):
    FLAT_RATE = "flat_rate"
    REDUCING_BALANCE = "reducing_balance"


class TransactionType(str, enum.Enum):
    MPESA_STK = "mpesa_stk"
    MPESA_PAYBILL = "mpesa_paybill"
    BANK_TRANSFER = "bank_transfer"
    CASH = "cash"
    INTERNAL = "internal"


class TransactionStatus(str, enum.Enum):
    INITIATED = "initiated"
    PENDING = "pending"
    SUCCESS = "success"
    FAILED = "failed"
    REVERSED = "reversed"


class SMSStatus(str, enum.Enum):
    PENDING = "pending"
    SENT = "sent"
    DELIVERED = "delivered"
    FAILED = "failed"


class Network(str, enum.Enum):
    SAFARICOM = "safaricom"
    AIRTEL = "airtel"
    TELKOM = "telkom"
    EQUITEL = "equitel"


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


class SoftDeleteMixin:
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    deleted_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )


class User(TimestampMixin, SoftDeleteMixin, Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=generate_uuid
    )
    phone_number: Mapped[str] = mapped_column(
        String(20), unique=True, nullable=False, index=True
    )
    email: Mapped[Optional[str]] = mapped_column(
        String(254), unique=True, nullable=True, index=True
    )
    full_name: Mapped[str] = mapped_column(String(200), nullable=False)
    national_id: Mapped[Optional[str]] = mapped_column(
        String(20), unique=True, nullable=True
    )
    network: Mapped[Optional[Network]] = mapped_column(Enum(Network), nullable=True)
    profile_photo_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)

    hashed_password: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    hashed_pin: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    pin_attempts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    pin_locked_until: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    pin_reset_code: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)
    pin_reset_expires: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    is_pin_set: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    role: Mapped[UserRole] = mapped_column(Enum(UserRole), default=UserRole.MEMBER)
    last_login_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    chama_memberships: Mapped[List["ChamaMember"]] = relationship(
        back_populates="user", lazy="selectin"
    )
    refresh_tokens: Mapped[List["RefreshToken"]] = relationship(back_populates="user")
    audit_logs: Mapped[List["AuditLog"]] = relationship(back_populates="user")

    __table_args__ = (
    )


class Chama(TimestampMixin, SoftDeleteMixin, Base):
    __tablename__ = "chamas"

    id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=generate_uuid
    )
    name: Mapped[str] = mapped_column(String(200), nullable=False, index=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    registration_number: Mapped[Optional[str]] = mapped_column(
        String(50), unique=True, nullable=True
    )
    logo_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    county: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)

    monthly_contribution: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    welfare_contribution: Mapped[Decimal] = mapped_column(
        Numeric(14, 2), default=Decimal("0")
    )
    registration_fee: Mapped[Decimal] = mapped_column(
        Numeric(14, 2), default=Decimal("0")
    )

    flat_interest_rate: Mapped[Decimal] = mapped_column(
        Numeric(6, 4), default=Decimal("0.10")
    )
    reducing_interest_rate: Mapped[Decimal] = mapped_column(
        Numeric(6, 4), default=Decimal("0.12")
    )
    default_interest_method: Mapped[InterestMethod] = mapped_column(
        Enum(InterestMethod), default=InterestMethod.FLAT_RATE
    )
    max_loan_multiplier: Mapped[Decimal] = mapped_column(
        Numeric(5, 2), default=Decimal("3.00")
    )
    late_penalty_rate: Mapped[Decimal] = mapped_column(
        Numeric(6, 4), default=Decimal("0.02")
    )
    min_guarantors: Mapped[int] = mapped_column(Integer, default=2)

    mpesa_till: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    mpesa_paybill: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    mpesa_account: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)

    meeting_schedule: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    next_meeting_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    meeting_venue: Mapped[Optional[str]] = mapped_column(String(300), nullable=True)

    merry_go_round_amount: Mapped[Decimal] = mapped_column(
        Numeric(14, 2), default=Decimal("0")
    )
    merry_go_round_active: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    settings: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True, default=dict)

    members: Mapped[List["ChamaMember"]] = relationship(
        back_populates="chama", lazy="selectin"
    )
    contributions: Mapped[List["Contribution"]] = relationship(back_populates="chama")
    loans: Mapped[List["Loan"]] = relationship(back_populates="chama")
    transactions: Mapped[List["Transaction"]] = relationship(back_populates="chama")
    meetings: Mapped[List["Meeting"]] = relationship(back_populates="chama")
    merry_go_round_slots: Mapped[List["MerryGoRoundSlot"]] = relationship(
        back_populates="chama"
    )
    sms_logs: Mapped[List["SMSLog"]] = relationship(back_populates="chama")
    audit_logs: Mapped[List["AuditLog"]] = relationship(back_populates="chama")


class ChamaMember(TimestampMixin, Base):
    __tablename__ = "chama_members"

    id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=generate_uuid
    )
    chama_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        ForeignKey("chamas.id", ondelete="CASCADE"),
        nullable=False,
    )
    user_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
    )
    role: Mapped[ChamaMemberRole] = mapped_column(
        Enum(ChamaMemberRole), default=ChamaMemberRole.MEMBER
    )
    member_number: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    joined_at: Mapped[date] = mapped_column(Date, server_default=func.current_date())
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_defaulting: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    total_savings: Mapped[Decimal] = mapped_column(Numeric(14, 2), default=Decimal("0"))
    total_contributed: Mapped[Decimal] = mapped_column(
        Numeric(14, 2), default=Decimal("0")
    )
    active_loan_balance: Mapped[Decimal] = mapped_column(
        Numeric(14, 2), default=Decimal("0")
    )
    shares: Mapped[int] = mapped_column(Integer, default=0)

    chama: Mapped["Chama"] = relationship(back_populates="members")
    user: Mapped["User"] = relationship(back_populates="chama_memberships")
    contributions: Mapped[List["Contribution"]] = relationship(back_populates="member")
    loans: Mapped[List["Loan"]] = relationship(
        back_populates="member", foreign_keys="Loan.member_id"
    )
    guaranteed_loans: Mapped[List["LoanGuarantor"]] = relationship(
        back_populates="guarantor"
    )
    merry_go_round_slot: Mapped[Optional["MerryGoRoundSlot"]] = relationship(
        back_populates="member"
    )

    __table_args__ = (
        UniqueConstraint("chama_id", "user_id", name="uq_chama_member"),

    )


class Contribution(TimestampMixin, Base):
    __tablename__ = "contributions"

    id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=generate_uuid
    )
    chama_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        ForeignKey("chamas.id", ondelete="CASCADE"),
        nullable=False,
    )
    member_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        ForeignKey("chama_members.id", ondelete="CASCADE"),
        nullable=False,
    )
    transaction_id: Mapped[Optional[str]] = mapped_column(
        UUID(as_uuid=False), ForeignKey("transactions.id"), nullable=True
    )

    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    contribution_type: Mapped[ContributionType] = mapped_column(
        Enum(ContributionType), nullable=False
    )
    status: Mapped[ContributionStatus] = mapped_column(
        Enum(ContributionStatus), default=ContributionStatus.PENDING
    )
    period_month: Mapped[int] = mapped_column(Integer, nullable=False)
    period_year: Mapped[int] = mapped_column(Integer, nullable=False)
    due_date: Mapped[date] = mapped_column(Date, nullable=False)
    paid_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    mpesa_ref: Mapped[Optional[str]] = mapped_column(
        String(50), nullable=True, index=True
    )
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    recorded_by_id: Mapped[Optional[str]] = mapped_column(
        UUID(as_uuid=False), ForeignKey("users.id"), nullable=True
    )

    chama: Mapped["Chama"] = relationship(back_populates="contributions")
    member: Mapped["ChamaMember"] = relationship(back_populates="contributions")
    transaction: Mapped[Optional["Transaction"]] = relationship()

    __table_args__ = (

        CheckConstraint("amount > 0", name="ck_contribution_positive_amount"),
    )


class Loan(TimestampMixin, Base):
    __tablename__ = "loans"

    id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=generate_uuid
    )
    chama_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        ForeignKey("chamas.id", ondelete="CASCADE"),
        nullable=False,
    )
    member_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), ForeignKey("chama_members.id"), nullable=False
    )
    loan_number: Mapped[str] = mapped_column(
        String(30), unique=True, nullable=False, index=True
    )
    purpose: Mapped[str] = mapped_column(String(300), nullable=False)

    principal: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    interest_method: Mapped[InterestMethod] = mapped_column(
        Enum(InterestMethod), nullable=False
    )
    interest_rate: Mapped[Decimal] = mapped_column(Numeric(6, 4), nullable=False)
    repayment_months: Mapped[int] = mapped_column(Integer, nullable=False)
    monthly_installment: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    total_interest: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    total_repayable: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)

    status: Mapped[LoanStatus] = mapped_column(
        Enum(LoanStatus), default=LoanStatus.PENDING, index=True
    )
    amount_repaid: Mapped[Decimal] = mapped_column(Numeric(14, 2), default=Decimal("0"))
    outstanding_balance: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    penalties_accrued: Mapped[Decimal] = mapped_column(
        Numeric(14, 2), default=Decimal("0")
    )
    disbursed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    first_repayment_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    due_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True, index=True)
    fully_repaid_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    applied_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    approved_by_id: Mapped[Optional[str]] = mapped_column(
        UUID(as_uuid=False), ForeignKey("users.id"), nullable=True
    )
    approved_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    rejection_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    chama: Mapped["Chama"] = relationship(back_populates="loans")
    member: Mapped["ChamaMember"] = relationship(
        back_populates="loans", foreign_keys=[member_id]
    )
    repayments: Mapped[List["LoanRepayment"]] = relationship(
        back_populates="loan", order_by="LoanRepayment.paid_at"
    )
    guarantors: Mapped[List["LoanGuarantor"]] = relationship(back_populates="loan")

    __table_args__ = (

        CheckConstraint("principal > 0", name="ck_loan_positive_principal"),
    )


class LoanRepayment(TimestampMixin, Base):
    __tablename__ = "loan_repayments"

    id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=generate_uuid
    )
    loan_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        ForeignKey("loans.id", ondelete="CASCADE"),
        nullable=False,
    )
    transaction_id: Mapped[Optional[str]] = mapped_column(
        UUID(as_uuid=False), ForeignKey("transactions.id"), nullable=True
    )
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    principal_portion: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    interest_portion: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    penalty_portion: Mapped[Decimal] = mapped_column(
        Numeric(14, 2), default=Decimal("0")
    )
    paid_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    mpesa_ref: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    loan: Mapped["Loan"] = relationship(back_populates="repayments")

    __table_args__ = (
    )


class LoanGuarantor(TimestampMixin, Base):
    __tablename__ = "loan_guarantors"

    id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=generate_uuid
    )
    loan_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        ForeignKey("loans.id", ondelete="CASCADE"),
        nullable=False,
    )
    guarantor_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), ForeignKey("chama_members.id"), nullable=False
    )
    amount_guaranteed: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    accepted: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    accepted_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    loan: Mapped["Loan"] = relationship(back_populates="guarantors")
    guarantor: Mapped["ChamaMember"] = relationship(back_populates="guaranteed_loans")

    __table_args__ = (
        UniqueConstraint("loan_id", "guarantor_id", name="uq_loan_guarantor"),
    )


class Transaction(TimestampMixin, Base):
    __tablename__ = "transactions"

    id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=generate_uuid
    )
    chama_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        ForeignKey("chamas.id", ondelete="CASCADE"),
        nullable=False,
    )
    user_id: Mapped[Optional[str]] = mapped_column(
        UUID(as_uuid=False), ForeignKey("users.id"), nullable=True
    )
    transaction_type: Mapped[TransactionType] = mapped_column(
        Enum(TransactionType), nullable=False
    )
    status: Mapped[TransactionStatus] = mapped_column(
        Enum(TransactionStatus), default=TransactionStatus.INITIATED, index=True
    )
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    phone_number: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)

    mpesa_checkout_request_id: Mapped[Optional[str]] = mapped_column(
        String(100), unique=True, nullable=True
    )
    mpesa_merchant_request_id: Mapped[Optional[str]] = mapped_column(
        String(100), nullable=True
    )
    mpesa_ref: Mapped[Optional[str]] = mapped_column(
        String(50), unique=True, nullable=True, index=True
    )
    mpesa_receipt_number: Mapped[Optional[str]] = mapped_column(
        String(50), nullable=True
    )
    mpesa_raw_response: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)

    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    extra_data: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    chama: Mapped["Chama"] = relationship(back_populates="transactions")

    __table_args__ = (
        CheckConstraint("amount > 0", name="ck_transaction_positive"),
    )


class MerryGoRoundSlot(TimestampMixin, Base):
    __tablename__ = "merry_go_round_slots"

    id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=generate_uuid
    )
    chama_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        ForeignKey("chamas.id", ondelete="CASCADE"),
        nullable=False,
    )
    member_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), ForeignKey("chama_members.id"), nullable=False
    )
    cycle_year: Mapped[int] = mapped_column(Integer, nullable=False)
    position: Mapped[int] = mapped_column(Integer, nullable=False)
    payout_month: Mapped[int] = mapped_column(Integer, nullable=False)
    payout_amount: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    received: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    received_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    chama: Mapped["Chama"] = relationship(back_populates="merry_go_round_slots")
    member: Mapped["ChamaMember"] = relationship(back_populates="merry_go_round_slot")

    __table_args__ = (
        UniqueConstraint("chama_id", "cycle_year", "position", name="uq_mgr_slot"),
        UniqueConstraint(
            "chama_id", "cycle_year", "member_id", name="uq_mgr_member_cycle"
        ),
    )


class Meeting(TimestampMixin, Base):
    __tablename__ = "meetings"

    id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=generate_uuid
    )
    chama_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        ForeignKey("chamas.id", ondelete="CASCADE"),
        nullable=False,
    )
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    scheduled_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    venue: Mapped[Optional[str]] = mapped_column(String(300), nullable=True)
    agenda: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    minutes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_completed: Mapped[bool] = mapped_column(Boolean, default=False)

    chama: Mapped["Chama"] = relationship(back_populates="meetings")


class SMSLog(TimestampMixin, Base):
    __tablename__ = "sms_logs"

    id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=generate_uuid
    )
    chama_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        ForeignKey("chamas.id", ondelete="CASCADE"),
        nullable=False,
    )
    recipient_phone: Mapped[str] = mapped_column(String(20), nullable=False)
    recipient_name: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[SMSStatus] = mapped_column(
        Enum(SMSStatus), default=SMSStatus.PENDING
    )
    gateway_ref: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    sent_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    triggered_by_id: Mapped[Optional[str]] = mapped_column(
        UUID(as_uuid=False), ForeignKey("users.id"), nullable=True
    )

    chama: Mapped["Chama"] = relationship(back_populates="sms_logs")

    __table_args__ = (
    )


class RefreshToken(TimestampMixin, Base):
    __tablename__ = "refresh_tokens"

    id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=generate_uuid
    )
    user_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
    )
    token_hash: Mapped[str] = mapped_column(
        String(255), unique=True, nullable=False, index=True
    )
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    is_revoked: Mapped[bool] = mapped_column(Boolean, default=False)
    device_info: Mapped[Optional[str]] = mapped_column(String(300), nullable=True)

    user: Mapped["User"] = relationship(back_populates="refresh_tokens")


class AuditLog(TimestampMixin, Base):
    __tablename__ = "audit_logs"

    id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=generate_uuid
    )
    chama_id: Mapped[Optional[str]] = mapped_column(
        UUID(as_uuid=False), ForeignKey("chamas.id"), nullable=True
    )
    user_id: Mapped[Optional[str]] = mapped_column(
        UUID(as_uuid=False), ForeignKey("users.id"), nullable=True
    )
    action: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    resource_type: Mapped[str] = mapped_column(String(50), nullable=False)
    resource_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    old_value: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    new_value: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    ip_address: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)
    user_agent: Mapped[Optional[str]] = mapped_column(String(300), nullable=True)

    chama: Mapped[Optional["Chama"]] = relationship(back_populates="audit_logs")
    user: Mapped[Optional["User"]] = relationship(back_populates="audit_logs")

    __table_args__ = (
    )
