"""
ChamaConnect — Pydantic v2 schemas for API validation and serialisation.
"""
from datetime import date, datetime
from decimal import Decimal
from typing import List, Optional, Any

from pydantic import BaseModel, EmailStr, Field, field_validator, model_validator
import re


# ── Base ──────────────────────────────────────────────────────────────────────

class BaseResponse(BaseModel):
    class Config:
        from_attributes = True


class PaginatedResponse(BaseModel):
    items: List[Any]
    total: int
    page: int
    per_page: int
    pages: int


# ── Auth ──────────────────────────────────────────────────────────────────────

class RegisterRequest(BaseModel):
    full_name: str = Field(..., min_length=2, max_length=200)
    phone_number: str = Field(..., pattern=r"^(\+254|0)[17]\d{8}$")
    email: Optional[EmailStr] = None
    password: str = Field(..., min_length=8, max_length=100)
    network: Optional[str] = None

    @field_validator("phone_number")
    @classmethod
    def normalise_phone(cls, v: str) -> str:
        v = v.replace(" ", "").replace("-", "")
        if v.startswith("0"):
            return "+254" + v[1:]
        return v


class LoginRequest(BaseModel):
    phone_number: str
    password: str

    @field_validator("phone_number")
    @classmethod
    def normalise_phone(cls, v: str) -> str:
        v = v.replace(" ", "").replace("-", "")
        if v.startswith("0"):
            return "+254" + v[1:]
        return v


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int


class RefreshRequest(BaseModel):
    refresh_token: str


class SetPINRequest(BaseModel):
    pin: str = Field(..., min_length=4, max_length=4, pattern=r"^\d{4}$")
    confirm_pin: str = Field(..., min_length=4, max_length=4)

    @model_validator(mode="after")
    def pins_must_match(self) -> "SetPINRequest":
        if self.pin != self.confirm_pin:
            raise ValueError("PINs do not match")
        return self


class VerifyPINRequest(BaseModel):
    pin: str = Field(..., min_length=4, max_length=4, pattern=r"^\d{4}$")


class RequestPINResetRequest(BaseModel):
    phone_number: str

    @field_validator("phone_number")
    @classmethod
    def normalise_phone(cls, v: str) -> str:
        v = v.replace(" ", "").replace("-", "")
        if v.startswith("0"):
            return "+254" + v[1:]
        return v


class VerifyPINResetRequest(BaseModel):
    phone_number: str
    reset_code: str = Field(..., min_length=6, max_length=6)
    new_pin: str = Field(..., min_length=4, max_length=4, pattern=r"^\d{4}$")


# ── User ──────────────────────────────────────────────────────────────────────

class UserOut(BaseResponse):
    id: str
    full_name: str
    phone_number: str
    email: Optional[str] = None
    network: Optional[str] = None
    is_active: bool
    is_verified: bool
    is_pin_set: bool
    role: str
    profile_photo_url: Optional[str] = None
    created_at: datetime


class UserUpdate(BaseModel):
    full_name: Optional[str] = Field(None, min_length=2, max_length=200)
    email: Optional[EmailStr] = None
    national_id: Optional[str] = None
    network: Optional[str] = None


# ── Chama ─────────────────────────────────────────────────────────────────────

class ChamaCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=200)
    description: Optional[str] = None
    county: Optional[str] = None
    monthly_contribution: Decimal = Field(..., gt=0)
    welfare_contribution: Optional[Decimal] = Decimal("0")
    registration_fee: Optional[Decimal] = Decimal("0")
    flat_interest_rate: Optional[Decimal] = Decimal("0.10")
    reducing_interest_rate: Optional[Decimal] = Decimal("0.12")
    default_interest_method: Optional[str] = "flat_rate"
    max_loan_multiplier: Optional[Decimal] = Decimal("3.00")
    late_penalty_rate: Optional[Decimal] = Decimal("0.02")
    mpesa_till: Optional[str] = None
    mpesa_paybill: Optional[str] = None
    merry_go_round_amount: Optional[Decimal] = Decimal("0")
    merry_go_round_active: Optional[bool] = False


class ChamaUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    monthly_contribution: Optional[Decimal] = None
    welfare_contribution: Optional[Decimal] = None
    flat_interest_rate: Optional[Decimal] = None
    reducing_interest_rate: Optional[Decimal] = None
    default_interest_method: Optional[str] = None
    max_loan_multiplier: Optional[Decimal] = None
    late_penalty_rate: Optional[Decimal] = None
    mpesa_till: Optional[str] = None
    mpesa_paybill: Optional[str] = None
    next_meeting_date: Optional[date] = None
    meeting_venue: Optional[str] = None
    merry_go_round_amount: Optional[Decimal] = None
    merry_go_round_active: Optional[bool] = None


class ChamaOut(BaseResponse):
    id: str
    name: str
    description: Optional[str] = None
    county: Optional[str] = None
    monthly_contribution: Decimal
    welfare_contribution: Decimal
    registration_fee: Decimal
    flat_interest_rate: Decimal
    reducing_interest_rate: Decimal
    default_interest_method: str
    max_loan_multiplier: Decimal
    late_penalty_rate: Decimal
    mpesa_till: Optional[str] = None
    mpesa_paybill: Optional[str] = None
    next_meeting_date: Optional[date] = None
    meeting_venue: Optional[str] = None
    merry_go_round_active: bool
    merry_go_round_amount: Decimal
    is_active: bool
    logo_url: Optional[str] = None
    created_at: datetime
    member_count: Optional[int] = None
    total_savings: Optional[Decimal] = None
    total_active_loans: Optional[Decimal] = None


# ── Member ────────────────────────────────────────────────────────────────────

class AddMemberRequest(BaseModel):
    phone_number: str = Field(..., pattern=r"^(\+254|0)[17]\d{8}$")
    role: Optional[str] = "member"

    @field_validator("phone_number")
    @classmethod
    def normalise(cls, v: str) -> str:
        v = v.replace(" ", "").replace("-", "")
        if v.startswith("0"):
            return "+254" + v[1:]
        return v


class MemberOut(BaseResponse):
    id: str
    chama_id: str
    user_id: str
    full_name: str
    phone_number: str
    email: Optional[str] = None
    network: Optional[str] = None
    role: str
    member_number: Optional[str] = None
    joined_at: date
    is_active: bool
    is_defaulting: bool
    total_savings: Decimal
    total_contributed: Decimal
    active_loan_balance: Decimal
    profile_photo_url: Optional[str] = None


class UpdateMemberRoleRequest(BaseModel):
    role: str = Field(..., pattern=r"^(chairperson|treasurer|secretary|member)$")


# ── Contribution ──────────────────────────────────────────────────────────────

class ContributionCreate(BaseModel):
    member_id: str
    amount: Decimal = Field(..., gt=0)
    contribution_type: str = "regular_savings"
    period_month: int = Field(..., ge=1, le=12)
    period_year: int = Field(..., ge=2020, le=2100)
    due_date: date
    mpesa_ref: Optional[str] = None
    status: Optional[str] = "pending"
    notes: Optional[str] = None


class ContributionUpdate(BaseModel):
    status: Optional[str] = None
    mpesa_ref: Optional[str] = None
    paid_at: Optional[datetime] = None
    notes: Optional[str] = None


class ContributionOut(BaseResponse):
    id: str
    chama_id: str
    member_id: str
    member_name: Optional[str] = None
    amount: Decimal
    contribution_type: str
    status: str
    period_month: int
    period_year: int
    due_date: date
    paid_at: Optional[datetime] = None
    mpesa_ref: Optional[str] = None
    notes: Optional[str] = None
    created_at: datetime


class ContributionSummary(BaseModel):
    total_paid: Decimal
    total_pending: Decimal
    total_late: Decimal
    compliance_rate: float
    period_month: int
    period_year: int


# ── Loan ──────────────────────────────────────────────────────────────────────

class LoanCalculateRequest(BaseModel):
    principal: Decimal = Field(..., gt=0)
    repayment_months: int = Field(..., ge=1, le=120)
    interest_method: str = Field(..., pattern=r"^(flat_rate|reducing_balance)$")
    interest_rate: Optional[Decimal] = None


class LoanCalculateResponse(BaseModel):
    principal: Decimal
    interest_method: str
    interest_rate: Decimal
    repayment_months: int
    total_interest: Decimal
    total_repayable: Decimal
    monthly_installment: Decimal
    schedule: List[dict]


class LoanApplyRequest(BaseModel):
    member_id: str
    principal: Decimal = Field(..., gt=0)
    purpose: str = Field(..., min_length=5, max_length=300)
    repayment_months: int = Field(..., ge=1, le=120)
    interest_method: Optional[str] = None


class LoanApproveRequest(BaseModel):
    approved: bool
    rejection_reason: Optional[str] = None


class LoanRepayRequest(BaseModel):
    amount: Decimal = Field(..., gt=0)
    mpesa_ref: Optional[str] = None
    notes: Optional[str] = None


class LoanOut(BaseResponse):
    id: str
    chama_id: str
    member_id: str
    member_name: Optional[str] = None
    loan_number: str
    purpose: str
    principal: Decimal
    interest_method: str
    interest_rate: Decimal
    repayment_months: int
    monthly_installment: Decimal
    total_interest: Decimal
    total_repayable: Decimal
    status: str
    amount_repaid: Decimal
    outstanding_balance: Decimal
    penalties_accrued: Decimal
    applied_at: datetime
    disbursed_at: Optional[datetime] = None
    due_date: Optional[date] = None
    fully_repaid_at: Optional[datetime] = None
    days_remaining: Optional[int] = None


# ── Transaction / M-Pesa ──────────────────────────────────────────────────────

class STKPushRequest(BaseModel):
    phone_number: str = Field(..., pattern=r"^(\+254|0)[17]\d{8}$")
    amount: Decimal = Field(..., ge=1)
    purpose: str = Field(..., pattern=r"^(contribution|loan_repayment|welfare|registration)$")
    reference_id: Optional[str] = None
    description: Optional[str] = None

    @field_validator("phone_number")
    @classmethod
    def normalise(cls, v: str) -> str:
        v = v.replace(" ", "").replace("-", "")
        if v.startswith("0"):
            return "+254" + v[1:]
        return v


class STKPushResponse(BaseModel):
    checkout_request_id: str
    merchant_request_id: str
    response_code: str
    customer_message: str
    transaction_id: str


class TransactionOut(BaseResponse):
    id: str
    chama_id: str
    transaction_type: str
    status: str
    amount: Decimal
    phone_number: Optional[str] = None
    mpesa_ref: Optional[str] = None
    description: Optional[str] = None
    completed_at: Optional[datetime] = None
    created_at: datetime


# ── SMS ──────────────────────────────────────────────────────────────────────

class SMSReminderPreview(BaseModel):
    member_id: str
    member_name: str
    phone_number: str
    message: str
    amount: Decimal
    due_date: str
    reminder_type: str
    char_count: int


class SendSMSRequest(BaseModel):
    member_ids: List[str]
    message_override: Optional[str] = None


class SMSLogOut(BaseResponse):
    id: str
    recipient_phone: str
    recipient_name: Optional[str] = None
    message: str
    status: str
    sent_at: Optional[datetime] = None
    created_at: datetime


# ── Dashboard ─────────────────────────────────────────────────────────────────

class DashboardStats(BaseModel):
    total_savings: Decimal
    total_active_loans: Decimal
    pending_approvals: int
    active_members: int
    defaulting_members: int
    compliance_rate: float
    next_meeting_date: Optional[date] = None
    next_meeting_venue: Optional[str] = None
    days_to_meeting: Optional[int] = None
    savings_trend: List[dict]
    contribution_breakdown: dict


class MerryGoRoundSlotOut(BaseResponse):
    id: str
    chama_id: str
    member_id: str
    member_name: Optional[str] = None
    position: int
    payout_month: int
    cycle_year: int
    payout_amount: Decimal
    received: bool
    received_at: Optional[datetime] = None
