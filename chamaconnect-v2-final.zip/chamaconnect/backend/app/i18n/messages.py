"""
ChamaConnect — Bilingual Messages (English + Kiswahili)
All user-facing text goes through this module so the app works
for digitally illiterate members who understand Swahili better.
"""
from typing import Literal

Language = Literal["en", "sw"]

MESSAGES = {
    # ── Auth ───────────────────────────────────────────────────────────────────
    "welcome": {
        "en": "Welcome to ChamaConnect",
        "sw": "Karibu ChamaConnect",
    },
    "login_success": {
        "en": "Login successful",
        "sw": "Umeingia kikamilifu",
    },
    "login_failed": {
        "en": "Wrong phone number or password",
        "sw": "Nambari ya simu au nenosiri si sahihi",
    },
    "account_suspended": {
        "en": "Your account has been suspended. Contact your Chairperson.",
        "sw": "Akaunti yako imesimamishwa. Wasiliana na Mwenyekiti wako.",
    },
    "pin_correct": {
        "en": "PIN verified successfully",
        "sw": "PIN imethibitishwa",
    },
    "pin_wrong": {
        "en": "Wrong PIN. {remaining} attempts remaining.",
        "sw": "PIN si sahihi. Majaribio {remaining} yaliyobaki.",
    },
    "pin_locked": {
        "en": "PIN locked for {minutes} minutes after too many wrong attempts.",
        "sw": "PIN imefungwa kwa dakika {minutes} kwa sababu ya majaribio mengi mabaya.",
    },
    "pin_set": {
        "en": "PIN set successfully",
        "sw": "PIN imewekwa kikamilifu",
    },
    "pin_reset_sent": {
        "en": "A reset code has been sent to your M-Pesa number",
        "sw": "Nambari ya kubadilisha imepelekwa kwa nambari yako ya M-Pesa",
    },
    "pin_reset_done": {
        "en": "PIN has been reset successfully",
        "sw": "PIN imebadilishwa kikamilifu",
    },
    "pin_reset_expired": {
        "en": "Reset code has expired. Please request a new one.",
        "sw": "Nambari ya kubadilisha imeisha muda. Omba nambari mpya.",
    },
    "pin_reset_wrong": {
        "en": "Wrong reset code",
        "sw": "Nambari ya kubadilisha si sahihi",
    },
    "registered": {
        "en": "Account created successfully! Welcome to ChamaConnect.",
        "sw": "Akaunti imeundwa! Karibu ChamaConnect.",
    },
    "phone_exists": {
        "en": "This phone number is already registered",
        "sw": "Nambari hii ya simu tayari imesajiliwa",
    },
    # ── Contributions ─────────────────────────────────────────────────────────
    "contribution_logged": {
        "en": "Payment of KES {amount} recorded for {name}",
        "sw": "Malipo ya KES {amount} yameandikwa kwa {name}",
    },
    "contribution_late": {
        "en": "Payment is overdue since {date}. A penalty of {penalty}% per month applies.",
        "sw": "Malipo yamechelewa tangu {date}. Faini ya {penalty}% kwa mwezi inatumika.",
    },
    # ── Loans ─────────────────────────────────────────────────────────────────
    "loan_applied": {
        "en": "Loan application submitted. Awaiting approval from Chairperson or Treasurer.",
        "sw": "Ombi la mkopo limewasilishwa. Linasubiri idhini ya Mwenyekiti au Mweka Hazina.",
    },
    "loan_approved": {
        "en": "Your loan of KES {amount} has been approved! Funds will be sent to your M-Pesa.",
        "sw": "Mkopo wako wa KES {amount} umeidhinishwa! Pesa itapelekwa kwa M-Pesa yako.",
    },
    "loan_rejected": {
        "en": "Your loan application was not approved. Reason: {reason}",
        "sw": "Ombi lako la mkopo halijakubaliwa. Sababu: {reason}",
    },
    "loan_exceeded_limit": {
        "en": "Loan amount exceeds your limit of KES {limit} (3× your savings of KES {savings})",
        "sw": "Mkopo unazidi kikomo chako cha KES {limit} (mara 3 ya akiba yako ya KES {savings})",
    },
    "loan_existing": {
        "en": "You already have an active loan. Repay it first before applying for a new one.",
        "sw": "Una mkopo unaoendelea. Ulipe kwanza kabla ya kuomba mpya.",
    },
    "loan_repayment_recorded": {
        "en": "Repayment of KES {amount} recorded. Balance remaining: KES {balance}",
        "sw": "Malipo ya mkopo ya KES {amount} yameandikwa. Salio lililobaki: KES {balance}",
    },
    "loan_repaid": {
        "en": "Congratulations! Your loan has been fully repaid. 🎉",
        "sw": "Hongera! Mkopo wako umelipwa kikamilifu. 🎉",
    },
    # ── M-Pesa ────────────────────────────────────────────────────────────────
    "mpesa_prompt_sent": {
        "en": "Check your phone {phone} — enter your M-Pesa PIN to complete payment",
        "sw": "Angalia simu yako {phone} — weka PIN yako ya M-Pesa kukamilisha malipo",
    },
    "mpesa_success": {
        "en": "M-Pesa payment of KES {amount} received! Ref: {ref}",
        "sw": "Malipo ya M-Pesa ya KES {amount} yamepokelewa! Kumbukumbu: {ref}",
    },
    "mpesa_failed": {
        "en": "M-Pesa payment failed. Please try again or pay via Till {till}",
        "sw": "Malipo ya M-Pesa hayakufanikiwa. Jaribu tena au lipa kupitia Till {till}",
    },
    "mpesa_cancelled": {
        "en": "You cancelled the M-Pesa payment. No charges made.",
        "sw": "Umeghairi malipo ya M-Pesa. Hakuna malipo yaliyofanywa.",
    },
    # ── SMS Reminders ─────────────────────────────────────────────────────────
    "sms_late_contribution": {
        "en": "Habari {name}, ukumbusho kutoka {chama}: Mchango wako wa KES {amount} ulipaswa kulipwa {date}. Tafadhali lipa kupitia M-Pesa Till {till} ili kuepuka faini.",
        "sw": "Habari {name}, ukumbusho kutoka {chama}: Mchango wako wa KES {amount} ulipaswa kulipwa {date}. Tafadhali lipa kupitia M-Pesa Till {till} ili kuepuka faini.",
    },
    "sms_loan_due": {
        "en": "Habari {name}, mkopo wako wa KES {installment} kutoka {chama} unastahili {date}. Lipa kupitia M-Pesa Till {till}. Salio: KES {balance}.",
        "sw": "Habari {name}, mkopo wako wa KES {installment} kutoka {chama} unastahili {date}. Lipa kupitia M-Pesa Till {till}. Salio: KES {balance}.",
    },
    "sms_loan_approved": {
        "en": "Habari {name}, mkopo wako wa KES {amount} kutoka {chama} umeidhinishwa! Pesa itawasilishwa kwa M-Pesa yako {phone} hivi karibuni.",
        "sw": "Habari {name}, mkopo wako wa KES {amount} kutoka {chama} umeidhinishwa! Pesa itawasilishwa kwa M-Pesa yako {phone} hivi karibuni.",
    },
    "sms_meeting_reminder": {
        "en": "Habari {name}, mkutano wa {chama} ni {date} saa {time} mahali {venue}. Tafadhali jihakikishe unahudhuria.",
        "sw": "Habari {name}, mkutano wa {chama} ni {date} saa {time} mahali {venue}. Tafadhali jihakikishe unahudhuria.",
    },
    "sms_contribution_reminder": {
        "en": "Habari {name}, mchango wa mwezi huu wa KES {amount} kwa {chama} unastahili {date}. Lipa mapema kupitia M-Pesa Till {till}.",
        "sw": "Habari {name}, mchango wa mwezi huu wa KES {amount} kwa {chama} unastahili {date}. Lipa mapema kupitia M-Pesa Till {till}.",
    },
    "sms_welcome": {
        "en": "Karibu {chama}! Umesajiliwa kama mwanachama. Nambari yako ya mwanachama: {number}. Wasiliana na Mwenyekiti kwa maswali.",
        "sw": "Karibu {chama}! Umesajiliwa kama mwanachama. Nambari yako ya mwanachama: {number}. Wasiliana na Mwenyekiti kwa maswali.",
    },
    # ── General errors ────────────────────────────────────────────────────────
    "not_found": {
        "en": "Record not found",
        "sw": "Rekodi haikupatikana",
    },
    "not_member": {
        "en": "You are not a member of this chama",
        "sw": "Wewe si mwanachama wa chama hiki",
    },
    "permission_denied": {
        "en": "You do not have permission to do this. Only Chairperson or Treasurer can.",
        "sw": "Huna ruhusa ya kufanya hivi. Mwenyekiti au Mweka Hazina tu anaweza.",
    },
    "server_error": {
        "en": "Something went wrong. Please try again.",
        "sw": "Kuna tatizo. Tafadhali jaribu tena.",
    },
}


def t(key: str, lang: Language = "sw", **kwargs) -> str:
    """
    Translate a message key.
    Defaults to Swahili — most Kenyan chama members speak Swahili.
    Falls back to English if key not found in Swahili.
    """
    msg_dict = MESSAGES.get(key, {})
    text = msg_dict.get(lang) or msg_dict.get("en") or key
    if kwargs:
        try:
            text = text.format(**kwargs)
        except KeyError:
            pass
    return text
