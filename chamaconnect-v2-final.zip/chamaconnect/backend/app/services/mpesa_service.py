"""
M-Pesa Daraja API v2 Service
Covers:
- STK Push (C2B) — member pays chama
- B2C — chama pays member (loan disbursement)
- Callback handler with signature verification
- Standing order simulation for auto-deductions

Works in sandbox mode out of the box.
Switch MPESA_ENV=production in .env for live payments.
"""
import base64
import random
import string
from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import verify_mpesa_callback
from app.models.models import (
    Chama, Transaction, TransactionType, TransactionStatus
)


def _generate_mock_ref() -> str:
    chars = "ABCDEFGHJKLMNPQRSTUVWXYZ0123456789"
    return "".join(random.choices(chars, k=10))


def _get_password_and_timestamp() -> tuple[str, str]:
    ts = datetime.now().strftime("%Y%m%d%H%M%S")
    raw = settings.MPESA_SHORTCODE + settings.MPESA_PASSKEY + ts
    password = base64.b64encode(raw.encode()).decode()
    return password, ts


async def _get_access_token() -> str:
    """Get OAuth token from Safaricom. Cached in production via Redis."""
    credentials = base64.b64encode(
        f"{settings.MPESA_CONSUMER_KEY}:{settings.MPESA_CONSUMER_SECRET}".encode()
    ).decode()

    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.get(
            f"{settings.mpesa_base_url}/oauth/v1/generate?grant_type=client_credentials",
            headers={"Authorization": f"Basic {credentials}"},
        )
        resp.raise_for_status()
        return resp.json()["access_token"]


async def stk_push(
    db: AsyncSession,
    chama_id: str,
    phone: str,
    amount: Decimal,
    description: str,
    purpose: str,
    reference_id: Optional[str] = None,
    user_id: Optional[str] = None,
) -> Transaction:
    """
    Initiate an STK Push (Lipa na M-Pesa).
    Sends a payment prompt directly to the member's phone.
    They see: "ChamaConnect requests KES X from you. Enter PIN to confirm."
    """
    # Normalize phone: 0712345678 → 254712345678
    phone_normalized = phone.replace("+", "").replace(" ", "")
    if phone_normalized.startswith("0"):
        phone_normalized = "254" + phone_normalized[1:]

    # Record transaction first (so we can track even if network fails)
    txn = Transaction(
        chama_id=chama_id,
        user_id=user_id,
        transaction_type=TransactionType.MPESA_STK,
        status=TransactionStatus.INITIATED,
        amount=amount,
        phone_number=phone,
        description=description,
        extra_data={"purpose": purpose, "reference_id": reference_id},
    )
    db.add(txn)
    await db.flush()

    # Sandbox / no credentials → simulate success immediately
    if settings.MPESA_ENV == "sandbox" or not settings.MPESA_CONSUMER_KEY:
        txn.mpesa_checkout_request_id = "ws_CO_" + "".join(
            random.choices(string.digits, k=16)
        )
        txn.mpesa_merchant_request_id = "MR_" + "".join(
            random.choices(string.digits, k=10)
        )
        txn.status = TransactionStatus.PENDING
        return txn

    # Real Safaricom API
    try:
        password, timestamp = _get_password_and_timestamp()
        token = await _get_access_token()

        payload = {
            "BusinessShortCode": settings.MPESA_SHORTCODE,
            "Password": password,
            "Timestamp": timestamp,
            "TransactionType": "CustomerPayBillOnline",
            "Amount": int(amount),
            "PartyA": phone_normalized,
            "PartyB": settings.MPESA_SHORTCODE,
            "PhoneNumber": phone_normalized,
            "CallBackURL": settings.MPESA_CALLBACK_URL,
            "AccountReference": reference_id or "ChamaConnect",
            "TransactionDesc": description[:13],
        }

        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(
                f"{settings.mpesa_base_url}/mpesa/stkpush/v1/processrequest",
                json=payload,
                headers={"Authorization": f"Bearer {token}"},
            )
            data = resp.json()

        txn.mpesa_checkout_request_id = data.get("CheckoutRequestID")
        txn.mpesa_merchant_request_id = data.get("MerchantRequestID")
        txn.mpesa_raw_response = data
        txn.status = (
            TransactionStatus.PENDING
            if data.get("ResponseCode") == "0"
            else TransactionStatus.FAILED
        )

    except Exception as e:
        txn.status = TransactionStatus.FAILED
        txn.mpesa_raw_response = {"error": str(e)}

    return txn


async def handle_stk_callback(
    db: AsyncSession,
    payload: dict,
) -> Optional[Transaction]:
    """
    Process M-Pesa STK callback from Safaricom.
    Verifies signature, updates transaction, triggers ledger update.
    """
    # Verify the callback is genuine
    if not verify_mpesa_callback(payload):
        return None

    body = payload.get("Body", {}).get("stkCallback", {})
    checkout_id = body.get("CheckoutRequestID")

    result = await db.execute(
        select(Transaction).where(
            Transaction.mpesa_checkout_request_id == checkout_id
        )
    )
    txn = result.scalar_one_or_none()
    if not txn:
        return None

    txn.mpesa_raw_response = payload
    result_code = body.get("ResultCode")

    if result_code == 0:
        # Payment successful
        items = {
            item["Name"]: item.get("Value")
            for item in body.get("CallbackMetadata", {}).get("Item", [])
        }
        txn.mpesa_ref = items.get("MpesaReceiptNumber")
        txn.mpesa_receipt_number = items.get("MpesaReceiptNumber")
        txn.status = TransactionStatus.SUCCESS
        txn.completed_at = datetime.now(timezone.utc)
    else:
        txn.status = TransactionStatus.FAILED

    await db.flush()
    return txn


async def simulate_stk_success(
    db: AsyncSession,
    transaction_id: str,
) -> Optional[Transaction]:
    """
    For sandbox/demo: simulate a successful M-Pesa payment.
    In production this is triggered by Safaricom's callback.
    """
    txn = await db.get(Transaction, transaction_id)
    if not txn or txn.status != TransactionStatus.PENDING:
        return None

    txn.mpesa_ref = _generate_mock_ref()
    txn.mpesa_receipt_number = txn.mpesa_ref
    txn.status = TransactionStatus.SUCCESS
    txn.completed_at = datetime.now(timezone.utc)
    await db.flush()
    return txn


async def b2c_payment(
    db: AsyncSession,
    chama_id: str,
    phone: str,
    amount: Decimal,
    occasion: str,
    remarks: str,
    user_id: Optional[str] = None,
) -> Transaction:
    """
    B2C — Chama pays a member directly (loan disbursement, MGR payout).
    Requires special B2C credentials from Safaricom.
    Simulated in sandbox.
    """
    phone_normalized = phone.replace("+", "").replace(" ", "")
    if phone_normalized.startswith("0"):
        phone_normalized = "254" + phone_normalized[1:]

    txn = Transaction(
        chama_id=chama_id,
        user_id=user_id,
        transaction_type=TransactionType.MPESA_PAYBILL,
        status=TransactionStatus.INITIATED,
        amount=amount,
        phone_number=phone,
        description=f"B2C: {remarks}",
        extra_data={"occasion": occasion, "type": "b2c"},
    )
    db.add(txn)
    await db.flush()

    # Always simulate in sandbox
    if settings.MPESA_ENV != "production" or not settings.MPESA_CONSUMER_KEY:
        txn.mpesa_ref = _generate_mock_ref()
        txn.status = TransactionStatus.SUCCESS
        txn.completed_at = datetime.now(timezone.utc)
        return txn

    # Real B2C API call
    try:
        token = await _get_access_token()
        payload = {
            "InitiatorName": "ChamaConnectAPI",
            "SecurityCredential": "",  # encrypted in production
            "CommandID": "BusinessPayment",
            "Amount": int(amount),
            "PartyA": settings.MPESA_SHORTCODE,
            "PartyB": phone_normalized,
            "Remarks": remarks[:100],
            "QueueTimeOutURL": f"{settings.MPESA_CALLBACK_URL}/timeout",
            "ResultURL": f"{settings.MPESA_CALLBACK_URL}/b2c",
            "Occasion": occasion[:100],
        }
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(
                f"{settings.mpesa_base_url}/mpesa/b2c/v3/paymentrequest",
                json=payload,
                headers={"Authorization": f"Bearer {token}"},
            )
            data = resp.json()
        txn.mpesa_raw_response = data
        txn.status = (
            TransactionStatus.PENDING
            if data.get("ResponseCode") == "0"
            else TransactionStatus.FAILED
        )
    except Exception as e:
        txn.status = TransactionStatus.FAILED
        txn.mpesa_raw_response = {"error": str(e)}

    return txn
