"""
Loan service — interest calculation engines, application, approval, repayment.
Implements both Flat Rate and Reducing Balance methods.
"""
from datetime import date, datetime, timezone, timedelta
from decimal import Decimal, ROUND_HALF_UP
from typing import List, Optional
import random
import string

from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import (
    Loan, LoanRepayment, ChamaMember, Chama,
    LoanStatus, InterestMethod
)
from app.schemas.schemas import (
    LoanCalculateRequest, LoanCalculateResponse,
    LoanApplyRequest, LoanRepayRequest
)


def _round(value: Decimal, places: int = 2) -> Decimal:
    return value.quantize(Decimal(10) ** -places, rounding=ROUND_HALF_UP)


# ─── Interest Calculation Engines ────────────────────────────────────────────

def calculate_flat_rate(
    principal: Decimal,
    annual_rate: Decimal,
    months: int,
) -> dict:
    """
    Flat Rate Method:
    Interest = Principal × Rate × (months / 12)
    Monthly instalment = (Principal + Total Interest) / months
    """
    total_interest = _round(principal * annual_rate * Decimal(months) / Decimal(12))
    total_repayable = _round(principal + total_interest)
    monthly_installment = _round(total_repayable / Decimal(months))

    schedule = []
    balance = principal
    for m in range(1, months + 1):
        interest_portion = _round(total_interest / Decimal(months))
        principal_portion = _round(monthly_installment - interest_portion)
        balance = _round(balance - principal_portion)
        schedule.append({
            "month": m,
            "payment": float(monthly_installment),
            "principal_portion": float(principal_portion),
            "interest_portion": float(interest_portion),
            "balance": float(max(balance, Decimal("0"))),
        })

    return {
        "total_interest": total_interest,
        "total_repayable": total_repayable,
        "monthly_installment": monthly_installment,
        "schedule": schedule,
    }


def calculate_reducing_balance(
    principal: Decimal,
    annual_rate: Decimal,
    months: int,
) -> dict:
    """
    Reducing Balance (Amortisation) Method:
    Monthly rate = annual_rate / 12
    EMI = P × r × (1 + r)^n / ((1 + r)^n − 1)
    Interest recalculated on outstanding balance each month.
    """
    monthly_rate = annual_rate / Decimal(12)
    factor = (1 + monthly_rate) ** months
    monthly_installment = _round(principal * monthly_rate * factor / (factor - 1))

    schedule = []
    balance = principal
    total_interest = Decimal("0")
    for m in range(1, months + 1):
        interest_portion = _round(balance * monthly_rate)
        principal_portion = _round(monthly_installment - interest_portion)
        if m == months:
            # Last payment — clear rounding residual
            principal_portion = balance
            monthly_installment = _round(principal_portion + interest_portion)
        balance = _round(balance - principal_portion)
        total_interest += interest_portion
        schedule.append({
            "month": m,
            "payment": float(monthly_installment),
            "principal_portion": float(principal_portion),
            "interest_portion": float(interest_portion),
            "balance": float(max(balance, Decimal("0"))),
        })

    return {
        "total_interest": _round(total_interest),
        "total_repayable": _round(principal + total_interest),
        "monthly_installment": monthly_installment,
        "schedule": schedule,
    }


def calculate_loan(
    principal: Decimal,
    annual_rate: Decimal,
    months: int,
    method: InterestMethod,
) -> dict:
    if method == InterestMethod.FLAT_RATE:
        return calculate_flat_rate(principal, annual_rate, months)
    return calculate_reducing_balance(principal, annual_rate, months)


def generate_loan_number() -> str:
    ts = datetime.now().strftime("%y%m%d")
    suffix = "".join(random.choices(string.ascii_uppercase + string.digits, k=5))
    return f"LN{ts}{suffix}"


# ─── Service ─────────────────────────────────────────────────────────────────

class LoanService:

    @staticmethod
    async def calculate(
        db: AsyncSession,
        chama_id: str,
        req: LoanCalculateRequest,
    ) -> LoanCalculateResponse:
        chama = await db.get(Chama, chama_id)
        method = InterestMethod(req.interest_method)
        rate = req.interest_rate
        if rate is None:
            rate = (
                chama.flat_interest_rate
                if method == InterestMethod.FLAT_RATE
                else chama.reducing_interest_rate
            )
        result = calculate_loan(req.principal, rate, req.repayment_months, method)
        return LoanCalculateResponse(
            principal=req.principal,
            interest_method=method.value,
            interest_rate=rate,
            repayment_months=req.repayment_months,
            **result,
        )

    @staticmethod
    async def apply(
        db: AsyncSession,
        chama_id: str,
        req: LoanApplyRequest,
        applicant_user_id: str,
    ) -> Loan:
        chama = await db.get(Chama, chama_id)
        member = await db.get(ChamaMember, req.member_id)

        dm = chama.default_interest_method
        dm_str = dm.value if hasattr(dm, "value") else str(dm)
        method = InterestMethod(req.interest_method or dm_str)
        rate = (
            chama.flat_interest_rate
            if method == InterestMethod.FLAT_RATE
            else chama.reducing_interest_rate
        )

        # Eligibility: outstanding balance check
        if member.active_loan_balance > 0:
            raise ValueError("Member already has an active loan")

        # Max loan = savings × multiplier
        max_amount = _round(member.total_savings * chama.max_loan_multiplier)
        if req.principal > max_amount:
            raise ValueError(
                f"Loan amount KES {req.principal:,.0f} exceeds maximum "
                f"KES {max_amount:,.0f} (3× your savings)"
            )

        calc = calculate_loan(req.principal, rate, req.repayment_months, method)

        loan = Loan(
            chama_id=chama_id,
            member_id=req.member_id,
            loan_number=generate_loan_number(),
            purpose=req.purpose,
            principal=req.principal,
            interest_method=method,
            interest_rate=rate,
            repayment_months=req.repayment_months,
            monthly_installment=calc["monthly_installment"],
            total_interest=calc["total_interest"],
            total_repayable=calc["total_repayable"],
            outstanding_balance=req.principal,
            status=LoanStatus.PENDING,
        )
        db.add(loan)
        await db.flush()
        return loan

    @staticmethod
    async def approve(
        db: AsyncSession,
        loan_id: str,
        approver_user_id: str,
        approved: bool,
        rejection_reason: Optional[str] = None,
    ) -> Loan:
        loan = await db.get(Loan, loan_id)
        if loan.status != LoanStatus.PENDING:
            raise ValueError("Loan is not in pending state")

        if approved:
            loan.status = LoanStatus.DISBURSED
            loan.approved_by_id = approver_user_id
            loan.approved_at = datetime.now(timezone.utc)
            loan.disbursed_at = datetime.now(timezone.utc)
            loan.first_repayment_date = date.today().replace(day=1) + timedelta(days=32)
            loan.first_repayment_date = loan.first_repayment_date.replace(day=1)
            loan.due_date = date.today() + timedelta(days=30 * loan.repayment_months)

            # Update member's active loan balance
            member = await db.get(ChamaMember, loan.member_id)
            member.active_loan_balance += loan.principal
        else:
            loan.status = LoanStatus.REJECTED
            loan.rejection_reason = rejection_reason

        await db.flush()
        return loan

    @staticmethod
    async def repay(
        db: AsyncSession,
        loan_id: str,
        req: LoanRepayRequest,
    ) -> LoanRepayment:
        loan = await db.get(Loan, loan_id)
        if loan.status not in (LoanStatus.DISBURSED, LoanStatus.ACTIVE):
            raise ValueError("Loan is not active")

        loan.status = LoanStatus.ACTIVE

        # Determine interest vs principal split for this payment
        if loan.interest_method == InterestMethod.FLAT_RATE:
            interest_per_month = _round(loan.total_interest / Decimal(loan.repayment_months))
            interest_portion = min(interest_per_month, req.amount)
            principal_portion = _round(req.amount - interest_portion)
        else:
            monthly_rate = loan.interest_rate / Decimal(12)
            interest_portion = _round(loan.outstanding_balance * monthly_rate)
            principal_portion = _round(req.amount - interest_portion)

        penalty_portion = Decimal("0")
        if loan.due_date and date.today() > loan.due_date:
            months_late = max(1, (date.today() - loan.due_date).days // 30)
            penalty_portion = _round(
                loan.outstanding_balance * Decimal("0.02") * months_late
            )

        repayment = LoanRepayment(
            loan_id=loan_id,
            amount=req.amount,
            principal_portion=principal_portion,
            interest_portion=interest_portion,
            penalty_portion=penalty_portion,
            mpesa_ref=req.mpesa_ref,
            notes=req.notes,
        )
        db.add(repayment)

        loan.amount_repaid += req.amount
        loan.outstanding_balance = max(
            Decimal("0"),
            _round(loan.outstanding_balance - principal_portion),
        )

        if loan.outstanding_balance <= 0:
            loan.status = LoanStatus.FULLY_REPAID
            loan.fully_repaid_at = datetime.now(timezone.utc)
            member = await db.get(ChamaMember, loan.member_id)
            member.active_loan_balance = max(
                Decimal("0"),
                member.active_loan_balance - loan.principal,
            )

        await db.flush()
        return repayment

    @staticmethod
    async def get_active_loans(
        db: AsyncSession,
        chama_id: str,
        skip: int = 0,
        limit: int = 50,
    ) -> List[Loan]:
        result = await db.execute(
            select(Loan)
            .where(
                Loan.chama_id == chama_id,
                Loan.status.in_([LoanStatus.DISBURSED, LoanStatus.ACTIVE]),
            )
            .order_by(Loan.applied_at.desc())
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all()

    @staticmethod
    async def get_pending_loans(
        db: AsyncSession,
        chama_id: str,
    ) -> List[Loan]:
        result = await db.execute(
            select(Loan)
            .where(Loan.chama_id == chama_id, Loan.status == LoanStatus.PENDING)
            .order_by(Loan.applied_at.asc())
        )
        return result.scalars().all()
