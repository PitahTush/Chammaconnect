"""
SMS Service — Africa's Talking gateway with Swahili templates.
All messages sent in Swahili by default (Kenya's lingua franca).
"""
from datetime import date, datetime, timezone
from decimal import Decimal
from typing import List, Optional

from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.i18n.messages import t
from app.models.models import (
    Chama, ChamaMember, Contribution, Loan, SMSLog, User,
    ContributionStatus, LoanStatus, SMSStatus,
)


async def _log_and_send(
    db: AsyncSession,
    chama_id: str,
    phone: str,
    name: str,
    message: str,
    triggered_by_id: Optional[str] = None,
) -> SMSLog:
    """Log SMS then dispatch via Africa's Talking gateway."""
    log = SMSLog(
        chama_id=chama_id,
        recipient_phone=phone,
        recipient_name=name,
        message=message,
        status=SMSStatus.PENDING,
        triggered_by_id=triggered_by_id,
    )
    db.add(log)
    await db.flush()

    if not settings.SMS_ENABLED:
        # Mock delivery — works offline, no cost
        log.status = SMSStatus.SENT
        log.sent_at = datetime.now(timezone.utc)
        log.gateway_ref = f"MOCK-{log.id[:8].upper()}"
        return log

    try:
        import africastalking
        africastalking.initialize(settings.AT_USERNAME, settings.AT_API_KEY)
        sms_client = africastalking.SMS
        response = sms_client.send(message, [phone], settings.AT_SENDER_ID)
        recipients = response.get("SMSMessageData", {}).get("Recipients", [])
        if recipients and recipients[0].get("statusCode") == 101:
            log.status = SMSStatus.SENT
            log.gateway_ref = recipients[0].get("messageId", "")
        else:
            log.status = SMSStatus.FAILED
            log.error = str(response)
    except Exception as e:
        log.status = SMSStatus.FAILED
        log.error = str(e)

    log.sent_at = datetime.now(timezone.utc)
    return log


async def send_welcome_sms(
    db: AsyncSession,
    chama: Chama,
    user: User,
    member_number: str,
) -> SMSLog:
    """Sent when a member joins the chama."""
    message = t(
        "sms_welcome",
        name=user.full_name.split()[0],
        chama=chama.name,
        number=member_number,
    )
    return await _log_and_send(
        db, chama.id, user.phone_number, user.full_name, message
    )


async def send_loan_approved_sms(
    db: AsyncSession,
    chama: Chama,
    user: User,
    amount: Decimal,
) -> SMSLog:
    message = t(
        "sms_loan_approved",
        name=user.full_name.split()[0],
        chama=chama.name,
        amount=f"{amount:,.0f}",
        phone=user.phone_number,
    )
    return await _log_and_send(
        db, chama.id, user.phone_number, user.full_name, message
    )


async def send_contribution_reminder_sms(
    db: AsyncSession,
    chama: Chama,
    user: User,
    amount: Decimal,
    due_date: str,
) -> SMSLog:
    message = t(
        "sms_contribution_reminder",
        name=user.full_name.split()[0],
        chama=chama.name,
        amount=f"{amount:,.0f}",
        date=due_date,
        till=chama.mpesa_till or "N/A",
    )
    return await _log_and_send(
        db, chama.id, user.phone_number, user.full_name, message
    )


async def send_late_contribution_sms(
    db: AsyncSession,
    chama: Chama,
    user: User,
    amount: Decimal,
    due_date: str,
) -> SMSLog:
    message = t(
        "sms_late_contribution",
        name=user.full_name.split()[0],
        chama=chama.name,
        amount=f"{amount:,.0f}",
        date=due_date,
        till=chama.mpesa_till or "N/A",
    )
    return await _log_and_send(
        db, chama.id, user.phone_number, user.full_name, message
    )


async def send_loan_due_sms(
    db: AsyncSession,
    chama: Chama,
    user: User,
    installment: Decimal,
    balance: Decimal,
    due_date: str,
) -> SMSLog:
    message = t(
        "sms_loan_due",
        name=user.full_name.split()[0],
        chama=chama.name,
        installment=f"{installment:,.0f}",
        date=due_date,
        till=chama.mpesa_till or "N/A",
        balance=f"{balance:,.0f}",
    )
    return await _log_and_send(
        db, chama.id, user.phone_number, user.full_name, message
    )


async def send_meeting_reminder_sms(
    db: AsyncSession,
    chama: Chama,
    user: User,
    meeting_date: str,
    meeting_time: str,
    venue: str,
) -> SMSLog:
    message = t(
        "sms_meeting_reminder",
        name=user.full_name.split()[0],
        chama=chama.name,
        date=meeting_date,
        time=meeting_time,
        venue=venue,
    )
    return await _log_and_send(
        db, chama.id, user.phone_number, user.full_name, message
    )


async def generate_late_reminders(
    db: AsyncSession,
    chama_id: str,
) -> List[dict]:
    """
    Scan ledger for late/pending contributions and overdue loans.
    Returns preview list — admin reviews before sending.
    """
    chama = await db.get(Chama, chama_id)
    till = chama.mpesa_till or chama.mpesa_paybill or "N/A"
    reminders = []

    # Late contributions
    contrib_result = await db.execute(
        select(Contribution, ChamaMember, User)
        .join(ChamaMember, Contribution.member_id == ChamaMember.id)
        .join(User, ChamaMember.user_id == User.id)
        .where(
            Contribution.chama_id == chama_id,
            Contribution.status.in_([
                ContributionStatus.LATE,
                ContributionStatus.PENDING,
            ]),
            ChamaMember.is_active == True,
        )
        .order_by(Contribution.due_date)
    )
    for contrib, member, user in contrib_result.all():
        msg = t(
            "sms_late_contribution",
            name=user.full_name.split()[0],
            chama=chama.name,
            amount=f"{contrib.amount:,.0f}",
            date=str(contrib.due_date),
            till=till,
        )
        reminders.append({
            "member_id": member.id,
            "member_name": user.full_name,
            "phone_number": user.phone_number,
            "message": msg,
            "amount": float(contrib.amount),
            "due_date": str(contrib.due_date),
            "reminder_type": "contribution",
            "char_count": len(msg),
        })

    # Overdue loans
    loan_result = await db.execute(
        select(Loan, ChamaMember, User)
        .join(ChamaMember, Loan.member_id == ChamaMember.id)
        .join(User, ChamaMember.user_id == User.id)
        .where(
            Loan.chama_id == chama_id,
            Loan.status == LoanStatus.ACTIVE,
            Loan.due_date < date.today(),
        )
    )
    for loan, member, user in loan_result.all():
        msg = t(
            "sms_loan_due",
            name=user.full_name.split()[0],
            chama=chama.name,
            installment=f"{loan.monthly_installment:,.0f}",
            date=str(loan.due_date),
            till=till,
            balance=f"{loan.outstanding_balance:,.0f}",
        )
        reminders.append({
            "member_id": member.id,
            "member_name": user.full_name,
            "phone_number": user.phone_number,
            "message": msg,
            "amount": float(loan.monthly_installment),
            "due_date": str(loan.due_date),
            "reminder_type": "loan_repayment",
            "char_count": len(msg),
        })

    return reminders
