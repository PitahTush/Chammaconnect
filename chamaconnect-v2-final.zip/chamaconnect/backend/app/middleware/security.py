"""
Security middleware:
- Rate limiting (slowapi)
- Security headers (HSTS, CSP, X-Frame-Options)
- Request ID tracking
- Sensitive data scrubbing from logs
"""
import time
import uuid
from typing import Callable

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Add security headers to every response."""

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        response = await call_next(request)

        # Prevent clickjacking
        response.headers["X-Frame-Options"] = "DENY"
        # Prevent MIME sniffing
        response.headers["X-Content-Type-Options"] = "nosniff"
        # XSS protection
        response.headers["X-XSS-Protection"] = "1; mode=block"
        # Referrer policy
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        # Content Security Policy — API only serves JSON
        response.headers["Content-Security-Policy"] = "default-src 'none'"
        # Remove server fingerprint
        if "server" in response.headers:
            del response.headers["server"]
        if "x-powered-by" in response.headers:
            del response.headers["x-powered-by"]

        return response


class RequestIDMiddleware(BaseHTTPMiddleware):
    """Attach a unique request ID to every request for tracing."""

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        request_id = str(uuid.uuid4())[:8]
        request.state.request_id = request_id
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response


class RequestTimingMiddleware(BaseHTTPMiddleware):
    """Log request duration. Helps spot slow queries."""

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        start = time.perf_counter()
        response = await call_next(request)
        duration_ms = round((time.perf_counter() - start) * 1000, 1)
        response.headers["X-Process-Time-Ms"] = str(duration_ms)
        return response


class BlockSuspiciousRequestsMiddleware(BaseHTTPMiddleware):
    """
    Block requests with suspicious patterns.
    Protects against SQL injection and path traversal attempts in URLs.
    """
    BLOCKED_PATTERNS = [
        "../", "..\\", "<script", "javascript:",
        "union select", "drop table", "'; --",
        "/etc/passwd", "/etc/shadow",
    ]

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        url_lower = str(request.url).lower()
        for pattern in self.BLOCKED_PATTERNS:
            if pattern in url_lower:
                return JSONResponse(
                    status_code=400,
                    content={"detail": "Invalid request"},
                )
        return await call_next(request)
