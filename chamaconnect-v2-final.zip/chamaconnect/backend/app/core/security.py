"""
Security utilities — JWT, PIN/password hashing, OTP, signature verification.
Uses bcrypt directly for maximum compatibility.
"""
import hashlib
import hmac
import random
import string
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

import bcrypt
import uuid
from jose import JWTError, jwt

from app.core.config import settings


# ── Hashing ───────────────────────────────────────────────────────────────────

def hash_secret(secret: str) -> str:
    """Hash a password or PIN with bcrypt (rounds=12)."""
    salt = bcrypt.gensalt(rounds=12)
    return bcrypt.hashpw(secret.encode("utf-8"), salt).decode("utf-8")


def verify_secret(plain: str, hashed: str) -> bool:
    """Constant-time bcrypt verification."""
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False


def generate_reset_code(length: int = 6) -> str:
    """Cryptographically secure numeric OTP."""
    return "".join(random.SystemRandom().choices(string.digits, k=length))


def generate_token_hash(token: str) -> str:
    """SHA-256 of a token — safe to store in DB."""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def constant_time_compare(a: str, b: str) -> bool:
    """Timing-safe string comparison."""
    return hmac.compare_digest(a.encode(), b.encode())


def validate_password_strength(password: str) -> tuple[bool, str]:
    """Returns (is_valid, error_message)."""
    if len(password) < 8:
        return False, "Nenosiri lazima liwe na herufi 8+ / Password must be at least 8 characters"
    if not any(c.isupper() for c in password):
        return False, "Nenosiri lazima liwe na herufi kubwa / Password must contain uppercase letter"
    if not any(c.isdigit() for c in password):
        return False, "Nenosiri lazima liwe na nambari / Password must contain a number"
    return True, ""


# ── JWT ───────────────────────────────────────────────────────────────────────

def create_access_token(subject: str, extra_claims: Optional[dict] = None) -> str:
    expire = datetime.now(timezone.utc) + timedelta(
        minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES
    )
    payload: dict[str, Any] = {
        "sub": subject,
        "exp": expire,
        "iat": datetime.now(timezone.utc),
        "type": "access",
        "jti": str(uuid.uuid4()),  # Unique token ID
    }
    if extra_claims:
        payload.update(extra_claims)
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


def create_refresh_token(subject: str) -> str:
    expire = datetime.now(timezone.utc) + timedelta(
        days=settings.REFRESH_TOKEN_EXPIRE_DAYS
    )
    payload: dict[str, Any] = {
        "sub": subject,
        "exp": expire,
        "iat": datetime.now(timezone.utc),
        "type": "refresh",
        "jti": str(uuid.uuid4()),  # Unique token ID
    }
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


def decode_token(token: str) -> dict[str, Any]:
    return jwt.decode(
        token, settings.SECRET_KEY, algorithms=[settings.JWT_ALGORITHM]
    )


# ── M-Pesa Callback Verification ─────────────────────────────────────────────

def verify_mpesa_callback(payload: dict) -> bool:
    """Verify M-Pesa callback has expected structure."""
    try:
        body = payload.get("Body", {}).get("stkCallback", {})
        required = ["MerchantRequestID", "CheckoutRequestID", "ResultCode"]
        return all(k in body for k in required)
    except Exception:
        return False
