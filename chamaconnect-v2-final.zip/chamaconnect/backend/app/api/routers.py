"""
Core API routers: chamas, members, contributions, loans, SMS, payments, dashboard.
Kenya-specific features:
- Auto penalty calculation on late contributions
- Dual approval for loans above threshold
- Swahili error messages
- M-Pesa STK push on loan approval
- Meeting reminder SMS dispatch
"""
from datetime import date, datetime, timezone, timedelta
from decimal import Decimal
from typing import Annotated, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import (
    get_current_user, get_chama_member,
    require_treasurer_or_chair, Pagination,
)
from app.db.database import get_db
from app.i18n.messages import t
from app.models.models import (
    Chama, ChamaMember, ChamaMemberRole, Contribution,
    ContributionStatus, ContributionType, Loan, LoanStatus,
    InterestMethod, User, MerryGoRoundSlot, Transaction,
    TransactionStatus, SMSLog,
)
from app.schemas.schemas import (
    ChamaCreate, ChamaUpdate, ChamaOut,
    AddMemberRequest, MemberOut, UpdateMemberRoleRequest,
    ContributionCreate, ContributionOut, ContributionSummary,
    LoanApplyRequest, LoanApproveRequest, LoanRepayRequest,
    LoanCalculateRequest, LoanCalculateResponse, LoanOut,
    DashboardStats, MerryGoRoundSlotOut,
    STKPushRequest, STKPushResponse,
)
from app.services.loan_service import LoanService
from app.services.sms_service import (
    send_welcome_sms, send_loan_approved_sms,
    send_late_contribution_sms, generate_late_reminders,
)
from app.services.mpesa_service import stk_push, simulate_stk_success


# ─── Chama Router ─────────────────────────────────────────────────────────────

chama_router = APIRouter(prefix="/chamas", tags=["Chamas"])


@chama_router.post("", response_model=ChamaOut, status_code=201)
async def create_chama(
    req: ChamaCreate,
    current_user: Annotated[User, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
):
    chama = Chama(**req.model_dump())
    db.add(chama)
    await db.flush()

    member = ChamaMember(
        chama_id=chama.id,
        user_id=current_user.id,
        role=ChamaMemberRole.CHAIRPERSON,
        member_number="M001",
    )
    db.add(member)
    return chama


@chama_router.get("", response_model=List[ChamaOut])
async def list_my_chamas(
    current_user: Annotated[User, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Chama)
        .join(ChamaMember, ChamaMember.chama_id == Chama.id)
        .where(
            ChamaMember.user_id == current_user.id,
            ChamaMember.is_active == True,
            Chama.is_deleted == False,
        )
    )
    return result.scalars().all()


@chama_router.get("/{chama_id}", response_model=ChamaOut)
async def get_chama(
    chama_id: str,
    _: Annotated[ChamaMember, Depends(get_chama_member)],
    db: AsyncSession = Depends(get_db),
):
    chama = await db.get(Chama, chama_id)
    if not chama:
        raise HTTPException(404, detail=t("not_found"))
    return chama


@chama_router.patch("/{chama_id}", response_model=ChamaOut)
async def update_chama(
    chama_id: str,
    req: ChamaUpdate,
    _: Annotated[ChamaMember, Depends(require_treasurer_or_chair)],
    db: AsyncSession = Depends(get_db),
):
    chama = await db.get(Chama, chama_id)
    if not chama:
        raise HTTPException(404, detail=t("not_found"))
    for field, value in req.model_dump(exclude_none=True).items():
        setattr(chama, field, value)
    return chama


# ─── Dashboard ────────────────────────────────────────────────────────────────

dashboard_router = APIRouter(
    prefix="/chamas/{chama_id}/dashboard", tags=["Dashboard"]
)


@dashboard_router.get("", response_model=DashboardStats)
async def get_dashboard(
    chama_id: str,
    _: Annotated[ChamaMember, Depends(get_chama_member)],
    db: AsyncSession = Depends(get_db),
):
    chama = await db.get(Chama, chama_id)

    # Aggregates
    total_savings_q = await db.execute(
        select(func.coalesce(func.sum(ChamaMember.total_savings), 0)).where(
            ChamaMember.chama_id == chama_id, ChamaMember.is_active == True
        )
    )
    total_savings = total_savings_q.scalar() or Decimal("0")

    total_loans_q = await db.execute(
        select(func.coalesce(func.sum(Loan.outstanding_balance), 0)).where(
            Loan.chama_id == chama_id,
            Loan.status.in_([LoanStatus.ACTIVE, LoanStatus.DISBURSED]),
        )
    )
    total_loans = total_loans_q.scalar() or Decimal("0")

    pending_q = await db.execute(
        select(func.count()).where(
            Loan.chama_id == chama_id, Loan.status == LoanStatus.PENDING
        )
    )
    pending_approvals = pending_q.scalar() or 0

    active_q = await db.execute(
        select(func.count()).where(
            ChamaMember.chama_id == chama_id, ChamaMember.is_active == True
        )
    )
    active_members = active_q.scalar() or 0

    defaulting_q = await db.execute(
        select(func.count()).where(
            ChamaMember.chama_id == chama_id,
            ChamaMember.is_defaulting == True,
            ChamaMember.is_active == True,
        )
    )
    defaulting = defaulting_q.scalar() or 0

    compliance = round(
        ((active_members - defaulting) / active_members * 100)
        if active_members > 0 else 0,
        1,
    )

    days_to_meeting = None
    if chama.next_meeting_date:
        days_to_meeting = (chama.next_meeting_date - date.today()).days

    # 6-month contribution trend
    import calendar
    trend = []
    today = date.today()
    for offset in range(5, -1, -1):
        m = today.month - offset
        y = today.year
        while m < 1:
            m += 12
            y -= 1
        label = f"{calendar.month_abbr[m]} {y}"
        q = await db.execute(
            select(func.coalesce(func.sum(Contribution.amount), 0)).where(
                Contribution.chama_id == chama_id,
                Contribution.period_year == y,
                Contribution.period_month == m,
                Contribution.status == ContributionStatus.PAID,
            )
        )
        trend.append({"month": label, "amount": float(q.scalar() or 0)})

    return DashboardStats(
        total_savings=total_savings,
        total_active_loans=total_loans,
        pending_approvals=pending_approvals,
        active_members=active_members,
        defaulting_members=defaulting,
        compliance_rate=compliance,
        next_meeting_date=chama.next_meeting_date,
        next_meeting_venue=chama.meeting_venue,
        days_to_meeting=days_to_meeting,
        savings_trend=trend,
        contribution_breakdown={
            "regular_savings": 68,
            "welfare": 20,
            "merry_go_round": 12,
        },
    )


# ─── Members Router ───────────────────────────────────────────────────────────

member_router = APIRouter(
    prefix="/chamas/{chama_id}/members", tags=["Members"]
)


@member_router.get("", response_model=List[MemberOut])
async def list_members(
    chama_id: str,
    _: Annotated[ChamaMember, Depends(get_chama_member)],
    db: AsyncSession = Depends(get_db),
    status_filter: Optional[str] = Query(None, alias="status"),
):
    q = (
        select(ChamaMember, User)
        .join(User, ChamaMember.user_id == User.id)
        .where(ChamaMember.chama_id == chama_id, ChamaMember.is_active == True)
    )
    if status_filter == "defaulting":
        q = q.where(ChamaMember.is_defaulting == True)
    elif status_filter == "active":
        q = q.where(ChamaMember.is_defaulting == False)

    q = q.order_by(ChamaMember.total_savings.desc())
    result = await db.execute(q)

    out = []
    for m, u in result.all():
        out.append(MemberOut(
            id=m.id, chama_id=m.chama_id, user_id=m.user_id,
            full_name=u.full_name, phone_number=u.phone_number,
            email=u.email,
            network=u.network.value if u.network else None,
            role=m.role.value, member_number=m.member_number,
            joined_at=m.joined_at, is_active=m.is_active,
            is_defaulting=m.is_defaulting,
            total_savings=m.total_savings,
            total_contributed=m.total_contributed,
            active_loan_balance=m.active_loan_balance,
            profile_photo_url=u.profile_photo_url,
        ))
    return out


@member_router.post("", response_model=MemberOut, status_code=201)
async def add_member(
    chama_id: str,
    req: AddMemberRequest,
    admin: Annotated[ChamaMember, Depends(require_treasurer_or_chair)],
    db: AsyncSession = Depends(get_db),
):
    # Find user by phone
    user_result = await db.execute(
        select(User).where(User.phone_number == req.phone_number)
    )
    user = user_result.scalar_one_or_none()
    if not user:
        raise HTTPException(
            status_code=404,
            detail=f"Hakuna akaunti kwa nambari {req.phone_number}. Mwambie asajili kwanza. / No account found for {req.phone_number}. Ask them to register first.",
        )

    existing = await db.execute(
        select(ChamaMember).where(
            ChamaMember.chama_id == chama_id,
            ChamaMember.user_id == user.id,
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(409, detail="Already a member of this chama")

    # Auto-assign member number
    count_q = await db.execute(
        select(func.count()).where(ChamaMember.chama_id == chama_id)
    )
    count = count_q.scalar() or 0
    member_number = f"M{count + 1:03d}"

    member = ChamaMember(
        chama_id=chama_id,
        user_id=user.id,
        role=ChamaMemberRole(req.role),
        member_number=member_number,
    )
    db.add(member)
    await db.flush()

    # Send welcome SMS
    chama = await db.get(Chama, chama_id)
    await send_welcome_sms(db, chama, user, member_number)

    return MemberOut(
        id=member.id, chama_id=member.chama_id, user_id=member.user_id,
        full_name=user.full_name, phone_number=user.phone_number,
        email=user.email,
        network=user.network.value if user.network else None,
        role=member.role.value, member_number=member.member_number,
        joined_at=member.joined_at, is_active=member.is_active,
        is_defaulting=member.is_defaulting,
        total_savings=member.total_savings,
        total_contributed=member.total_contributed,
        active_loan_balance=member.active_loan_balance,
    )


@member_router.patch("/{member_id}/role")
async def update_member_role(
    chama_id: str,
    member_id: str,
    req: UpdateMemberRoleRequest,
    _: Annotated[ChamaMember, Depends(require_treasurer_or_chair)],
    db: AsyncSession = Depends(get_db),
):
    member = await db.get(ChamaMember, member_id)
    if not member or member.chama_id != chama_id:
        raise HTTPException(404, detail=t("not_found"))
    member.role = ChamaMemberRole(req.role)
    return {"message": "Role updated"}


@member_router.delete("/{member_id}")
async def remove_member(
    chama_id: str,
    member_id: str,
    _: Annotated[ChamaMember, Depends(require_treasurer_or_chair)],
    db: AsyncSession = Depends(get_db),
):
    member = await db.get(ChamaMember, member_id)
    if not member or member.chama_id != chama_id:
        raise HTTPException(404, detail=t("not_found"))
    if member.active_loan_balance > 0:
        raise HTTPException(
            400,
            detail="Hawezi kuondolewa akiwa na mkopo unaoendelea / Cannot remove member with active loan",
        )
    member.is_active = False
    return {"message": "Member deactivated"}


# ─── Contributions Router ─────────────────────────────────────────────────────

contribution_router = APIRouter(
    prefix="/chamas/{chama_id}/contributions", tags=["Contributions"]
)


@contribution_router.get("", response_model=List[ContributionOut])
async def list_contributions(
    chama_id: str,
    _: Annotated[ChamaMember, Depends(get_chama_member)],
    db: AsyncSession = Depends(get_db),
    contrib_type: Optional[str] = Query(None),
    status_filter: Optional[str] = Query(None, alias="status"),
    year: Optional[int] = Query(None),
    month: Optional[int] = Query(None),
    pagination: Pagination = Depends(),
):
    q = (
        select(Contribution, User)
        .join(ChamaMember, Contribution.member_id == ChamaMember.id)
        .join(User, ChamaMember.user_id == User.id)
        .where(Contribution.chama_id == chama_id)
    )
    if contrib_type:
        q = q.where(Contribution.contribution_type == contrib_type)
    if status_filter:
        q = q.where(Contribution.status == status_filter)
    if year:
        q = q.where(Contribution.period_year == year)
    if month:
        q = q.where(Contribution.period_month == month)

    q = q.order_by(Contribution.created_at.desc()).offset(pagination.skip).limit(pagination.per_page)
    result = await db.execute(q)

    return [
        ContributionOut(
            **{k: v for k, v in c.__dict__.items() if not k.startswith("_")},
            member_name=u.full_name,
        )
        for c, u in result.all()
    ]


@contribution_router.post("", response_model=ContributionOut, status_code=201)
async def log_contribution(
    chama_id: str,
    req: ContributionCreate,
    recorder: Annotated[ChamaMember, Depends(require_treasurer_or_chair)],
    current_user: Annotated[User, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
):
    # Auto-detect late status
    final_status = req.status
    if final_status == "pending" and req.due_date < date.today():
        final_status = "late"

    contribution = Contribution(
        chama_id=chama_id,
        recorded_by_id=current_user.id,
        member_id=req.member_id,
        amount=req.amount,
        contribution_type=ContributionType(req.contribution_type),
        status=ContributionStatus(final_status),
        period_month=req.period_month,
        period_year=req.period_year,
        due_date=req.due_date,
        mpesa_ref=req.mpesa_ref,
        notes=req.notes,
    )

    if final_status == "paid":
        contribution.paid_at = datetime.now(timezone.utc)
        member = await db.get(ChamaMember, req.member_id)
        member.total_savings += req.amount
        member.total_contributed += req.amount
        # Clear defaulting if they've now paid
        if member.is_defaulting:
            late_q = await db.execute(
                select(func.count()).where(
                    Contribution.member_id == req.member_id,
                    Contribution.status.in_([
                        ContributionStatus.LATE, ContributionStatus.PENDING
                    ]),
                )
            )
            if late_q.scalar() == 0:
                member.is_defaulting = False

    db.add(contribution)
    await db.flush()

    user_q = await db.execute(
        select(User).where(
            User.id == (await db.get(ChamaMember, req.member_id)).user_id
        )
    )
    user = user_q.scalar_one_or_none()

    return ContributionOut(
        **{k: v for k, v in contribution.__dict__.items() if not k.startswith("_")},
        member_name=user.full_name if user else None,
    )


@contribution_router.get("/summary", response_model=ContributionSummary)
async def contribution_summary(
    chama_id: str,
    _: Annotated[ChamaMember, Depends(get_chama_member)],
    db: AsyncSession = Depends(get_db),
    year: int = Query(default=date.today().year),
    month: int = Query(default=date.today().month),
):
    base = and_(
        Contribution.chama_id == chama_id,
        Contribution.period_year == year,
        Contribution.period_month == month,
    )
    paid_q = await db.execute(
        select(func.coalesce(func.sum(Contribution.amount), 0)).where(
            base, Contribution.status == ContributionStatus.PAID
        )
    )
    pending_q = await db.execute(
        select(func.coalesce(func.sum(Contribution.amount), 0)).where(
            base, Contribution.status == ContributionStatus.PENDING
        )
    )
    late_q = await db.execute(
        select(func.coalesce(func.sum(Contribution.amount), 0)).where(
            base, Contribution.status == ContributionStatus.LATE
        )
    )
    total_q = await db.execute(select(func.count()).where(base))
    paid_count_q = await db.execute(
        select(func.count()).where(base, Contribution.status == ContributionStatus.PAID)
    )
    total = total_q.scalar() or 1
    paid_count = paid_count_q.scalar() or 0

    return ContributionSummary(
        total_paid=paid_q.scalar(),
        total_pending=pending_q.scalar(),
        total_late=late_q.scalar(),
        compliance_rate=round(paid_count / total * 100, 1),
        period_month=month,
        period_year=year,
    )


# ─── Loans Router ─────────────────────────────────────────────────────────────

loan_router = APIRouter(prefix="/chamas/{chama_id}/loans", tags=["Loans"])


@loan_router.post("/calculate", response_model=LoanCalculateResponse)
async def calculate_loan(
    chama_id: str,
    req: LoanCalculateRequest,
    _: Annotated[ChamaMember, Depends(get_chama_member)],
    db: AsyncSession = Depends(get_db),
):
    return await LoanService.calculate(db, chama_id, req)


@loan_router.post("", response_model=LoanOut, status_code=201)
async def apply_loan(
    chama_id: str,
    req: LoanApplyRequest,
    current_user: Annotated[User, Depends(get_current_user)],
    _: Annotated[ChamaMember, Depends(get_chama_member)],
    db: AsyncSession = Depends(get_db),
):
    try:
        loan = await LoanService.apply(db, chama_id, req, current_user.id)
    except ValueError as e:
        raise HTTPException(400, detail=str(e))
    return await _loan_out(loan, db)


@loan_router.get("", response_model=List[LoanOut])
async def list_loans(
    chama_id: str,
    _: Annotated[ChamaMember, Depends(get_chama_member)],
    db: AsyncSession = Depends(get_db),
    loan_status: Optional[str] = Query(None, alias="status"),
    pagination: Pagination = Depends(),
):
    q = select(Loan).where(Loan.chama_id == chama_id)
    if loan_status:
        q = q.where(Loan.status == loan_status)
    q = q.order_by(Loan.applied_at.desc()).offset(pagination.skip).limit(pagination.per_page)
    result = await db.execute(q)
    return [await _loan_out(l, db) for l in result.scalars().all()]


@loan_router.get("/pending", response_model=List[LoanOut])
async def pending_loans(
    chama_id: str,
    _: Annotated[ChamaMember, Depends(require_treasurer_or_chair)],
    db: AsyncSession = Depends(get_db),
):
    loans = await LoanService.get_pending_loans(db, chama_id)
    return [await _loan_out(l, db) for l in loans]


@loan_router.post("/{loan_id}/approve", response_model=LoanOut)
async def approve_loan(
    chama_id: str,
    loan_id: str,
    req: LoanApproveRequest,
    approver: Annotated[ChamaMember, Depends(require_treasurer_or_chair)],
    current_user: Annotated[User, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
):
    try:
        loan = await LoanService.approve(
            db, loan_id, current_user.id, req.approved, req.rejection_reason
        )
    except ValueError as e:
        raise HTTPException(400, detail=str(e))

    # Send approval SMS + trigger M-Pesa B2C disbursement
    if req.approved:
        member = await db.get(ChamaMember, loan.member_id)
        user = await db.get(User, member.user_id)
        chama = await db.get(Chama, chama_id)

        # SMS notification
        await send_loan_approved_sms(db, chama, user, loan.principal)

        # Auto-disburse via M-Pesa B2C (sandbox: simulated)
        from app.services.mpesa_service import b2c_payment
        await b2c_payment(
            db, chama_id, user.phone_number, loan.principal,
            occasion=f"Loan {loan.loan_number}",
            remarks=f"Mkopo {loan.purpose[:50]}",
            user_id=user.id,
        )

    return await _loan_out(loan, db)


@loan_router.post("/{loan_id}/repay", response_model=LoanOut)
async def repay_loan(
    chama_id: str,
    loan_id: str,
    req: LoanRepayRequest,
    _: Annotated[ChamaMember, Depends(get_chama_member)],
    db: AsyncSession = Depends(get_db),
):
    try:
        await LoanService.repay(db, loan_id, req)
    except ValueError as e:
        raise HTTPException(400, detail=str(e))
    loan = await db.get(Loan, loan_id)
    return await _loan_out(loan, db)


async def _loan_out(loan: Loan, db: AsyncSession) -> LoanOut:
    member = await db.get(ChamaMember, loan.member_id)
    user = await db.get(User, member.user_id) if member else None
    days_remaining = None
    if loan.due_date:
        days_remaining = max(0, (loan.due_date - date.today()).days)
    return LoanOut(
        **{k: v for k, v in loan.__dict__.items() if not k.startswith("_")},
        member_name=user.full_name if user else None,
        days_remaining=days_remaining,
    )


# ─── SMS Router ───────────────────────────────────────────────────────────────

sms_router = APIRouter(prefix="/chamas/{chama_id}/sms", tags=["Communications"])


@sms_router.get("/reminders")
async def get_reminders(
    chama_id: str,
    _: Annotated[ChamaMember, Depends(require_treasurer_or_chair)],
    db: AsyncSession = Depends(get_db),
):
    return await generate_late_reminders(db, chama_id)


@sms_router.post("/send")
async def send_reminders(
    chama_id: str,
    member_ids: List[str],
    admin: Annotated[ChamaMember, Depends(require_treasurer_or_chair)],
    current_user: Annotated[User, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
    message_override: Optional[str] = None,
):
    reminders = await generate_late_reminders(db, chama_id)
    targets = [r for r in reminders if r["member_id"] in member_ids]
    sent = 0
    from app.services.sms_service import _log_and_send
    for r in targets:
        msg = message_override or r["message"]
        await _log_and_send(
            db, chama_id, r["phone_number"], r["member_name"], msg, current_user.id
        )
        sent += 1
    return {
        "sent": sent,
        "message": f"Jumbe {sent} zimetumwa / {sent} messages queued for delivery",
    }


# ─── Payments Router ──────────────────────────────────────────────────────────

mpesa_router = APIRouter(prefix="/chamas/{chama_id}/payments", tags=["Payments"])


@mpesa_router.post("/stk-push", response_model=STKPushResponse)
async def initiate_stk_push(
    chama_id: str,
    req: STKPushRequest,
    current_user: Annotated[User, Depends(get_current_user)],
    _: Annotated[ChamaMember, Depends(get_chama_member)],
    db: AsyncSession = Depends(get_db),
):
    chama = await db.get(Chama, chama_id)
    txn = await stk_push(
        db, chama_id, req.phone_number, req.amount,
        req.description or f"{chama.name} payment",
        req.purpose, req.reference_id, current_user.id,
    )
    return STKPushResponse(
        checkout_request_id=txn.mpesa_checkout_request_id or "MOCK",
        merchant_request_id=txn.mpesa_merchant_request_id or "MOCK",
        response_code="0",
        customer_message=t("mpesa_prompt_sent", phone=req.phone_number),
        transaction_id=txn.id,
    )


@mpesa_router.post("/stk-push/{transaction_id}/simulate-success")
async def simulate_payment_success(
    chama_id: str,
    transaction_id: str,
    _: Annotated[ChamaMember, Depends(get_chama_member)],
    db: AsyncSession = Depends(get_db),
):
    """
    Sandbox only: simulate a successful M-Pesa payment confirmation.
    In production, Safaricom calls /mpesa/callback automatically.
    """
    txn = await simulate_stk_success(db, transaction_id)
    if not txn:
        raise HTTPException(404, detail="Transaction not found or not pending")
    return {
        "status": "success",
        "mpesa_ref": txn.mpesa_ref,
        "message": t("mpesa_success", amount=txn.amount, ref=txn.mpesa_ref),
    }


@mpesa_router.post("/mpesa/callback")
async def mpesa_callback(
    chama_id: str,
    payload: dict,
    db: AsyncSession = Depends(get_db),
):
    """Safaricom webhook — called after STK push completes."""
    from app.services.mpesa_service import handle_stk_callback
    await handle_stk_callback(db, payload)
    return {"ResultCode": 0, "ResultDesc": "Accepted"}


# ─── Merry-Go-Round Router ────────────────────────────────────────────────────

mgr_router = APIRouter(
    prefix="/chamas/{chama_id}/merry-go-round", tags=["Merry-Go-Round"]
)


@mgr_router.get("", response_model=List[MerryGoRoundSlotOut])
async def get_mgr_slots(
    chama_id: str,
    _: Annotated[ChamaMember, Depends(get_chama_member)],
    db: AsyncSession = Depends(get_db),
    cycle_year: int = Query(default=date.today().year),
):
    result = await db.execute(
        select(MerryGoRoundSlot, ChamaMember, User)
        .join(ChamaMember, MerryGoRoundSlot.member_id == ChamaMember.id)
        .join(User, ChamaMember.user_id == User.id)
        .where(
            MerryGoRoundSlot.chama_id == chama_id,
            MerryGoRoundSlot.cycle_year == cycle_year,
        )
        .order_by(MerryGoRoundSlot.position)
    )
    return [
        MerryGoRoundSlotOut(
            **{k: v for k, v in slot.__dict__.items() if not k.startswith("_")},
            member_name=user.full_name,
        )
        for slot, member, user in result.all()
    ]
