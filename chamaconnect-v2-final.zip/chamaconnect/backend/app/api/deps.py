"""FastAPI dependencies — authentication, authorisation, pagination."""
from typing import Annotated
from fastapi import Depends, HTTPException, Query, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import decode_token
from app.db.database import get_db
from app.models.models import User, ChamaMember, ChamaMemberRole

bearer_scheme = HTTPBearer(auto_error=False)


async def get_current_user(
    credentials: Annotated[
        HTTPAuthorizationCredentials | None, Depends(bearer_scheme)
    ],
    db: AsyncSession = Depends(get_db),
) -> User:
    """Extract and validate JWT bearer token."""
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
            headers={"WWW-Authenticate": "Bearer"},
        )

    try:
        payload = decode_token(credentials.credentials)
        user_id: str = payload.get("sub")
        token_type: str = payload.get("type", "")
        if not user_id or token_type != "access":
            raise JWTError("Invalid token")
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user = await db.get(User, user_id)
    if not user or not user.is_active or user.is_deleted:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or account suspended",
        )
    return user


async def get_chama_member(
    chama_id: str,
    current_user: Annotated[User, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
) -> ChamaMember:
    """Verify caller is an active member of the specified chama."""
    result = await db.execute(
        select(ChamaMember).where(
            ChamaMember.chama_id == chama_id,
            ChamaMember.user_id == current_user.id,
            ChamaMember.is_active == True,
        )
    )
    member = result.scalar_one_or_none()
    if not member:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Wewe si mwanachama wa chama hiki / You are not a member of this chama",
        )
    return member


async def require_treasurer_or_chair(
    chama_id: str,
    current_user: Annotated[User, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
) -> ChamaMember:
    """Require Chairperson or Treasurer role."""
    result = await db.execute(
        select(ChamaMember).where(
            ChamaMember.chama_id == chama_id,
            ChamaMember.user_id == current_user.id,
            ChamaMember.is_active == True,
        )
    )
    member = result.scalar_one_or_none()
    if not member:
        raise HTTPException(status_code=403, detail="Not a member")

    allowed = {ChamaMemberRole.CHAIRPERSON, ChamaMemberRole.TREASURER}
    if member.role not in allowed and current_user.role.value != "super_admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Mwenyekiti au Mweka Hazina tu anaweza / Chairperson or Treasurer only",
        )
    return member


class Pagination:
    def __init__(
        self,
        page: int = Query(default=1, ge=1),
        per_page: int = Query(default=20, ge=1, le=100),
    ):
        self.page = page
        self.per_page = per_page

    @property
    def skip(self) -> int:
        return (self.page - 1) * self.per_page
