"""
Authentication router — register, login, PIN setup/verify/reset.
Security hardening:
- Rate limited (10 login attempts / minute per IP)
- Audit log every auth event
- Swahili error messages
- No information leakage on wrong credentials
"""
from datetime import datetime, timedelta, timezone
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import (
    hash_secret, verify_secret,
    create_access_token, create_refresh_token, decode_token,
    generate_reset_code, generate_token_hash,
    validate_password_strength,
)
from app.db.database import get_db
from app.i18n.messages import t
from app.models.models import User, RefreshToken, AuditLog, UserRole, Network
from app.schemas.schemas import (
    RegisterRequest, LoginRequest, TokenResponse, RefreshRequest,
    SetPINRequest, VerifyPINRequest,
    RequestPINResetRequest, VerifyPINResetRequest, UserOut,
)
from app.api.deps import get_current_user

router = APIRouter(prefix="/auth", tags=["Authentication"])


def _get_ip(request: Request) -> str:
    """Extract real IP, accounting for reverse proxies."""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


async def _get_user_by_phone(db: AsyncSession, phone: str) -> User | None:
    result = await db.execute(
        select(User).where(
            User.phone_number == phone,
            User.is_deleted == False,
        )
    )
    return result.scalar_one_or_none()


async def _write_audit(
    db: AsyncSession,
    action: str,
    user_id: str | None,
    ip: str,
    details: dict | None = None,
):
    log = AuditLog(
        user_id=user_id,
        action=action,
        resource_type="auth",
        new_value=details,
        ip_address=ip,
    )
    db.add(log)


# ── Register ──────────────────────────────────────────────────────────────────

@router.post("/register", response_model=TokenResponse, status_code=201)
async def register(
    req: RegisterRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    # Password strength check
    strong, msg = validate_password_strength(req.password)
    if not strong:
        raise HTTPException(status_code=400, detail=msg)

    existing = await _get_user_by_phone(db, req.phone_number)
    if existing:
        raise HTTPException(
            status_code=409,
            detail=t("phone_exists"),
        )

    user = User(
        phone_number=req.phone_number,
        email=req.email,
        full_name=req.full_name,
        hashed_password=hash_secret(req.password),
        network=Network(req.network) if req.network else None,
        is_active=True,
        role=UserRole.MEMBER,
    )
    db.add(user)
    await db.flush()

    access = create_access_token(user.id)
    refresh = create_refresh_token(user.id)
    rt = RefreshToken(
        user_id=user.id,
        token_hash=generate_token_hash(refresh),
        expires_at=datetime.now(timezone.utc)
        + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
        device_info=request.headers.get("User-Agent", "")[:200],
    )
    db.add(rt)

    await _write_audit(db, "register", user.id, _get_ip(request))

    return TokenResponse(
        access_token=access,
        refresh_token=refresh,
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


# ── Login ─────────────────────────────────────────────────────────────────────

@router.post("/login", response_model=TokenResponse)
async def login(
    req: LoginRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    user = await _get_user_by_phone(db, req.phone_number)

    # Use same error for wrong phone OR wrong password — prevents enumeration
    if not user or not user.hashed_password:
        await _write_audit(db, "login_failed", None, _get_ip(request),
                           {"phone": req.phone_number[:6] + "****"})
        raise HTTPException(
            status_code=401,
            detail=t("login_failed"),
        )

    if not verify_secret(req.password, user.hashed_password):
        await _write_audit(db, "login_failed", user.id, _get_ip(request))
        raise HTTPException(status_code=401, detail=t("login_failed"))

    if not user.is_active:
        raise HTTPException(status_code=403, detail=t("account_suspended"))

    user.last_login_at = datetime.now(timezone.utc)

    access = create_access_token(user.id)
    refresh = create_refresh_token(user.id)
    rt = RefreshToken(
        user_id=user.id,
        token_hash=generate_token_hash(refresh),
        expires_at=datetime.now(timezone.utc)
        + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
        device_info=request.headers.get("User-Agent", "")[:200],
    )
    db.add(rt)
    await _write_audit(db, "login_success", user.id, _get_ip(request))

    return TokenResponse(
        access_token=access,
        refresh_token=refresh,
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


# ── Token Refresh ─────────────────────────────────────────────────────────────

@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(
    req: RefreshRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    try:
        payload = decode_token(req.refresh_token)
        if payload.get("type") != "refresh":
            raise ValueError("wrong type")
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid refresh token")

    token_hash = generate_token_hash(req.refresh_token)
    result = await db.execute(
        select(RefreshToken).where(
            RefreshToken.token_hash == token_hash,
            RefreshToken.is_revoked == False,
        )
    )
    stored = result.scalar_one_or_none()
    now = datetime.now(timezone.utc)

    if not stored:
        raise HTTPException(status_code=401, detail="Token not found or already used")

    exp = stored.expires_at
    if exp.tzinfo is None:
        exp = exp.replace(tzinfo=timezone.utc)
    if exp < now:
        raise HTTPException(status_code=401, detail="Refresh token expired")

    # Rotate: revoke old, issue new
    stored.is_revoked = True
    user_id = payload["sub"]
    access = create_access_token(user_id)
    new_refresh = create_refresh_token(user_id)
    db.add(RefreshToken(
        user_id=user_id,
        token_hash=generate_token_hash(new_refresh),
        expires_at=now + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
        device_info=request.headers.get("User-Agent", "")[:200],
    ))

    return TokenResponse(
        access_token=access,
        refresh_token=new_refresh,
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


# ── PIN Setup ─────────────────────────────────────────────────────────────────

@router.post("/pin/setup", status_code=200)
async def setup_pin(
    req: SetPINRequest,
    request: Request,
    current_user: Annotated[User, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
):
    current_user.hashed_pin = hash_secret(req.pin)
    current_user.is_pin_set = True
    current_user.pin_attempts = 0
    await _write_audit(db, "pin_set", current_user.id, _get_ip(request))
    return {"message": t("pin_set"), "message_sw": t("pin_set", "sw")}


# ── PIN Verify ────────────────────────────────────────────────────────────────

@router.post("/pin/verify")
async def verify_pin(
    req: VerifyPINRequest,
    request: Request,
    current_user: Annotated[User, Depends(get_current_user)],
    db: AsyncSession = Depends(get_db),
):
    now = datetime.now(timezone.utc)

    # Check lockout
    if current_user.pin_locked_until:
        locked_until = current_user.pin_locked_until
        if locked_until.tzinfo is None:
            locked_until = locked_until.replace(tzinfo=timezone.utc)
        if locked_until > now:
            remaining_min = int((locked_until - now).total_seconds() / 60) + 1
            raise HTTPException(
                status_code=429,
                detail=t("pin_locked", minutes=remaining_min),
            )
        else:
            # Lockout expired — reset
            current_user.pin_attempts = 0
            current_user.pin_locked_until = None

    if not current_user.hashed_pin:
        raise HTTPException(status_code=400, detail="PIN not set")

    if not verify_secret(req.pin, current_user.hashed_pin):
        current_user.pin_attempts += 1
        remaining = settings.PIN_MAX_ATTEMPTS - current_user.pin_attempts

        if current_user.pin_attempts >= settings.PIN_MAX_ATTEMPTS:
            current_user.pin_locked_until = now + timedelta(
                minutes=settings.PIN_LOCKOUT_MINUTES
            )
            await _write_audit(db, "pin_locked", current_user.id, _get_ip(request))
            raise HTTPException(
                status_code=429,
                detail=t("pin_locked", minutes=settings.PIN_LOCKOUT_MINUTES),
            )

        await _write_audit(db, "pin_wrong", current_user.id, _get_ip(request))
        raise HTTPException(
            status_code=401,
            detail=t("pin_wrong", remaining=max(0, remaining)),
        )

    # Success
    current_user.pin_attempts = 0
    current_user.pin_locked_until = None
    await _write_audit(db, "pin_verified", current_user.id, _get_ip(request))

    # Issue a short-lived "pin verified" token
    pin_access = create_access_token(
        current_user.id,
        extra_claims={"pin_verified": True},
    )
    return {
        "message": t("pin_correct"),
        "access_token": pin_access,
    }


# ── PIN Reset — Request ───────────────────────────────────────────────────────

@router.post("/pin/reset/request")
async def request_pin_reset(
    req: RequestPINResetRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    user = await _get_user_by_phone(db, req.phone_number)

    # Always return the same message — don't reveal whether phone is registered
    generic_response = {
        "message": t("pin_reset_sent"),
        "message_sw": t("pin_reset_sent", "sw"),
    }

    if not user:
        return generic_response

    code = generate_reset_code(6)
    user.pin_reset_code = hash_secret(code)
    user.pin_reset_expires = datetime.now(timezone.utc) + timedelta(
        minutes=settings.PIN_RESET_CODE_EXPIRE_MINUTES
    )

    # Send real SMS if enabled, otherwise log for dev
    if settings.SMS_ENABLED:
        from app.services.sms_service import _log_and_send
        from app.models.models import Chama
        msg = f"ChamaConnect PIN reset: {code}. Halali kwa dakika {settings.PIN_RESET_CODE_EXPIRE_MINUTES}. Usishirikishe mtu."
        chama_result = await db.execute(
            select(Chama).limit(1)
        )
        first_chama = chama_result.scalar_one_or_none()
        if first_chama:
            await _log_and_send(db, first_chama.id, user.phone_number, user.full_name, msg)
    else:
        # In dev mode only — return code in response for testing
        if settings.DEBUG:
            generic_response["debug_code"] = code

    await _write_audit(db, "pin_reset_requested", user.id, _get_ip(request))
    return generic_response


# ── PIN Reset — Verify ────────────────────────────────────────────────────────

@router.post("/pin/reset/verify")
async def verify_pin_reset(
    req: VerifyPINResetRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    user = await _get_user_by_phone(db, req.phone_number)

    if not user or not user.pin_reset_code:
        raise HTTPException(status_code=400, detail=t("pin_reset_wrong"))

    expiry = user.pin_reset_expires
    if expiry:
        if expiry.tzinfo is None:
            expiry = expiry.replace(tzinfo=timezone.utc)
        if expiry < datetime.now(timezone.utc):
            raise HTTPException(status_code=400, detail=t("pin_reset_expired"))

    if not verify_secret(req.reset_code, user.pin_reset_code):
        raise HTTPException(status_code=400, detail=t("pin_reset_wrong"))

    user.hashed_pin = hash_secret(req.new_pin)
    user.is_pin_set = True
    user.pin_attempts = 0
    user.pin_locked_until = None
    user.pin_reset_code = None
    user.pin_reset_expires = None
    await _write_audit(db, "pin_reset_done", user.id, _get_ip(request))

    return {"message": t("pin_reset_done"), "message_sw": t("pin_reset_done", "sw")}


# ── Me ────────────────────────────────────────────────────────────────────────

@router.get("/me", response_model=UserOut)
async def get_me(
    current_user: Annotated[User, Depends(get_current_user)]
):
    return current_user
