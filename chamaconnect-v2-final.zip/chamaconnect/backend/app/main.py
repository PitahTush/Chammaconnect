"""
ChamaConnect v2 — FastAPI application factory.
Includes: security headers, rate limiting, request tracing, CORS.
"""
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse

from app.core.config import settings
from app.db.database import init_db, close_db, check_db_health
from app.middleware.security import (
    SecurityHeadersMiddleware,
    RequestIDMiddleware,
    RequestTimingMiddleware,
    BlockSuspiciousRequestsMiddleware,
)
from app.api.auth import router as auth_router
from app.api.routers import (
    chama_router, dashboard_router, member_router,
    contribution_router, loan_router, sms_router,
    mpesa_router, mgr_router,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: create tables for SQLite (dev) or verify connection for PostgreSQL
    await init_db()
    yield
    # Shutdown: close connection pool cleanly
    await close_db()


def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.APP_NAME,
        version=settings.APP_VERSION,
        description=(
            "ChamaConnect — Kenya Chama Management API. "
            "Inasaidia vikundi vya akiba nchini Kenya."
        ),
        docs_url="/api/docs" if settings.DEBUG else None,
        redoc_url="/api/redoc" if settings.DEBUG else None,
        openapi_url="/api/openapi.json" if settings.DEBUG else None,
        lifespan=lifespan,
    )

    # ── Middleware (order matters: outermost runs first) ─────
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(RequestIDMiddleware)
    app.add_middleware(RequestTimingMiddleware)
    app.add_middleware(BlockSuspiciousRequestsMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.origins_list,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type", "X-Request-ID"],
    )
    app.add_middleware(GZipMiddleware, minimum_size=1000)

    # ── Global exception handler ─────────────────────────────
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        if settings.DEBUG:
            raise exc
        return JSONResponse(
            status_code=500,
            content={
                "detail": "Kuna tatizo la seva. Tafadhali jaribu tena. / Internal server error."
            },
        )

    # ── Routes ───────────────────────────────────────────────
    prefix = settings.API_V1_PREFIX
    app.include_router(auth_router, prefix=prefix)
    app.include_router(chama_router, prefix=prefix)
    app.include_router(dashboard_router, prefix=prefix)
    app.include_router(member_router, prefix=prefix)
    app.include_router(contribution_router, prefix=prefix)
    app.include_router(loan_router, prefix=prefix)
    app.include_router(sms_router, prefix=prefix)
    app.include_router(mpesa_router, prefix=prefix)
    app.include_router(mgr_router, prefix=prefix)

    # ── Health & status ──────────────────────────────────────
    @app.get("/health", tags=["Health"])
    async def health():
        db_ok = await check_db_health()
        return {
            "status": "ok" if db_ok else "degraded",
            "version": settings.APP_VERSION,
            "database": "connected" if db_ok else "unreachable",
            "environment": settings.APP_ENV,
        }

    @app.get("/", tags=["Health"])
    async def root():
        return {
            "app": settings.APP_NAME,
            "version": settings.APP_VERSION,
            "docs": "/api/docs" if settings.DEBUG else "disabled in production",
        }

    return app


app = create_app()
