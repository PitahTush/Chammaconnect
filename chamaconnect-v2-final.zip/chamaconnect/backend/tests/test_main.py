"""
ChamaConnect v2 — Test Suite
Covers: auth security, loan calculators, contributions, PIN lockout, Swahili messages.
Run: pytest -v
"""
import pytest
from decimal import Decimal
from httpx import AsyncClient


# ── Registration & Login ──────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_register_success(client: AsyncClient):
    resp = await client.post("/api/v1/auth/register", json={
        "full_name": "Jane Wanjiru Kamau",
        "phone_number": "0799111222",
        "password": "SecurePass1!",
    })
    assert resp.status_code == 201
    data = resp.json()
    assert "access_token" in data
    assert "refresh_token" in data


@pytest.mark.asyncio
async def test_register_weak_password_rejected(client: AsyncClient):
    resp = await client.post("/api/v1/auth/register", json={
        "full_name": "Test User",
        "phone_number": "0799111333",
        "password": "weak",
    })
    assert resp.status_code in (400, 422)  # 422 from Pydantic, 400 from our check


@pytest.mark.asyncio
async def test_register_duplicate_phone_rejected(client: AsyncClient, test_user):
    resp = await client.post("/api/v1/auth/register", json={
        "full_name": "Another Person",
        "phone_number": "+254799000001",
        "password": "Password123!",
    })
    assert resp.status_code == 409


@pytest.mark.asyncio
async def test_login_success(client: AsyncClient, test_user):
    resp = await client.post("/api/v1/auth/login", json={
        "phone_number": "+254799000001",
        "password": "Password123!",
    })
    assert resp.status_code == 200
    assert "access_token" in resp.json()


@pytest.mark.asyncio
async def test_login_wrong_password(client: AsyncClient, test_user):
    resp = await client.post("/api/v1/auth/login", json={
        "phone_number": "+254799000001",
        "password": "wrongpassword",
    })
    assert resp.status_code == 401
    # Must not reveal whether phone exists or password wrong
    detail = resp.json()["detail"]
    assert "phone" not in detail.lower() or "nambari" in detail.lower()


@pytest.mark.asyncio
async def test_login_nonexistent_phone_same_error(client: AsyncClient):
    """Security: wrong phone gives identical error to wrong password."""
    resp = await client.post("/api/v1/auth/login", json={
        "phone_number": "+254799999999",
        "password": "SomePassword1",
    })
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_get_me_requires_auth(client: AsyncClient):
    resp = await client.get("/api/v1/auth/me")
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_get_me_authenticated(client: AsyncClient, auth_headers):
    resp = await client.get("/api/v1/auth/me", headers=auth_headers)
    assert resp.status_code == 200
    assert resp.json()["phone_number"] == "+254799000001"


# ── PIN Security ──────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_pin_setup_and_verify(client: AsyncClient, auth_headers):
    # Setup PIN
    r1 = await client.post("/api/v1/auth/pin/setup",
                           json={"pin": "5678", "confirm_pin": "5678"},
                           headers=auth_headers)
    assert r1.status_code == 200

    # Correct PIN
    r2 = await client.post("/api/v1/auth/pin/verify",
                           json={"pin": "5678"},
                           headers=auth_headers)
    assert r2.status_code == 200
    assert "access_token" in r2.json()


@pytest.mark.asyncio
async def test_pin_mismatch_rejected(client: AsyncClient, auth_headers):
    resp = await client.post("/api/v1/auth/pin/setup",
                             json={"pin": "1111", "confirm_pin": "2222"},
                             headers=auth_headers)
    assert resp.status_code == 422  # Pydantic validation


@pytest.mark.asyncio
async def test_pin_wrong_returns_swahili_message(client: AsyncClient, auth_headers):
    # First set a PIN
    await client.post("/api/v1/auth/pin/setup",
                      json={"pin": "9999", "confirm_pin": "9999"},
                      headers=auth_headers)
    # Try wrong PIN
    resp = await client.post("/api/v1/auth/pin/verify",
                             json={"pin": "0000"},
                             headers=auth_headers)
    assert resp.status_code == 401
    detail = resp.json()["detail"]
    # Should contain Swahili word "majaribio" or "PIN"
    assert "PIN" in detail or "majaribio" in detail or "remaining" in detail.lower()


@pytest.mark.asyncio
async def test_pin_reset_flow(client: AsyncClient, test_user):
    resp = await client.post("/api/v1/auth/pin/reset/request",
                             json={"phone_number": "+254799000001"})
    assert resp.status_code == 200
    data = resp.json()
    # In debug mode, code is returned for testing
    assert "message" in data


# ── Chama & Dashboard ─────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_create_chama(client: AsyncClient, auth_headers):
    resp = await client.post("/api/v1/chamas", json={
        "name": "Pamoja Savings Group",
        "monthly_contribution": 3000,
        "county": "Mombasa",
    }, headers=auth_headers)
    assert resp.status_code == 201
    assert resp.json()["name"] == "Pamoja Savings Group"


@pytest.mark.asyncio
async def test_list_chamas(client: AsyncClient, auth_headers, test_chama):
    resp = await client.get("/api/v1/chamas", headers=auth_headers)
    assert resp.status_code == 200
    assert len(resp.json()) >= 1


@pytest.mark.asyncio
async def test_dashboard(client: AsyncClient, auth_headers, test_chama):
    resp = await client.get(
        f"/api/v1/chamas/{test_chama.id}/dashboard",
        headers=auth_headers,
    )
    assert resp.status_code == 200
    d = resp.json()
    assert "total_savings" in d
    assert "active_members" in d
    assert "savings_trend" in d
    assert len(d["savings_trend"]) == 6  # 6 months


@pytest.mark.asyncio
async def test_non_member_cannot_access_dashboard(client: AsyncClient, test_chama):
    import time
    phone = f"+254799{int(time.time()) % 1000000:06d}"
    await client.post("/api/v1/auth/register", json={
        "full_name": "Stranger Mtu",
        "phone_number": phone,
        "password": "Password123!",
    })
    login = await client.post("/api/v1/auth/login", json={
        "phone_number": phone,
        "password": "Password123!",
    })
    assert login.status_code == 200
    stranger_headers = {"Authorization": f"Bearer {login.json()['access_token']}"}
    resp = await client.get(
        f"/api/v1/chamas/{test_chama.id}/dashboard",
        headers=stranger_headers,
    )
    assert resp.status_code == 403


# ── Loan Calculation Engines ──────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_flat_rate_calculation_api(client: AsyncClient, auth_headers, test_chama):
    resp = await client.post(
        f"/api/v1/chamas/{test_chama.id}/loans/calculate",
        json={
            "principal": 50000,
            "repayment_months": 12,
            "interest_method": "flat_rate",
        },
        headers=auth_headers,
    )
    assert resp.status_code == 200
    d = resp.json()
    assert d["interest_method"] == "flat_rate"
    assert float(d["total_interest"]) == pytest.approx(5000.0, rel=0.01)
    assert float(d["total_repayable"]) == pytest.approx(55000.0, rel=0.01)
    assert float(d["monthly_installment"]) == pytest.approx(4583.33, rel=0.01)
    assert len(d["schedule"]) == 12
    # Balance should reach 0 at end
    assert d["schedule"][-1]["balance"] == pytest.approx(0.0, abs=5.0)


@pytest.mark.asyncio
async def test_reducing_balance_calculation_api(client: AsyncClient, auth_headers, test_chama):
    resp = await client.post(
        f"/api/v1/chamas/{test_chama.id}/loans/calculate",
        json={
            "principal": 50000,
            "repayment_months": 12,
            "interest_method": "reducing_balance",
        },
        headers=auth_headers,
    )
    assert resp.status_code == 200
    d = resp.json()
    # Reducing balance should cost LESS total interest than flat
    assert float(d["total_interest"]) < 5000.0
    # Schedule should have 12 entries
    assert len(d["schedule"]) == 12
    # Final balance ≈ 0
    assert d["schedule"][-1]["balance"] == pytest.approx(0.0, abs=5.0)


def test_flat_rate_unit():
    """Unit test — no HTTP, pure math verification."""
    from app.services.loan_service import calculate_flat_rate
    r = calculate_flat_rate(Decimal("100000"), Decimal("0.10"), 12)
    assert r["total_interest"] == Decimal("10000")
    assert r["total_repayable"] == Decimal("110000")
    assert len(r["schedule"]) == 12


def test_reducing_balance_unit():
    """Unit test — reducing balance math."""
    from app.services.loan_service import calculate_reducing_balance
    r = calculate_reducing_balance(Decimal("100000"), Decimal("0.12"), 12)
    # Total interest must be less than flat rate equivalent
    flat_interest = Decimal("100000") * Decimal("0.10")
    assert r["total_interest"] < flat_interest
    # Final balance must be essentially zero
    assert abs(r["schedule"][-1]["balance"]) < 1.0


# ── Loan Application & Approval ───────────────────────────────────────────────

@pytest.mark.asyncio
async def test_loan_apply_and_approve(client: AsyncClient, auth_headers, test_chama, db):
    members = await client.get(
        f"/api/v1/chamas/{test_chama.id}/members",
        headers=auth_headers,
    )
    member_id = members.json()[0]["id"]

    # Apply
    apply_resp = await client.post(
        f"/api/v1/chamas/{test_chama.id}/loans",
        json={
            "member_id": member_id,
            "principal": 20000,
            "purpose": "Mtaji wa biashara ndogo / Small business capital",
            "repayment_months": 6,
            "interest_method": "flat_rate",
        },
        headers=auth_headers,
    )
    assert apply_resp.status_code == 201
    loan = apply_resp.json()
    assert loan["status"] == "pending"
    loan_id = loan["id"]

    # Approve
    approve_resp = await client.post(
        f"/api/v1/chamas/{test_chama.id}/loans/{loan_id}/approve",
        json={"approved": True},
        headers=auth_headers,
    )
    assert approve_resp.status_code == 200
    assert approve_resp.json()["status"] == "disbursed"


@pytest.mark.asyncio
async def test_loan_exceeds_limit_rejected(client: AsyncClient, auth_headers, test_chama):
    members = await client.get(
        f"/api/v1/chamas/{test_chama.id}/members",
        headers=auth_headers,
    )
    member_id = members.json()[0]["id"]

    # Try to borrow more than 3x savings (savings=50000, limit=150000)
    resp = await client.post(
        f"/api/v1/chamas/{test_chama.id}/loans",
        json={
            "member_id": member_id,
            "principal": 200000,  # Exceeds 3x limit
            "purpose": "Too much money",
            "repayment_months": 12,
        },
        headers=auth_headers,
    )
    assert resp.status_code in (400, 422)  # 422 from Pydantic, 400 from our check
    detail = resp.json()["detail"].lower()
    assert any(word in detail for word in ["limit", "kikomo", "exceeds", "maximum", "inazidi"])


# ── Contributions ─────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_log_contribution(client: AsyncClient, auth_headers, test_chama):
    from datetime import date
    members = await client.get(
        f"/api/v1/chamas/{test_chama.id}/members",
        headers=auth_headers,
    )
    member_id = members.json()[0]["id"]

    resp = await client.post(
        f"/api/v1/chamas/{test_chama.id}/contributions",
        json={
            "member_id": member_id,
            "amount": 5000,
            "contribution_type": "regular_savings",
            "period_month": 6,
            "period_year": 2025,
            "due_date": "2025-06-05",
            "mpesa_ref": "QXYZ123456",
            "status": "paid",
        },
        headers=auth_headers,
    )
    assert resp.status_code == 201
    assert resp.json()["status"] == "paid"
    assert float(resp.json()["amount"]) == 5000.0


@pytest.mark.asyncio
async def test_contribution_summary(client: AsyncClient, auth_headers, test_chama):
    resp = await client.get(
        f"/api/v1/chamas/{test_chama.id}/contributions/summary",
        params={"year": 2025, "month": 6},
        headers=auth_headers,
    )
    assert resp.status_code == 200
    assert "compliance_rate" in resp.json()


# ── Security Headers ──────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_security_headers_present(client: AsyncClient):
    resp = await client.get("/health")
    assert resp.status_code == 200
    assert "x-frame-options" in resp.headers
    assert resp.headers["x-frame-options"] == "DENY"
    assert "x-content-type-options" in resp.headers


# ── Swahili Messages ──────────────────────────────────────────────────────────

def test_swahili_translations_complete():
    """All message keys must have both 'en' and 'sw' translations."""
    from app.i18n.messages import MESSAGES, t
    for key, translations in MESSAGES.items():
        assert "en" in translations, f"Missing English for key: {key}"
        assert "sw" in translations, f"Missing Swahili for key: {key}"

    # Test formatting works
    msg = t("pin_wrong", lang="sw", remaining=3)
    assert "3" in msg

    msg_en = t("pin_wrong", lang="en", remaining=2)
    assert "2" in msg_en


def test_swahili_defaults_to_sw():
    """t() should return Swahili by default."""
    from app.i18n.messages import t
    msg = t("login_failed")
    # Swahili version contains "nambari" or similar Swahili word
    assert len(msg) > 0


# ── Health Check ──────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_health_check(client: AsyncClient):
    resp = await client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] in ("ok", "degraded")
    assert "version" in data
    assert "database" in data
