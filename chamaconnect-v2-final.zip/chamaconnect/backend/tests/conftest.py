"""
Test configuration — SQLite in-memory per session. No Docker needed.
"""
import asyncio
import os
import pytest
import pytest_asyncio
from decimal import Decimal
from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession

os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///./test_chama.db")
os.environ.setdefault("SECRET_KEY", "test-secret-not-for-prod-testing-only-32chars")
os.environ.setdefault("APP_ENV", "test")
os.environ.setdefault("DEBUG", "true")
os.environ.setdefault("SMS_ENABLED", "false")
os.environ.setdefault("MPESA_ENV", "sandbox")
os.environ.setdefault("POSTGRES_PASSWORD", "testonly")

# Must import AFTER env vars are set
from app.main import create_app
from app.db.database import Base, get_db
from app.core.security import hash_secret
from app.models.models import User, Chama, ChamaMember, ChamaMemberRole, Network, UserRole

# Unique DB per session via tmpfile
import tempfile, pathlib
_tmp = tempfile.mktemp(suffix=".db")
TEST_DB_URL = f"sqlite+aiosqlite:///{_tmp}"

test_engine = create_async_engine(TEST_DB_URL, echo=False)
TestSession = async_sessionmaker(test_engine, expire_on_commit=False)


@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture(scope="session")
async def db_setup():
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await test_engine.dispose()
    try:
        pathlib.Path(_tmp).unlink(missing_ok=True)
    except Exception:
        pass


@pytest_asyncio.fixture
async def db(db_setup) -> AsyncSession:
    async with TestSession() as session:
        yield session
        await session.rollback()


@pytest_asyncio.fixture
async def client(db):
    app = create_app()
    async def override_get_db():
        yield db
    app.dependency_overrides[get_db] = override_get_db
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        yield ac


@pytest_asyncio.fixture
async def test_user(db) -> User:
    user = User(
        full_name="Test Mwanachama",
        phone_number="+254799000001",
        email="test@chamaconnect.app",
        hashed_password=hash_secret("Password123!"),
        hashed_pin=hash_secret("1234"),
        is_pin_set=True,
        is_active=True,
        is_verified=True,
        network=Network.SAFARICOM,
        role=UserRole.MEMBER,
    )
    db.add(user)
    await db.flush()
    return user


@pytest_asyncio.fixture
async def auth_headers(client, test_user) -> dict:
    resp = await client.post("/api/v1/auth/login", json={
        "phone_number": "+254799000001",
        "password": "Password123!",
    })
    assert resp.status_code == 200, f"Login failed: {resp.text}"
    token = resp.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


@pytest_asyncio.fixture
async def test_chama(db, test_user) -> Chama:
    chama = Chama(
        name="Test Chama ya Majaribio",
        monthly_contribution=Decimal("5000"),
        flat_interest_rate=Decimal("0.10"),
        reducing_interest_rate=Decimal("0.12"),
        default_interest_method="flat_rate",
        max_loan_multiplier=Decimal("3.00"),
        mpesa_till="1234567",
    )
    db.add(chama)
    await db.flush()
    member = ChamaMember(
        chama_id=chama.id,
        user_id=test_user.id,
        role=ChamaMemberRole.CHAIRPERSON,
        member_number="M001",
        total_savings=Decimal("50000"),
    )
    db.add(member)
    await db.flush()
    return chama
