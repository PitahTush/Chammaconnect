"""
ChamaConnect v2 — Database Seeder
Loads realistic Kenyan chama demo data.

Run: python seed.py

Security: demo credentials shown ONLY after successful seed — not during.
"""
import asyncio
import random
from datetime import date, datetime, timezone, timedelta
from decimal import Decimal

from sqlalchemy import text, select

from app.core.config import settings
from app.core.security import hash_secret
from app.db.database import AsyncSessionLocal, engine, Base
from app.models.models import (
    User, Chama, ChamaMember, Contribution, Loan, LoanRepayment,
    MerryGoRoundSlot, Meeting,
    UserRole, ChamaMemberRole, ContributionType, ContributionStatus,
    LoanStatus, InterestMethod, Network,
)
from app.services.loan_service import calculate_loan

MEMBERS_DATA = [
    ("Grace Wanjiku Mwangi",    "+254712345678", "grace@email.com",    Network.SAFARICOM, ChamaMemberRole.CHAIRPERSON),
    ("Peter Kamau Njoroge",     "+254722456789", "peter@email.com",    Network.SAFARICOM, ChamaMemberRole.TREASURER),
    ("Fatuma Abdi Hassan",      "+254733567890", "fatuma@email.com",   Network.AIRTEL,    ChamaMemberRole.SECRETARY),
    ("James Otieno Odhiambo",   "+254741678901", "james@email.com",    Network.SAFARICOM, ChamaMemberRole.MEMBER),
    ("Mary Njeri Githui",       "+254750789012", "mary@email.com",     Network.SAFARICOM, ChamaMemberRole.MEMBER),
    ("Samuel Kipchoge Mutai",   "+254701890123", "samuel@email.com",   Network.SAFARICOM, ChamaMemberRole.MEMBER),
    ("Amina Wafula Shikuku",    "+254711901234", "amina@email.com",    Network.AIRTEL,    ChamaMemberRole.MEMBER),
    ("David Mwenda Kirori",     "+254720012345", "david@email.com",    Network.SAFARICOM, ChamaMemberRole.MEMBER),
    ("Beatrice Achieng Ouma",   "+254798123456", "beatrice@email.com", Network.SAFARICOM, ChamaMemberRole.MEMBER),
    ("Charles Ndungu Gachui",   "+254732234567", "charles@email.com",  Network.SAFARICOM, ChamaMemberRole.MEMBER),
    ("Rose Akinyi Onyango",     "+254745345678", "rose@email.com",     Network.AIRTEL,    ChamaMemberRole.MEMBER),
    ("Tom Mbugua Waweru",       "+254708456789", "tom@email.com",      Network.SAFARICOM, ChamaMemberRole.MEMBER),
]

SAVINGS = [42500, 38000, 35500, 30000, 28000, 27500, 25000, 22500, 18000, 15000, 12000, 9000]

LOAN_DATA = [
    (1,  25000, "Mtaji wa biashara / Business capital",   6, InterestMethod.FLAT_RATE,       5000),
    (3,  20000, "Ada ya shule / School fees",             4, InterestMethod.FLAT_RATE,       8000),
    (5,  15000, "Ukarabati nyumba / Home improvement",    3, InterestMethod.FLAT_RATE,       0),
    (7,   8000, "Dharura ya hospitali / Medical",         2, InterestMethod.FLAT_RATE,       2000),
    (9,  30000, "Ununuzi wa ardhi / Land purchase",      12, InterestMethod.REDUCING_BALANCE, 0),
]


def _ref():
    return "".join(random.choices("ABCDEFGHJKLMNPQRSTUVWXYZ0123456789", k=10))


async def seed():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with AsyncSessionLocal() as db:
        # Check if already seeded
        result = await db.execute(text("SELECT COUNT(*) FROM users"))
        if result.scalar() > 0:
            print("✓ Database already seeded. Skipping.")
            return

        print("🌱 Seeding ChamaConnect database with Kenyan demo data...")

        # ── Chama ────────────────────────────────────────────
        chama = Chama(
            name="Umoja wa Nguvu",
            description="Kikundi cha akiba na uwekezaji Nairobi. A progressive savings and investment group in Nairobi.",
            county="Nairobi",
            monthly_contribution=Decimal("5000"),
            welfare_contribution=Decimal("500"),
            registration_fee=Decimal("1000"),
            flat_interest_rate=Decimal("0.10"),
            reducing_interest_rate=Decimal("0.12"),
            default_interest_method=InterestMethod.FLAT_RATE,
            max_loan_multiplier=Decimal("3.00"),
            late_penalty_rate=Decimal("0.02"),
            mpesa_till="5471823",
            mpesa_paybill="247247",
            merry_go_round_amount=Decimal("60000"),
            merry_go_round_active=True,
            next_meeting_date=date(2025, 6, 28),
            meeting_venue="Chiromo Hall, Westlands, Nairobi",
        )
        db.add(chama)
        await db.flush()

        # ── Users + Members ───────────────────────────────────
        # Hash once — same for all demo accounts
        pw_hash = hash_secret("Password123!")
        pin_hash = hash_secret("1234")

        users = []
        members = []
        for i, (name, phone, email, network, role) in enumerate(MEMBERS_DATA):
            user = User(
                full_name=name,
                phone_number=phone,
                email=email,
                network=network,
                hashed_password=pw_hash,
                hashed_pin=pin_hash,
                is_pin_set=True,
                is_active=True,
                is_verified=True,
                role=UserRole.MEMBER,
            )
            db.add(user)
            await db.flush()
            users.append(user)

            member = ChamaMember(
                chama_id=chama.id,
                user_id=user.id,
                role=role,
                member_number=f"M{i+1:03d}",
                joined_at=date(2024, 1, 15),
                is_active=True,
                is_defaulting=(i in [9, 10]),
                total_savings=Decimal(str(SAVINGS[i])),
                total_contributed=Decimal(str(SAVINGS[i])),
            )
            db.add(member)
            await db.flush()
            members.append(member)

        # ── Contributions (6 months) ──────────────────────────
        today = date.today()
        for month_offset in range(5, -1, -1):
            m = today.month - month_offset
            y = today.year
            while m < 1:
                m += 12
                y -= 1
            due = date(y, m, 5)

            for i, member in enumerate(members):
                is_late = (i in [9, 10] and month_offset <= 1)
                is_pending = (i in [9, 10] and month_offset == 0)
                s = (
                    ContributionStatus.PENDING if is_pending
                    else ContributionStatus.LATE if is_late
                    else ContributionStatus.PAID
                )
                paid_at = None
                mpesa_ref = None
                if s == ContributionStatus.PAID:
                    mpesa_ref = _ref()
                    paid_at = datetime(y, m, random.randint(1, 7), tzinfo=timezone.utc)

                db.add(Contribution(
                    chama_id=chama.id,
                    member_id=member.id,
                    amount=Decimal("5000"),
                    contribution_type=ContributionType.REGULAR_SAVINGS,
                    status=s,
                    period_month=m,
                    period_year=y,
                    due_date=due,
                    paid_at=paid_at,
                    mpesa_ref=mpesa_ref,
                ))

            # Welfare contributions for first 5 members
            for i in range(5):
                db.add(Contribution(
                    chama_id=chama.id,
                    member_id=members[i].id,
                    amount=Decimal("500"),
                    contribution_type=ContributionType.WELFARE,
                    status=ContributionStatus.PAID,
                    period_month=m,
                    period_year=y,
                    due_date=due,
                    paid_at=datetime(y, m, 3, tzinfo=timezone.utc),
                    mpesa_ref=_ref(),
                ))

        await db.flush()

        # ── Loans ────────────────────────────────────────────
        import string as _s
        for mem_idx, principal, purpose, months, method, paid in LOAN_DATA:
            member = members[mem_idx]
            rate = (
                chama.flat_interest_rate
                if method == InterestMethod.FLAT_RATE
                else chama.reducing_interest_rate
            )
            calc = calculate_loan(Decimal(str(principal)), rate, months, method)
            suffix = "".join(random.choices(_s.ascii_uppercase + _s.digits, k=5))
            ln_num = f"LN250114{suffix}"

            loan = Loan(
                chama_id=chama.id,
                member_id=member.id,
                loan_number=ln_num,
                purpose=purpose,
                principal=Decimal(str(principal)),
                interest_method=method,
                interest_rate=rate,
                repayment_months=months,
                monthly_installment=calc["monthly_installment"],
                total_interest=calc["total_interest"],
                total_repayable=calc["total_repayable"],
                outstanding_balance=Decimal(str(principal - paid)),
                amount_repaid=Decimal(str(paid)),
                status=LoanStatus.ACTIVE,
                applied_at=datetime(2025, 1, 10, tzinfo=timezone.utc),
                approved_at=datetime(2025, 1, 12, tzinfo=timezone.utc),
                disbursed_at=datetime(2025, 1, 14, tzinfo=timezone.utc),
                due_date=today + timedelta(days=30 * (months - 2)),
                approved_by_id=users[0].id,
            )
            db.add(loan)
            await db.flush()
            member.active_loan_balance = Decimal(str(principal - paid))

            if paid > 0:
                db.add(LoanRepayment(
                    loan_id=loan.id,
                    amount=Decimal(str(paid)),
                    principal_portion=Decimal(str(int(paid * 0.8))),
                    interest_portion=Decimal(str(int(paid * 0.2))),
                    paid_at=datetime(2025, 3, 5, tzinfo=timezone.utc),
                    mpesa_ref=_ref(),
                ))

        # ── Merry-Go-Round ────────────────────────────────────
        for i, member in enumerate(members):
            received = i < 5
            db.add(MerryGoRoundSlot(
                chama_id=chama.id,
                member_id=member.id,
                cycle_year=today.year,
                position=i + 1,
                payout_month=i + 1,
                payout_amount=Decimal("60000"),
                received=received,
                received_at=(
                    datetime(today.year, i + 1, 28, tzinfo=timezone.utc)
                    if received else None
                ),
            ))

        # ── Meeting ───────────────────────────────────────────
        db.add(Meeting(
            chama_id=chama.id,
            title="Mkutano wa Juni 2025 / June 2025 Monthly Meeting",
            scheduled_at=datetime(2025, 6, 28, 10, 0, tzinfo=timezone.utc),
            venue="Chiromo Hall, Westlands, Nairobi",
            agenda=(
                "1. Mapitio ya mchango wa Mei / Review May contributions\n"
                "2. Maombi ya mikopo / Loan applications\n"
                "3. Mzunguko wa fedha / Merry-Go-Round update\n"
                "4. Mambo mengine / AOB"
            ),
        ))

        await db.commit()

    # Print credentials AFTER commit — never during db operations
    print("")
    print("=" * 60)
    print("✅  ChamaConnect seeding complete!")
    print("=" * 60)
    print(f"  Chama:      Umoja wa Nguvu")
    print(f"  Members:    {len(MEMBERS_DATA)}")
    print(f"  Loans:      {len(LOAN_DATA)} active")
    print("")
    print("🔐 Demo login credentials (same for all members):")
    print(f"  Phone:      +254712345678  (Grace — Chairperson)")
    print(f"  Password:   Password123!")
    print(f"  PIN:        1234")
    print("")
    print("📚 API docs:   http://localhost:8000/api/docs")
    print("❤️  Health:    http://localhost:8000/health")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(seed())
