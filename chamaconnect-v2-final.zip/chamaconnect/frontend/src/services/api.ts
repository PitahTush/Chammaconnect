/**
 * ChamaConnect API Client
 * Axios instance with JWT auth, token refresh, and error handling.
 */
import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from "axios";
import * as SecureStore from "expo-secure-store";

const BASE_URL = process.env.EXPO_PUBLIC_API_URL || "http://localhost:8000/api/v1";

const ACCESS_TOKEN_KEY = "chama_access_token";
const REFRESH_TOKEN_KEY = "chama_refresh_token";

export const api: AxiosInstance = axios.create({
  baseURL: BASE_URL,
  timeout: 15000,
  headers: { "Content-Type": "application/json" },
});

// ── Request interceptor: attach access token ─────────────────────────────────
api.interceptors.request.use(async (config) => {
  const token = await SecureStore.getItemAsync(ACCESS_TOKEN_KEY);
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// ── Response interceptor: auto-refresh on 401 ────────────────────────────────
let refreshing = false;
let failedQueue: Array<{ resolve: Function; reject: Function }> = [];

const processQueue = (error: Error | null, token: string | null) => {
  failedQueue.forEach((p) => (error ? p.reject(error) : p.resolve(token)));
  failedQueue = [];
};

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const original = error.config;
    if (error.response?.status === 401 && !original._retry) {
      if (refreshing) {
        return new Promise((resolve, reject) => {
          failedQueue.push({ resolve, reject });
        }).then((token) => {
          original.headers.Authorization = `Bearer ${token}`;
          return api(original);
        });
      }
      original._retry = true;
      refreshing = true;

      try {
        const refresh = await SecureStore.getItemAsync(REFRESH_TOKEN_KEY);
        if (!refresh) throw new Error("No refresh token");
        const resp = await axios.post(`${BASE_URL}/auth/refresh`, {
          refresh_token: refresh,
        });
        const { access_token, refresh_token } = resp.data;
        await SecureStore.setItemAsync(ACCESS_TOKEN_KEY, access_token);
        await SecureStore.setItemAsync(REFRESH_TOKEN_KEY, refresh_token);
        processQueue(null, access_token);
        original.headers.Authorization = `Bearer ${access_token}`;
        return api(original);
      } catch (err) {
        processQueue(err as Error, null);
        await SecureStore.deleteItemAsync(ACCESS_TOKEN_KEY);
        await SecureStore.deleteItemAsync(REFRESH_TOKEN_KEY);
        return Promise.reject(err);
      } finally {
        refreshing = false;
      }
    }
    return Promise.reject(error);
  }
);

// ── Auth helpers ─────────────────────────────────────────────────────────────

export const saveTokens = async (access: string, refresh: string) => {
  await SecureStore.setItemAsync(ACCESS_TOKEN_KEY, access);
  await SecureStore.setItemAsync(REFRESH_TOKEN_KEY, refresh);
};

export const clearTokens = async () => {
  await SecureStore.deleteItemAsync(ACCESS_TOKEN_KEY);
  await SecureStore.deleteItemAsync(REFRESH_TOKEN_KEY);
};

export const getAccessToken = () => SecureStore.getItemAsync(ACCESS_TOKEN_KEY);

// ── API service functions ─────────────────────────────────────────────────────

export const authService = {
  register: (data: any) => api.post("/auth/register", data),
  login: (data: any) => api.post("/auth/login", data),
  me: () => api.get("/auth/me"),
  setPin: (data: any) => api.post("/auth/pin/setup", data),
  verifyPin: (data: any) => api.post("/auth/pin/verify", data),
  requestPinReset: (data: any) => api.post("/auth/pin/reset/request", data),
  verifyPinReset: (data: any) => api.post("/auth/pin/reset/verify", data),
};

export const chamaService = {
  list: () => api.get("/chamas"),
  create: (data: any) => api.post("/chamas", data),
  get: (id: string) => api.get(`/chamas/${id}`),
  update: (id: string, data: any) => api.patch(`/chamas/${id}`, data),
  dashboard: (id: string) => api.get(`/chamas/${id}/dashboard`),
};

export const memberService = {
  list: (chamaId: string) => api.get(`/chamas/${chamaId}/members`),
  add: (chamaId: string, data: any) => api.post(`/chamas/${chamaId}/members`, data),
  updateRole: (chamaId: string, memberId: string, role: string) =>
    api.patch(`/chamas/${chamaId}/members/${memberId}/role`, { role }),
  remove: (chamaId: string, memberId: string) =>
    api.delete(`/chamas/${chamaId}/members/${memberId}`),
};

export const contributionService = {
  list: (chamaId: string, params?: any) =>
    api.get(`/chamas/${chamaId}/contributions`, { params }),
  log: (chamaId: string, data: any) =>
    api.post(`/chamas/${chamaId}/contributions`, data),
  summary: (chamaId: string, year: number, month: number) =>
    api.get(`/chamas/${chamaId}/contributions/summary`, { params: { year, month } }),
};

export const loanService = {
  list: (chamaId: string, params?: any) =>
    api.get(`/chamas/${chamaId}/loans`, { params }),
  pending: (chamaId: string) => api.get(`/chamas/${chamaId}/loans/pending`),
  calculate: (chamaId: string, data: any) =>
    api.post(`/chamas/${chamaId}/loans/calculate`, data),
  apply: (chamaId: string, data: any) => api.post(`/chamas/${chamaId}/loans`, data),
  approve: (chamaId: string, loanId: string, data: any) =>
    api.post(`/chamas/${chamaId}/loans/${loanId}/approve`, data),
  repay: (chamaId: string, loanId: string, data: any) =>
    api.post(`/chamas/${chamaId}/loans/${loanId}/repay`, data),
};

export const smsService = {
  reminders: (chamaId: string) => api.get(`/chamas/${chamaId}/sms/reminders`),
  send: (chamaId: string, data: any) => api.post(`/chamas/${chamaId}/sms/send`, data),
};

export const paymentService = {
  stkPush: (chamaId: string, data: any) =>
    api.post(`/chamas/${chamaId}/payments/stk-push`, data),
};

export const merryGoRoundService = {
  slots: (chamaId: string, year?: number) =>
    api.get(`/chamas/${chamaId}/merry-go-round`, { params: { cycle_year: year } }),
};
