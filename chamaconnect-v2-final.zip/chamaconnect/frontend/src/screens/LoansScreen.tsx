/**
 * LoansScreen — active loans, pending approvals, apply form,
 * and live interest calculator (flat rate vs reducing balance).
 */
import React, { useState } from "react";
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, ActivityIndicator, TextInput, Alert,
} from "react-native";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { loanService, memberService } from "../services/api";
import { useAppStore } from "../store/appStore";
import { Colors, Spacing, Radius, FontSize, Shadow, formatKESFull } from "../utils/theme";

type Tab = "active" | "pending" | "apply" | "calc";

export default function LoansScreen() {
  const { activeChamaId } = useAppStore();
  const [tab, setTab] = useState<Tab>("active");
  const queryClient = useQueryClient();

  // ── Queries ───────────────────────────────────────────────
  const { data: activeLoans = [], isLoading: activeLoading } = useQuery({
    queryKey: ["loans", activeChamaId, "active"],
    queryFn: () => loanService.list(activeChamaId!, { status: "active" }).then((r) => r.data),
    enabled: !!activeChamaId,
  });

  const { data: pendingLoans = [], isLoading: pendingLoading } = useQuery({
    queryKey: ["loans", activeChamaId, "pending"],
    queryFn: () => loanService.pending(activeChamaId!).then((r) => r.data),
    enabled: !!activeChamaId,
  });

  const { data: members = [] } = useQuery({
    queryKey: ["members", activeChamaId],
    queryFn: () => memberService.list(activeChamaId!).then((r) => r.data),
    enabled: !!activeChamaId,
  });

  // ── Approve mutation ──────────────────────────────────────
  const approveMutation = useMutation({
    mutationFn: ({ loanId, approved }: any) =>
      loanService.approve(activeChamaId!, loanId, { approved }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["loans", activeChamaId] });
    },
  });

  // ── Loan application form state ───────────────────────────
  const [form, setForm] = useState({ member_id: "", principal: "", repayment_months: "6", purpose: "Business capital", interest_method: "flat_rate" });
  const [calcResult, setCalcResult] = useState<any>(null);
  const [calcLoading, setCalcLoading] = useState(false);

  const applyMutation = useMutation({
    mutationFn: (data: any) => loanService.apply(activeChamaId!, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["loans", activeChamaId] });
      Alert.alert("✓ Submitted", "Your loan application has been sent for approval.");
      setForm({ member_id: "", principal: "", repayment_months: "6", purpose: "Business capital", interest_method: "flat_rate" });
      setCalcResult(null);
      setTab("pending");
    },
    onError: (e: any) => Alert.alert("Error", e?.response?.data?.detail || "Submission failed"),
  });

  const handleCalculate = async () => {
    if (!form.principal || !form.repayment_months) return;
    setCalcLoading(true);
    try {
      const r = await loanService.calculate(activeChamaId!, {
        principal: parseFloat(form.principal),
        repayment_months: parseInt(form.repayment_months),
        interest_method: form.interest_method,
      });
      setCalcResult(r.data);
    } catch (e) {}
    setCalcLoading(false);
  };

  const toggleMethod = (m: string) => {
    setForm((f) => ({ ...f, interest_method: m }));
    setCalcResult(null);
  };

  // ── Calculator tab state ──────────────────────────────────
  const [calcForm, setCalcForm] = useState({ principal: "50000", months: "12", rate: "10", method: "flat_rate" });
  const [calcRes, setCalcRes] = useState<any>(null);

  const runCalc = async () => {
    try {
      const r = await loanService.calculate(activeChamaId!, {
        principal: parseFloat(calcForm.principal),
        repayment_months: parseInt(calcForm.months),
        interest_method: calcForm.method,
        interest_rate: parseFloat(calcForm.rate) / 100,
      });
      setCalcRes(r.data);
    } catch (e) {}
  };

  const TABS: { key: Tab; label: string }[] = [
    { key: "active", label: `Active (${activeLoans.length})` },
    { key: "pending", label: `Pending (${pendingLoans.length})` },
    { key: "apply", label: "Apply" },
    { key: "calc", label: "Calculator" },
  ];

  return (
    <View style={styles.container}>
      {/* Tab bar */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabBar} contentContainerStyle={{ gap: 8, paddingHorizontal: Spacing.lg }}>
        {TABS.map((t) => (
          <TouchableOpacity key={t.key} style={[styles.tab, tab === t.key && styles.tabActive]} onPress={() => setTab(t.key)}>
            <Text style={[styles.tabText, tab === t.key && styles.tabTextActive]}>{t.label}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <ScrollView style={styles.body} contentContainerStyle={{ padding: Spacing.lg, paddingBottom: 80 }} showsVerticalScrollIndicator={false}>

        {/* ── Active loans ──────────────────────────────── */}
        {tab === "active" && (
          activeLoading ? <ActivityIndicator color={Colors.green600} style={{ marginTop: 40 }} /> :
          activeLoans.length === 0 ? <EmptyState icon="🎉" text="No active loans" /> :
          activeLoans.map((loan: any) => <LoanCard key={loan.id} loan={loan} />)
        )}

        {/* ── Pending loans ─────────────────────────────── */}
        {tab === "pending" && (
          pendingLoading ? <ActivityIndicator color={Colors.green600} style={{ marginTop: 40 }} /> :
          pendingLoans.length === 0 ? <EmptyState icon="🎉" text="No pending applications" /> :
          pendingLoans.map((loan: any) => (
            <PendingCard
              key={loan.id}
              loan={loan}
              onApprove={() => approveMutation.mutate({ loanId: loan.id, approved: true })}
              onReject={() => approveMutation.mutate({ loanId: loan.id, approved: false })}
            />
          ))
        )}

        {/* ── Apply form ────────────────────────────────── */}
        {tab === "apply" && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Loan application</Text>

            <Label>Member</Label>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 14 }}>
              <View style={{ flexDirection: "row", gap: 8 }}>
                {members.map((m: any) => (
                  <TouchableOpacity key={m.id} style={[styles.chip, form.member_id === m.id && styles.chipActive]} onPress={() => setForm((f) => ({ ...f, member_id: m.id }))}>
                    <Text style={[styles.chipText, form.member_id === m.id && styles.chipTextActive]}>
                      {m.full_name.split(" ")[0]}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>

            <Label>Amount (KES)</Label>
            <TextInput style={styles.input} keyboardType="numeric" placeholder="20,000" value={form.principal} onChangeText={(v) => { setForm((f) => ({ ...f, principal: v })); setCalcResult(null); }} onBlur={handleCalculate} />

            <Label>Period (months)</Label>
            <TextInput style={styles.input} keyboardType="numeric" value={form.repayment_months} onChangeText={(v) => { setForm((f) => ({ ...f, repayment_months: v })); setCalcResult(null); }} onBlur={handleCalculate} />

            <Label>Purpose</Label>
            <TextInput style={styles.input} value={form.purpose} onChangeText={(v) => setForm((f) => ({ ...f, purpose: v }))} />

            <Label>Interest method</Label>
            <View style={styles.toggle}>
              <TouchableOpacity style={[styles.toggleOpt, form.interest_method === "flat_rate" && styles.toggleOptActive]} onPress={() => { toggleMethod("flat_rate"); setTimeout(handleCalculate, 100); }}>
                <Text style={[styles.toggleText, form.interest_method === "flat_rate" && styles.toggleTextActive]}>Flat rate (10%)</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.toggleOpt, form.interest_method === "reducing_balance" && styles.toggleOptActive]} onPress={() => { toggleMethod("reducing_balance"); setTimeout(handleCalculate, 100); }}>
                <Text style={[styles.toggleText, form.interest_method === "reducing_balance" && styles.toggleTextActive]}>Reducing (12%)</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.methodInfo}>
              <Text style={styles.methodTitle}>{form.interest_method === "flat_rate" ? "Flat rate method" : "Reducing balance method"}</Text>
              <Text style={styles.methodDesc}>
                {form.interest_method === "flat_rate"
                  ? "Interest is calculated on the original principal for the full duration. Total interest = Principal × Rate × Years."
                  : "Interest charged only on the outstanding balance each month. Reduces as you repay. Fairer for borrowers on longer loans."}
              </Text>
            </View>

            {calcLoading && <ActivityIndicator color={Colors.green600} style={{ marginVertical: 10 }} />}
            {calcResult && <CalcResult data={calcResult} />}

            <TouchableOpacity
              style={[styles.btn, (!form.member_id || !form.principal) && styles.btnDisabled]}
              disabled={!form.member_id || !form.principal || applyMutation.isPending}
              onPress={() => applyMutation.mutate({ ...form, principal: parseFloat(form.principal), repayment_months: parseInt(form.repayment_months) })}
            >
              <Text style={styles.btnText}>{applyMutation.isPending ? "Submitting…" : "Submit Application"}</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* ── Calculator ────────────────────────────────── */}
        {tab === "calc" && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Interest calculator</Text>
            <View style={styles.toggle}>
              <TouchableOpacity style={[styles.toggleOpt, calcForm.method === "flat_rate" && styles.toggleOptActive]} onPress={() => { setCalcForm((f) => ({ ...f, method: "flat_rate" })); setCalcRes(null); }}>
                <Text style={[styles.toggleText, calcForm.method === "flat_rate" && styles.toggleTextActive]}>Flat rate</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.toggleOpt, calcForm.method === "reducing_balance" && styles.toggleOptActive]} onPress={() => { setCalcForm((f) => ({ ...f, method: "reducing_balance" })); setCalcRes(null); }}>
                <Text style={[styles.toggleText, calcForm.method === "reducing_balance" && styles.toggleTextActive]}>Reducing balance</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.formRow}>
              <View style={{ flex: 1 }}>
                <Label>Principal (KES)</Label>
                <TextInput style={styles.input} keyboardType="numeric" value={calcForm.principal} onChangeText={(v) => setCalcForm((f) => ({ ...f, principal: v }))} />
              </View>
              <View style={{ flex: 1 }}>
                <Label>Months</Label>
                <TextInput style={styles.input} keyboardType="numeric" value={calcForm.months} onChangeText={(v) => setCalcForm((f) => ({ ...f, months: v }))} />
              </View>
            </View>
            <Label>Interest rate (% p.a.)</Label>
            <TextInput style={styles.input} keyboardType="numeric" value={calcForm.rate} onChangeText={(v) => setCalcForm((f) => ({ ...f, rate: v }))} />
            <TouchableOpacity style={styles.btn} onPress={runCalc}>
              <Text style={styles.btnText}>Calculate</Text>
            </TouchableOpacity>
            {calcRes && <CalcResult data={calcRes} />}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

// ── Sub-components ────────────────────────────────────────────────────────────

const Label = ({ children }: { children: string }) => (
  <Text style={styles.label}>{children}</Text>
);

const CalcResult = ({ data }: { data: any }) => (
  <View style={styles.calcBox}>
    {[
      ["Principal", formatKESFull(data.principal)],
      ["Total interest accrued", formatKESFull(data.total_interest)],
      ["Monthly installment", formatKESFull(data.monthly_installment)],
      ["Total repayment amount", formatKESFull(data.total_repayable)],
    ].map(([label, value], i) => (
      <View key={i} style={[styles.calcRow, i === 3 && styles.calcRowTotal]}>
        <Text style={[styles.calcLabel, i === 3 && { fontWeight: "700" }]}>{label}</Text>
        <Text style={[styles.calcValue, i === 3 && styles.calcValueTotal]}>{value}</Text>
      </View>
    ))}
  </View>
);

const LoanCard = ({ loan }: { loan: any }) => {
  const pct = Math.round((parseFloat(loan.amount_repaid) / parseFloat(loan.total_repayable)) * 100);
  return (
    <View style={styles.loanCard}>
      <View style={styles.loanTop}>
        <View>
          <Text style={styles.loanName}>{(loan.member_name || "").split(" ").slice(0, 2).join(" ")}</Text>
          <Text style={styles.loanPurpose}>{loan.purpose}</Text>
        </View>
        <View style={styles.badge}><Text style={styles.badgeText}>{loan.interest_method === "flat_rate" ? "Flat" : "Reducing"} {Math.round(parseFloat(loan.interest_rate) * 100)}%</Text></View>
      </View>
      <View style={styles.loanGrid}>
        {[["Principal", formatKESFull(loan.principal)], ["Total due", formatKESFull(loan.total_repayable)], ["Paid", formatKESFull(loan.amount_repaid)], ["Monthly", formatKESFull(loan.monthly_installment)]].map(([l, v]) => (
          <View key={l}>
            <Text style={styles.loanCellLabel}>{l}</Text>
            <Text style={styles.loanCellVal}>{v}</Text>
          </View>
        ))}
      </View>
      <View style={styles.progTrack}><View style={[styles.progFill, { width: `${pct}%` as any }]} /></View>
      <View style={styles.progMeta}>
        <Text style={{ fontSize: 11, color: Colors.slate500 }}>{pct}% repaid</Text>
        {loan.days_remaining != null && <Text style={styles.countdown}>⏰ {loan.days_remaining} days left</Text>}
      </View>
    </View>
  );
};

const PendingCard = ({ loan, onApprove, onReject }: any) => (
  <View style={styles.pendingCard}>
    <View style={styles.loanTop}>
      <Text style={styles.loanName}>{(loan.member_name || "").split(" ").slice(0, 2).join(" ")}</Text>
      <View style={styles.amberBadge}><Text style={styles.amberBadgeText}>Pending</Text></View>
    </View>
    <Text style={styles.loanPurpose}>{loan.purpose}</Text>
    <View style={styles.loanGrid}>
      {[["Amount", formatKESFull(loan.principal)], ["Period", `${loan.repayment_months} months`], ["Purpose", loan.purpose], ["Applied", loan.applied_at?.slice(0,10)]].map(([l, v]) => (
        <View key={l}>
          <Text style={styles.loanCellLabel}>{l}</Text>
          <Text style={[styles.loanCellVal, { fontSize: 12 }]}>{v}</Text>
        </View>
      ))}
    </View>
    <View style={styles.approveRow}>
      <TouchableOpacity style={styles.approveBtn} onPress={onApprove}><Text style={styles.approveBtnText}>✓ Approve</Text></TouchableOpacity>
      <TouchableOpacity style={styles.rejectBtn} onPress={onReject}><Text style={styles.rejectBtnText}>✗ Reject</Text></TouchableOpacity>
    </View>
  </View>
);

const EmptyState = ({ icon, text }: { icon: string; text: string }) => (
  <View style={{ alignItems: "center", paddingVertical: 40 }}>
    <Text style={{ fontSize: 40, marginBottom: 12 }}>{icon}</Text>
    <Text style={{ fontSize: FontSize.base, color: Colors.slate500 }}>{text}</Text>
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  tabBar: { backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.border, paddingVertical: Spacing.sm, flexGrow: 0 },
  tab: { height: 36, paddingHorizontal: 16, borderRadius: 20, borderWidth: 1.5, borderColor: Colors.slate300, alignItems: "center", justifyContent: "center" },
  tabActive: { backgroundColor: Colors.green700, borderColor: Colors.green700 },
  tabText: { fontSize: 13, fontWeight: "600", color: Colors.slate500 },
  tabTextActive: { color: "#fff" },
  body: { flex: 1 },

  card: { backgroundColor: Colors.surface, borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border, padding: Spacing.lg, marginBottom: Spacing.md, ...Shadow.sm },
  cardTitle: { fontSize: 15, fontWeight: "700", color: Colors.slate900, marginBottom: Spacing.lg },

  label: { fontSize: FontSize.sm, fontWeight: "600", color: Colors.slate600, marginBottom: 7, marginTop: 2 },
  input: { height: 52, borderWidth: 1.5, borderColor: Colors.slate300, borderRadius: Radius.md, paddingHorizontal: 14, fontSize: 15, color: Colors.slate900, marginBottom: 14, backgroundColor: "#fff" },
  formRow: { flexDirection: "row", gap: 12 },

  toggle: { flexDirection: "row", backgroundColor: Colors.slate100, borderRadius: Radius.md, padding: 4, marginBottom: 14 },
  toggleOpt: { flex: 1, height: 40, alignItems: "center", justifyContent: "center", borderRadius: Radius.sm },
  toggleOptActive: { backgroundColor: "#fff", shadowColor: "#000", shadowOpacity: 0.08, shadowRadius: 4, elevation: 2 },
  toggleText: { fontSize: 13, fontWeight: "600", color: Colors.slate500 },
  toggleTextActive: { color: Colors.green800 },

  methodInfo: { backgroundColor: Colors.slate100, borderRadius: Radius.md, padding: 12, marginBottom: 14 },
  methodTitle: { fontSize: 13, fontWeight: "700", color: Colors.slate900, marginBottom: 4 },
  methodDesc: { fontSize: 12, color: Colors.slate600, lineHeight: 18 },

  calcBox: { backgroundColor: Colors.green50, borderWidth: 1.5, borderColor: Colors.green100, borderRadius: Radius.lg, padding: 16, marginTop: 14 },
  calcRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 7, borderBottomWidth: 1, borderBottomColor: Colors.green100 },
  calcRowTotal: { borderBottomWidth: 0, marginTop: 4, paddingTop: 10 },
  calcLabel: { fontSize: 13, color: Colors.slate600 },
  calcValue: { fontSize: 13, fontWeight: "700", color: Colors.green900 },
  calcValueTotal: { fontSize: 17, color: Colors.green700 },

  chip: { height: 38, paddingHorizontal: 16, borderRadius: 20, borderWidth: 1.5, borderColor: Colors.slate300, alignItems: "center", justifyContent: "center", backgroundColor: "#fff" },
  chipActive: { borderColor: Colors.green500, backgroundColor: Colors.green50 },
  chipText: { fontSize: 13, fontWeight: "600", color: Colors.slate500 },
  chipTextActive: { color: Colors.green800 },

  btn: { height: 52, backgroundColor: Colors.green700, borderRadius: Radius.md, alignItems: "center", justifyContent: "center", marginTop: 16 },
  btnDisabled: { opacity: 0.4 },
  btnText: { fontSize: 15, fontWeight: "700", color: "#fff" },

  loanCard: { backgroundColor: Colors.surface, borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border, padding: 16, marginBottom: 10, ...Shadow.sm },
  pendingCard: { backgroundColor: Colors.amberLight, borderRadius: Radius.xl, borderWidth: 1, borderColor: "rgba(217,119,6,0.2)", padding: 16, marginBottom: 10 },
  loanTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 },
  loanName: { fontSize: 15, fontWeight: "700", color: Colors.slate900 },
  loanPurpose: { fontSize: 12, color: Colors.slate500, marginTop: 2 },
  loanGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginVertical: 12 },
  loanCellLabel: { fontSize: 11, color: Colors.slate500 },
  loanCellVal: { fontSize: 14, fontWeight: "700", color: Colors.slate900, marginTop: 2 },
  progTrack: { height: 5, backgroundColor: Colors.slate200, borderRadius: 3, overflow: "hidden" },
  progFill: { height: "100%", backgroundColor: Colors.green500, borderRadius: 3 },
  progMeta: { flexDirection: "row", justifyContent: "space-between", marginTop: 5 },
  countdown: { fontSize: 12, fontWeight: "600", color: Colors.amber },
  badge: { backgroundColor: Colors.slate100, borderRadius: 20, paddingHorizontal: 9, paddingVertical: 3 },
  badgeText: { fontSize: 11, fontWeight: "600", color: Colors.slate700 },
  amberBadge: { backgroundColor: Colors.amberLight, borderRadius: 20, paddingHorizontal: 9, paddingVertical: 3 },
  amberBadgeText: { fontSize: 11, fontWeight: "600", color: Colors.amber },
  approveRow: { flexDirection: "row", gap: 8, marginTop: 12 },
  approveBtn: { flex: 1, height: 42, backgroundColor: Colors.green700, borderRadius: Radius.sm, alignItems: "center", justifyContent: "center" },
  approveBtnText: { fontSize: 13, fontWeight: "700", color: "#fff" },
  rejectBtn: { flex: 1, height: 42, backgroundColor: Colors.redLight, borderRadius: Radius.sm, borderWidth: 1, borderColor: "rgba(220,38,38,0.2)", alignItems: "center", justifyContent: "center" },
  rejectBtnText: { fontSize: 13, fontWeight: "700", color: Colors.red },
});
