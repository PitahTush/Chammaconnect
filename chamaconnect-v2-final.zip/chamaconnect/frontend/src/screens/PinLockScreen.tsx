/**
 * PinLockScreen — secure PIN entry overlay.
 * Shows on app launch and resume from background.
 */
import React, { useState, useCallback } from "react";
import {
  View, Text, TouchableOpacity, StyleSheet,
  Vibration, Animated,
} from "react-native";
import { authService } from "../services/api";
import { useAppStore } from "../store/appStore";
import { Colors, Spacing, Radius, FontSize } from "../utils/theme";

const KEYS = [
  ["1", ""],   ["2", "ABC"],  ["3", "DEF"],
  ["4", "GHI"],["5", "JKL"],  ["6", "MNO"],
  ["7", "PQRS"],["8","TUV"],  ["9", "WXYZ"],
  ["", ""],   ["0", ""],    ["⌫", ""],
];

interface PinLockScreenProps {
  onForgot: () => void;
}

export default function PinLockScreen({ onForgot }: PinLockScreenProps) {
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { user, setPinVerified } = useAppStore();
  const shakeAnim = new Animated.Value(0);

  const shake = () => {
    Vibration.vibrate([0, 50, 50, 50]);
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 8,  duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -8, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 6,  duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -6, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0,  duration: 60, useNativeDriver: true }),
    ]).start();
  };

  const handleKey = useCallback(async (key: string) => {
    if (loading) return;
    if (key === "⌫") {
      setPin((p) => p.slice(0, -1));
      setError("");
      return;
    }
    if (!key || pin.length >= 4) return;

    const newPin = pin + key;
    setPin(newPin);

    if (newPin.length === 4) {
      setLoading(true);
      try {
        await authService.verifyPin({ pin: newPin });
        setPinVerified(true);
      } catch (err: any) {
        shake();
        setError(err?.response?.data?.detail || "Incorrect PIN");
        setPin("");
      } finally {
        setLoading(false);
      }
    }
  }, [pin, loading, setPinVerified]);

  return (
    <View style={styles.container}>
      <View style={styles.top}>
        <View style={styles.logoWrap}>
          <Text style={styles.logoText}>CC</Text>
        </View>
        <Text style={styles.title}>ChamaConnect</Text>
        <Text style={styles.subtitle}>
          Welcome back{user?.full_name ? `, ${user.full_name.split(" ")[0]}` : ""}
        </Text>
      </View>

      <View style={styles.body}>
        <Text style={[styles.prompt, error ? styles.promptError : {}]}>
          {error || "Enter your 4-digit PIN"}
        </Text>

        <Animated.View style={[styles.dotsRow, { transform: [{ translateX: shakeAnim }] }]}>
          {[0, 1, 2, 3].map((i) => (
            <View key={i} style={[styles.dot, i < pin.length && styles.dotFilled]} />
          ))}
        </Animated.View>

        <View style={styles.keypad}>
          {KEYS.map(([digit, sub], i) => {
            const isDelete = digit === "⌫";
            const isEmpty = digit === "" && sub === "";
            return (
              <TouchableOpacity
                key={i}
                style={[styles.key, isEmpty && styles.keyEmpty]}
                onPress={() => !isEmpty && handleKey(digit)}
                disabled={isEmpty || loading}
                activeOpacity={0.7}
              >
                {!isEmpty && (
                  <>
                    <Text style={[styles.keyDigit, isDelete && styles.keyDelete]}>{digit}</Text>
                    {sub ? <Text style={styles.keySub}>{sub}</Text> : null}
                  </>
                )}
              </TouchableOpacity>
            );
          })}
        </View>

        <TouchableOpacity onPress={onForgot} style={styles.forgotBtn}>
          <Text style={styles.forgotText}>Forgot PIN?</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.green900 },
  top: {
    backgroundColor: Colors.green800,
    paddingTop: 60, paddingBottom: 36,
    alignItems: "center",
  },
  logoWrap: {
    width: 56, height: 56, backgroundColor: Colors.green600,
    borderRadius: 18, alignItems: "center", justifyContent: "center", marginBottom: 16,
  },
  logoText: { fontSize: 20, fontWeight: "800", color: "#fff" },
  title: { fontSize: 22, fontWeight: "800", color: "#fff", letterSpacing: -0.5 },
  subtitle: { fontSize: FontSize.base, color: "rgba(255,255,255,0.5)", marginTop: 4 },

  body: { flex: 1, alignItems: "center", paddingTop: 36 },
  prompt: { fontSize: FontSize.base, color: "rgba(255,255,255,0.7)", fontWeight: "500", marginBottom: 20 },
  promptError: { color: "#FCA5A5" },

  dotsRow: { flexDirection: "row", gap: 18, marginBottom: 36 },
  dot: {
    width: 18, height: 18, borderRadius: 9,
    borderWidth: 2, borderColor: "rgba(255,255,255,0.35)",
    backgroundColor: "transparent",
  },
  dotFilled: { backgroundColor: "#fff", borderColor: "#fff" },

  keypad: {
    flexDirection: "row", flexWrap: "wrap",
    width: 300, gap: 12,
  },
  key: {
    width: 88, height: 66, backgroundColor: "rgba(255,255,255,0.08)",
    borderRadius: 20, alignItems: "center", justifyContent: "center",
  },
  keyEmpty: { backgroundColor: "transparent" },
  keyDigit: { fontSize: 22, fontWeight: "700", color: "#fff" },
  keyDelete: { fontSize: 20, color: "rgba(255,255,255,0.7)" },
  keySub: { fontSize: 9, color: "rgba(255,255,255,0.4)", letterSpacing: 1, marginTop: 2 },

  forgotBtn: { marginTop: 24 },
  forgotText: { fontSize: FontSize.base, color: "rgba(255,255,255,0.45)" },
});
