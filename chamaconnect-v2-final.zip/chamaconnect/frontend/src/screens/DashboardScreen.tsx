/**
 * Dashboard screen — connects to real API, shows live stats.
 */
import React, { useCallback } from "react";
import {
  View, Text, ScrollView, RefreshControl,
  TouchableOpacity, StyleSheet, ActivityIndicator,
} from "react-native";
import { useQuery } from "@tanstack/react-query";
import { chamaService, memberService } from "../services/api";
import { useAppStore } from "../store/appStore";
import { Colors, Spacing, Radius, Shadow, FontSize, formatKES, formatKESFull } from "../utils/theme";

// ── Sub-components ────────────────────────────────────────────────────────────

const HeroCard = ({ stats }: { stats: any }) => (
  <View style={styles.hero}>
    <Text style={styles.heroLabel}>Total Group Savings</Text>
    <Text style={styles.heroAmount}>{formatKESFull(stats?.total_savings ?? 0)}</Text>
    <Text style={styles.heroSub}>Umoja wa Nguvu Chama · {new Date().toLocaleString("en-KE", { month: "long", year: "numeric" })}</Text>
    <View style={styles.heroChips}>
      <View style={styles.heroChip}><Text style={styles.heroChipText}><Text style={styles.heroChipBold}>{stats?.active_members ?? 0}</Text> members</Text></View>
      {stats?.next_meeting_date && (
        <View style={styles.heroChip}><Text style={styles.heroChipText}>Meeting: <Text style={styles.heroChipBold}>{stats.next_meeting_date}</Text></Text></View>
      )}
      <View style={styles.heroChip}><Text style={styles.heroChipText}><Text style={styles.heroChipBold}>{stats?.pending_approvals ?? 0}</Text> pending</Text></View>
    </View>
  </View>
);

const MeetingBanner = ({ stats }: { stats: any }) => {
  if (!stats?.next_meeting_date) return null;
  return (
    <View style={styles.meetingBanner}>
      <View style={styles.meetingIconWrap}>
        <Text style={{ fontSize: 20 }}>📅</Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.meetingTitle}>{stats.next_meeting_venue || "Next Meeting"}</Text>
        <Text style={styles.meetingDate}>{stats.next_meeting_date}</Text>
      </View>
      {stats.days_to_meeting != null && (
        <View style={styles.meetingDays}>
          <Text style={styles.meetingDaysText}>{stats.days_to_meeting}d</Text>
        </View>
      )}
    </View>
  );
};

const StatCard = ({ icon, value, label, trend, trendColor }: any) => (
  <View style={styles.statCard}>
    <View style={[styles.statIcon]}><Text style={{ fontSize: 18 }}>{icon}</Text></View>
    <Text style={styles.statValue}>{value}</Text>
    <Text style={styles.statLabel}>{label}</Text>
    {trend && <Text style={[styles.statTrend, { color: trendColor || Colors.green600 }]}>{trend}</Text>}
  </View>
);

const LeaderboardRow = ({ member, rank, onPress }: any) => {
  const rankColors: Record<number, string> = { 1: "#FEF3C7", 2: Colors.slate100, 3: "#FDE8D8" };
  const rankTextColors: Record<number, string> = { 1: "#92400E", 2: Colors.slate700, 3: "#9A3412" };
  const initials = member.full_name.split(" ").slice(0, 2).map((w: string) => w[0]).join("").toUpperCase();

  return (
    <TouchableOpacity style={styles.lbRow} onPress={onPress}>
      <View style={[styles.lbRank, { backgroundColor: rankColors[rank] || Colors.green50 }]}>
        <Text style={[styles.lbRankText, { color: rankTextColors[rank] || Colors.green800 }]}>{rank}</Text>
      </View>
      <View style={[styles.avatar, { backgroundColor: Colors.green100 }]}>
        <Text style={[styles.avatarText, { color: Colors.green800 }]}>{initials}</Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.lbName} numberOfLines={1}>{member.full_name.split(" ").slice(0, 2).join(" ")}</Text>
        <View style={styles.lbBar}>
          <View style={[styles.lbFill, { width: `${Math.min(100, (member.total_savings / 42500) * 100)}%` }]} />
        </View>
      </View>
      <Text style={styles.lbAmt}>{formatKES(member.total_savings)}</Text>
      {member.is_defaulting && (
        <View style={styles.lateBadge}><Text style={styles.lateBadgeText}>Late</Text></View>
      )}
    </TouchableOpacity>
  );
};

// ── Main Screen ───────────────────────────────────────────────────────────────

export default function DashboardScreen({ navigation }: any) {
  const { activeChamaId } = useAppStore();

  const { data: stats, isLoading: statsLoading, refetch: refetchStats } = useQuery({
    queryKey: ["dashboard", activeChamaId],
    queryFn: () => chamaService.dashboard(activeChamaId!).then((r) => r.data),
    enabled: !!activeChamaId,
    staleTime: 30_000,
  });

  const { data: members, isLoading: membersLoading, refetch: refetchMembers } = useQuery({
    queryKey: ["members", activeChamaId],
    queryFn: () => memberService.list(activeChamaId!).then((r) => r.data),
    enabled: !!activeChamaId,
    staleTime: 60_000,
  });

  const sorted = [...(members ?? [])].sort((a: any, b: any) => b.total_savings - a.total_savings);

  const onRefresh = useCallback(() => {
    refetchStats();
    refetchMembers();
  }, [refetchStats, refetchMembers]);

  if (statsLoading || membersLoading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color={Colors.green600} />
        <Text style={styles.loadingText}>Loading dashboard...</Text>
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      refreshControl={<RefreshControl refreshing={false} onRefresh={onRefresh} tintColor={Colors.green600} />}
      showsVerticalScrollIndicator={false}
    >
      <HeroCard stats={stats} />
      <MeetingBanner stats={stats} />

      <View style={styles.statGrid}>
        <StatCard icon="🏦" value={formatKES(stats?.total_active_loans ?? 0)} label="Active loans" trend={`${stats?.pending_approvals ?? 0} pending`} trendColor={Colors.amber} />
        <StatCard icon="👥" value={stats?.active_members ?? 0} label="Active members" trend={`${stats?.compliance_rate ?? 0}% compliance`} trendColor={Colors.green600} />
        <StatCard icon="⏳" value={stats?.pending_approvals ?? 0} label="Pending approvals" trend="Action needed" trendColor={Colors.amber} />
        <StatCard icon="⚠️" value={stats?.defaulting_members ?? 0} label="Defaulting" trend="Need follow-up" trendColor={Colors.red} />
      </View>

      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <Text style={styles.cardTitle}>Member leaderboard</Text>
          <TouchableOpacity onPress={() => navigation?.navigate?.("Members")}>
            <Text style={styles.cardAction}>See all</Text>
          </TouchableOpacity>
        </View>
        {sorted.slice(0, 6).map((m: any, i: number) => (
          <LeaderboardRow key={m.id} member={m} rank={i + 1} onPress={() => {}} />
        ))}
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Contribution types</Text>
        <View style={styles.ctGrid}>
          {[
            { label: "Regular", pct: "68%", color: Colors.green500 },
            { label: "Welfare", pct: "20%", color: Colors.blue },
            { label: "Merry-Go", pct: "12%", color: Colors.amber },
          ].map((t) => (
            <View key={t.label} style={[styles.ctCard, { borderColor: t.color + "40" }]}>
              <Text style={[styles.ctPct, { color: t.color }]}>{t.pct}</Text>
              <Text style={styles.ctLabel}>{t.label}</Text>
            </View>
          ))}
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  content: { padding: Spacing.lg, paddingBottom: 80 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: Colors.background },
  loadingText: { marginTop: Spacing.md, color: Colors.slate500, fontSize: FontSize.base },

  hero: {
    backgroundColor: Colors.green900,
    borderRadius: Radius.xxl,
    padding: Spacing.xxl,
    marginBottom: Spacing.md,
  },
  heroLabel: { fontSize: FontSize.sm, color: "rgba(255,255,255,0.6)", fontWeight: "500", marginBottom: 6 },
  heroAmount: { fontSize: 34, fontWeight: "800", color: "#fff", letterSpacing: -1, marginBottom: 4 },
  heroSub: { fontSize: FontSize.sm, color: "rgba(255,255,255,0.45)" },
  heroChips: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 14 },
  heroChip: { backgroundColor: "rgba(255,255,255,0.12)", borderRadius: 20, paddingHorizontal: 12, paddingVertical: 5 },
  heroChipText: { fontSize: 11, color: "rgba(255,255,255,0.75)" },
  heroChipBold: { color: "#fff", fontWeight: "700" },

  meetingBanner: {
    backgroundColor: Colors.green800,
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
  },
  meetingIconWrap: {
    width: 42, height: 42, backgroundColor: "rgba(255,255,255,0.12)",
    borderRadius: 12, alignItems: "center", justifyContent: "center",
  },
  meetingTitle: { fontSize: FontSize.base, fontWeight: "700", color: "#fff" },
  meetingDate: { fontSize: FontSize.xs, color: "rgba(255,255,255,0.55)", marginTop: 2 },
  meetingDays: { backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 20, paddingHorizontal: 11, paddingVertical: 5 },
  meetingDaysText: { fontSize: FontSize.sm, fontWeight: "700", color: "#fff" },

  statGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: Spacing.md },
  statCard: {
    width: "48%", backgroundColor: Colors.surface, borderRadius: Radius.lg,
    borderWidth: 1, borderColor: Colors.border, padding: Spacing.lg, ...Shadow.sm,
  },
  statIcon: { width: 36, height: 36, borderRadius: 10, backgroundColor: Colors.green50, alignItems: "center", justifyContent: "center", marginBottom: 10 },
  statValue: { fontSize: 22, fontWeight: "800", color: Colors.slate900, letterSpacing: -0.5 },
  statLabel: { fontSize: FontSize.xs, color: Colors.slate500, marginTop: 3 },
  statTrend: { fontSize: FontSize.xs, fontWeight: "600", marginTop: 4 },

  card: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border,
    padding: Spacing.lg, marginBottom: Spacing.md, ...Shadow.sm,
  },
  cardHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: Spacing.md },
  cardTitle: { fontSize: 15, fontWeight: "700", color: Colors.slate900 },
  cardAction: { fontSize: FontSize.base, fontWeight: "600", color: Colors.green700 },

  lbRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: Colors.slate200 },
  lbRank: { width: 26, height: 26, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  lbRankText: { fontSize: 12, fontWeight: "700" },
  avatar: { width: 32, height: 32, borderRadius: 16, alignItems: "center", justifyContent: "center" },
  avatarText: { fontSize: 11, fontWeight: "700" },
  lbName: { fontSize: 13, fontWeight: "600", color: Colors.slate900 },
  lbBar: { height: 3, backgroundColor: Colors.slate200, borderRadius: 2, marginTop: 5 },
  lbFill: { height: "100%", backgroundColor: Colors.green500, borderRadius: 2 },
  lbAmt: { fontSize: 13, fontWeight: "700", color: Colors.green900 },
  lateBadge: { backgroundColor: Colors.redLight, borderRadius: 20, paddingHorizontal: 8, paddingVertical: 2 },
  lateBadgeText: { fontSize: 10, fontWeight: "600", color: Colors.red },

  ctGrid: { flexDirection: "row", gap: 10, marginTop: 10 },
  ctCard: { flex: 1, backgroundColor: Colors.slate50, borderRadius: Radius.md, borderWidth: 1, padding: Spacing.md, alignItems: "center" },
  ctPct: { fontSize: 20, fontWeight: "800" },
  ctLabel: { fontSize: 11, color: Colors.slate500, marginTop: 2 },
});
