/**
 * Global state store — Zustand.
 * Manages: auth session, active chama, UI state.
 */
import { create } from "zustand";
import { clearTokens, saveTokens } from "../services/api";

interface User {
  id: string;
  full_name: string;
  phone_number: string;
  email?: string;
  is_pin_set: boolean;
  role: string;
}

interface Chama {
  id: string;
  name: string;
  monthly_contribution: number;
  mpesa_till?: string;
  mpesa_paybill?: string;
  flat_interest_rate: number;
  reducing_interest_rate: number;
  default_interest_method: string;
}

interface AppState {
  // Auth
  user: User | null;
  isAuthenticated: boolean;
  isPinVerified: boolean;
  isAppLocked: boolean;

  // Active chama
  activeChamaId: string | null;
  activeChama: Chama | null;

  // Actions
  setUser: (user: User | null) => void;
  login: (user: User, accessToken: string, refreshToken: string) => Promise<void>;
  logout: () => Promise<void>;
  setPinVerified: (verified: boolean) => void;
  lockApp: () => void;
  setActiveChama: (chama: Chama | null) => void;
}

export const useAppStore = create<AppState>((set) => ({
  user: null,
  isAuthenticated: false,
  isPinVerified: false,
  isAppLocked: false,
  activeChamaId: null,
  activeChama: null,

  setUser: (user) => set({ user, isAuthenticated: !!user }),

  login: async (user, accessToken, refreshToken) => {
    await saveTokens(accessToken, refreshToken);
    set({ user, isAuthenticated: true });
  },

  logout: async () => {
    await clearTokens();
    set({
      user: null,
      isAuthenticated: false,
      isPinVerified: false,
      isAppLocked: false,
      activeChamaId: null,
      activeChama: null,
    });
  },

  setPinVerified: (verified) => set({ isPinVerified: verified, isAppLocked: !verified }),

  lockApp: () => set({ isAppLocked: true, isPinVerified: false }),

  setActiveChama: (chama) =>
    set({ activeChama: chama, activeChamaId: chama?.id ?? null }),
}));
