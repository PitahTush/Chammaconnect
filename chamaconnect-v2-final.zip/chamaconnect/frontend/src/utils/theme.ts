/**
 * Design tokens — colours, spacing, typography, shadows.
 */
export const Colors = {
  // Brand greens
  green900: "#064E3B",
  green800: "#065F46",
  green700: "#047857",
  green600: "#059669",
  green500: "#10B981",
  green400: "#34D399",
  green100: "#D1FAE5",
  green50:  "#ECFDF5",

  // Slate / navy
  slate900: "#0F172A",
  slate800: "#1E293B",
  slate700: "#334155",
  slate600: "#475569",
  slate500: "#64748B",
  slate400: "#94A3B8",
  slate300: "#CBD5E1",
  slate200: "#E2E8F0",
  slate100: "#F1F5F9",
  slate50:  "#F8FAFC",

  // Semantic
  amber:    "#D97706",
  amberLight: "#FEF3C7",
  red:      "#DC2626",
  redLight: "#FEE2E2",
  blue:     "#2563EB",
  blueLight:"#EFF6FF",

  // Base
  white: "#FFFFFF",
  background: "#F8FAFC",
  surface: "#FFFFFF",
  border: "#E2E8F0",
  mpesa: "#00A651",
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
};

export const Radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  full: 9999,
};

export const FontSize = {
  xs: 11,
  sm: 12,
  base: 14,
  md: 15,
  lg: 17,
  xl: 20,
  xxl: 24,
  hero: 36,
};

export const Shadow = {
  sm: {
    shadowColor: "#0F172A",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  md: {
    shadowColor: "#0F172A",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 4,
  },
};

export const formatKES = (amount: number | string): string => {
  const n = typeof amount === "string" ? parseFloat(amount) : amount;
  if (n >= 1_000_000) return `KES ${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `KES ${(n / 1_000).toFixed(0)}K`;
  return `KES ${n.toLocaleString()}`;
};

export const formatKESFull = (amount: number | string): string => {
  const n = typeof amount === "string" ? parseFloat(amount) : amount;
  return `KES ${n.toLocaleString("en-KE", { minimumFractionDigits: 0 })}`;
};
