/**
 * ChamaConnect — Root App Component
 * Handles: PIN lock gate, auth routing, bottom nav
 */
import React, { useEffect, useState } from "react";
import {
  View, Text, TouchableOpacity, StyleSheet,
  SafeAreaView, StatusBar, AppState,
} from "react-native";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useAppStore } from "./src/store/appStore";
import { authService, getAccessToken } from "./src/services/api";
import PinLockScreen from "./src/screens/PinLockScreen";
import DashboardScreen from "./src/screens/DashboardScreen";
import LoansScreen from "./src/screens/LoansScreen";
import { Colors, FontSize, Spacing } from "./src/utils/theme";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 2, staleTime: 30_000 },
  },
});

type Screen = "dashboard" | "members" | "contributions" | "loans" | "settings";

function MainApp() {
  const [screen, setScreen] = useState<Screen>("dashboard");
  const { lockApp } = useAppStore();

  // Lock app when it goes to background
  useEffect(() => {
    const sub = AppState.addEventListener("change", (state) => {
      if (state === "background") lockApp();
    });
    return () => sub.remove();
  }, [lockApp]);

  const navItems: { key: Screen; icon: string; label: string }[] = [
    { key: "dashboard",     icon: "🏠", label: "Home" },
    { key: "members",       icon: "👥", label: "Members" },
    { key: "contributions", icon: "💰", label: "Savings" },
    { key: "loans",         icon: "🏦", label: "Loans" },
    { key: "settings",      icon: "⚙️", label: "Treasurer" },
  ];

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.green900} />

      {/* Top bar */}
      <View style={styles.topbar}>
        <View style={styles.brandWrap}>
          <View style={styles.brandMark}>
            <Text style={styles.brandMarkText}>CC</Text>
          </View>
          <View>
            <Text style={styles.brandName}>ChamaConnect</Text>
            <Text style={styles.brandSub}>Pamoja Tunaweza</Text>
          </View>
        </View>
        <TouchableOpacity style={styles.iconBtn} onPress={lockApp}>
          <Text>🔒</Text>
        </TouchableOpacity>
      </View>

      {/* Screen content */}
      <View style={{ flex: 1 }}>
        {screen === "dashboard"     && <DashboardScreen />}
        {screen === "loans"         && <LoansScreen />}
        {screen === "members"       && <PlaceholderScreen title="Members" icon="👥" />}
        {screen === "contributions" && <PlaceholderScreen title="Savings & Contributions" icon="💰" />}
        {screen === "settings"      && <PlaceholderScreen title="Treasurer Settings" icon="⚙️" />}
      </View>

      {/* Bottom navigation */}
      <View style={styles.bottomNav}>
        {navItems.map((item) => (
          <TouchableOpacity
            key={item.key}
            style={styles.navItem}
            onPress={() => setScreen(item.key)}
          >
            <Text style={[styles.navIcon, screen === item.key && styles.navIconActive]}>
              {item.icon}
            </Text>
            <Text style={[styles.navLabel, screen === item.key && styles.navLabelActive]}>
              {item.label}
            </Text>
            {screen === item.key && <View style={styles.navDot} />}
          </TouchableOpacity>
        ))}
      </View>
    </SafeAreaView>
  );
}

function PlaceholderScreen({ title, icon }: { title: string; icon: string }) {
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: Colors.background }}>
      <Text style={{ fontSize: 52, marginBottom: 16 }}>{icon}</Text>
      <Text style={{ fontSize: 20, fontWeight: "700", color: Colors.slate900 }}>{title}</Text>
      <Text style={{ fontSize: 14, color: Colors.slate500, marginTop: 8 }}>
        Connected to the live API
      </Text>
    </View>
  );
}

function AuthGate() {
  const { isAuthenticated, isAppLocked, isPinVerified, login, setUser } = useAppStore();
  const [loading, setLoading] = useState(true);
  const [forgotPin, setForgotPin] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const token = await getAccessToken();
        if (token) {
          const resp = await authService.me();
          setUser(resp.data);
        }
      } catch {}
      setLoading(false);
    })();
  }, []);

  if (loading) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: Colors.green900 }}>
        <Text style={{ color: "#fff", fontSize: 18, fontWeight: "700" }}>ChamaConnect</Text>
        <Text style={{ color: "rgba(255,255,255,0.5)", marginTop: 8 }}>Loading...</Text>
      </View>
    );
  }

  // Not logged in → show simple login prompt
  if (!isAuthenticated) {
    return <LoginScreen />;
  }

  // Logged in but app is locked (or PIN not yet verified)
  if (isAppLocked || !isPinVerified) {
    return <PinLockScreen onForgot={() => setForgotPin(true)} />;
  }

  return <MainApp />;
}

function LoginScreen() {
  const { login } = useAppStore();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleDemoLogin = async () => {
    setLoading(true);
    setError("");
    try {
      const { default: axios } = await import("axios");
      const resp = await axios.post("http://localhost:8000/api/v1/auth/login", {
        phone_number: "+254712345678",
        password: "Password123!",
      });
      const { access_token, refresh_token } = resp.data;
      const me = await axios.get("http://localhost:8000/api/v1/auth/me", {
        headers: { Authorization: `Bearer ${access_token}` },
      });
      await login(me.data, access_token, refresh_token);
    } catch (e: any) {
      setError("Could not connect. Make sure the backend is running on port 8000.");
    }
    setLoading(false);
  };

  return (
    <View style={{ flex: 1, backgroundColor: Colors.green900, alignItems: "center", justifyContent: "center", padding: 32 }}>
      <View style={styles.brandMark}>
        <Text style={styles.brandMarkText}>CC</Text>
      </View>
      <Text style={{ fontSize: 28, fontWeight: "800", color: "#fff", marginTop: 16 }}>ChamaConnect</Text>
      <Text style={{ color: "rgba(255,255,255,0.6)", marginTop: 8, marginBottom: 40 }}>Pamoja Tunaweza</Text>
      {error ? <Text style={{ color: "#FCA5A5", marginBottom: 16, textAlign: "center" }}>{error}</Text> : null}
      <TouchableOpacity
        style={{ width: "100%", height: 52, backgroundColor: Colors.green500, borderRadius: 14, alignItems: "center", justifyContent: "center" }}
        onPress={handleDemoLogin}
        disabled={loading}
      >
        <Text style={{ color: "#fff", fontSize: 16, fontWeight: "700" }}>
          {loading ? "Connecting..." : "Login with Demo Account"}
        </Text>
      </TouchableOpacity>
      <Text style={{ color: "rgba(255,255,255,0.4)", fontSize: 12, marginTop: 16, textAlign: "center" }}>
        Demo: +254712345678 / Password123! / PIN: 1234
      </Text>
    </View>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthGate />
    </QueryClientProvider>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: Colors.green900 },
  topbar: {
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    height: 52,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
  },
  brandWrap: { flexDirection: "row", alignItems: "center", gap: 9 },
  brandMark: { width: 34, height: 34, backgroundColor: Colors.green900, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  brandMarkText: { color: "#fff", fontWeight: "800", fontSize: 13 },
  brandName: { fontSize: 17, fontWeight: "800", color: Colors.slate900, letterSpacing: -0.4 },
  brandSub: { fontSize: 11, color: Colors.slate500 },
  iconBtn: { width: 38, height: 38, borderRadius: 10, backgroundColor: Colors.slate100, alignItems: "center", justifyContent: "center" },
  bottomNav: {
    flexDirection: "row",
    backgroundColor: Colors.surface,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    height: 68,
  },
  navItem: { flex: 1, alignItems: "center", justifyContent: "center", gap: 3 },
  navIcon: { fontSize: 22, opacity: 0.4 },
  navIconActive: { opacity: 1 },
  navLabel: { fontSize: 10, fontWeight: "500", color: Colors.slate400 },
  navLabelActive: { color: Colors.green700, fontWeight: "700" },
  navDot: { width: 4, height: 4, borderRadius: 2, backgroundColor: Colors.green500 },
});
